/* eGyan Classes — OMR Auto-Checker: licence client (free trial · annual licence · UPI payment request · activation).
   The licence SERVER is the only authority. This file never decides that a payment is valid or a code is correct; it only
   asks the server, verifies the server's Ed25519 signature on the answer, and caches the signed answer for a short offline grace period.
   Honest limitation: someone who edits their own copy of this JavaScript can remove the gate. Payment approval, activation codes,
   the trial counter and expiry are enforced by the server; scanning itself stays local and existing results are never locked. */
(function () {
  'use strict';
  const C = Object.assign({ api: '', publicKey: null, upiId: '', payeeName: '', whatsapp: '', whatsappCountryCode: '91', price: 500, qrImage: '' }, window.EGYAN_LICENSE || {});
  const ON = !!String(C.api || '').trim(), API = String(C.api || '').replace(/\/+$/, ''), KEY = 'egyan_license_v1', DAY = 86400000;
  const $ = id => document.getElementById(id);
  let st = load(), ent = null, entOK = false, syncing = false, lastRefresh = 0, view = 'status', banner = '', booted = false, openFlag = false, subtleUnsupported = false, busy = false;
  let ui = { form: {}, msg: null, lastCheck: null };

  function load() { try { const v = JSON.parse(localStorage.getItem(KEY) || '{}'); return Object.assign({ cid: '', secret: '', token: '', offset: 0, maxSeen: 0, pending: [], pub: null, req: null }, v, { pending: Array.isArray(v.pending) ? v.pending : [] }); } catch (_) { return { cid: '', secret: '', token: '', offset: 0, maxSeen: 0, pending: [], pub: null, req: null }; } }
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (_) {} };
  const hex = n => Array.from(crypto.getRandomValues(new Uint8Array(n)), b => b.toString(16).padStart(2, '0')).join('');
  const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : [hex(4), hex(2), '4' + hex(2).slice(1), '8' + hex(2).slice(1), hex(6)].join('-'));
  const b64uToBytes = s => { s = s.replace(/-/g, '+').replace(/_/g, '/'); const b = atob(s + '='.repeat((4 - s.length % 4) % 4)); return Uint8Array.from(b, c => c.charCodeAt(0)); };
  const money = n => '₹' + Number(n).toLocaleString('en-IN');
  const dmy = t => t ? new Date(t).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
  const now = () => { const n = Math.max(Date.now() + (st.offset || 0), st.maxSeen || 0); st.maxSeen = n; return n; };

  /* ---------- signature check ---------- */
  async function pubKey() {
    if (C.publicKey) return C.publicKey;
    if (st.pub) return st.pub;
    const r = await fetch(API + '/api/v1/public-key'); const j = await r.json(); if (!j.publicKey) throw new Error('No public key'); st.pub = j.publicKey; save(); return st.pub;   // first-use pin (set publicKey in the config to avoid this)
  }
  async function verify(token) {
    try {
      const [body, sig] = String(token).split('.'); if (!body || !sig || !crypto.subtle) return null;
      const key = await crypto.subtle.importKey('jwk', await pubKey(), { name: 'Ed25519' }, false, ['verify']);
      const ok = await crypto.subtle.verify('Ed25519', key, b64uToBytes(sig), new TextEncoder().encode(body)); if (!ok) return null;
      return JSON.parse(new TextDecoder().decode(b64uToBytes(body)));
    } catch (e) { if (e && (e.name === 'NotSupportedError' || e.name === 'SyntaxError' || /Ed25519|algorithm/i.test(String(e.message)))) subtleUnsupported = true; return null; }
  }

  /* ---------- server calls ---------- */
  async function call(method, path, body, extra) {
    const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 20000);
    try {
      const r = await fetch(API + path, { method, signal: ctl.signal, headers: Object.assign({ 'x-client-id': st.cid, 'x-client-secret': st.secret }, body ? { 'content-type': 'application/json' } : {}, extra || {}), body: body ? JSON.stringify(body) : undefined });
      const j = await r.json().catch(() => ({})); if (!r.ok || j.ok === false) { const e = new Error(j.message || 'Request failed'); e.code = j.error; e.status = r.status; e.retryAfter = j.retryAfter; e.field = j.field; throw e; } return j;
    } catch (e) { if (e.name === 'AbortError') { const x = new Error('The licence server did not answer. Check your internet connection.'); x.code = 'offline'; throw x; } if (e instanceof TypeError) { const x = new Error('Cannot reach the licence server. Check your internet connection.'); x.code = 'offline'; throw x; } throw e; }
    finally { clearTimeout(t); }
  }
  async function apply(e) {   // accept a server answer ONLY if its signature verifies (or, on browsers without Ed25519, keep it in memory only)
    const p = await verify(e.token);
    if (p && p.cid === st.cid) { ent = p; entOK = true; st.token = e.token; st.offset = e.serverTime - Date.now(); st.maxSeen = Math.max(st.maxSeen || 0, e.serverTime); }
    else if (subtleUnsupported && e && e.state) { ent = { state: e.state, trialAllowed: e.trialAllowed, trialUsed: e.trialUsed, trialRemaining: e.trialRemaining, expiresAt: e.expiresAt, activatedAt: e.activatedAt, exp: e.serverTime + 5 * 60000, cid: st.cid }; entOK = true; st.token = ''; st.offset = e.serverTime - Date.now(); }
    else throw new Error('The licence answer could not be verified. Please update your browser or contact support.');
    st.latest = e.latestRequest || null; save(); paint();
  }
  async function register() {
    if (!st.cid) { st.cid = uuid(); st.secret = hex(32); save(); }
    let school = ''; try { school = (JSON.parse(localStorage.getItem('p9_school_v1') || '{}').name) || ''; } catch (_) {}
    const j = await call('POST', '/api/v1/client/register', { clientId: st.cid, secret: st.secret, school }); await apply(j.entitlement);
  }
  async function refresh() {
    if (!ON) return; lastRefresh = Date.now();
    try { if (!st.cid) await register(); else { try { const j = await call('GET', '/api/v1/entitlement'); await apply(j.entitlement); } catch (e) { if (e.status === 401) await register(); else throw e; } } if (st.pending.length) await sync(); }
    catch (e) { if (e.code !== 'offline') console.warn('[licence]', e.message); paint(); }
  }
  async function sync() {
    if (syncing || !st.pending.length || !st.cid) return; syncing = true; const ids = st.pending.slice(0, 100);
    try { let school = ''; try { school = (JSON.parse(localStorage.getItem('p9_school_v1') || '{}').name) || ''; } catch (_) {} const j = await call('POST', '/api/v1/usage', { ids, school }); st.pending = st.pending.filter(x => !ids.includes(x)); await apply(j.entitlement); syncing = false; if (st.pending.length) return sync(); }
    catch (e) { /* offline: the ids stay queued and are sent later */ } finally { syncing = false; }
  }

  /* ---------- the gate used by the scanner ---------- */
  function allowed() {
    if (!ON) return true; if (!ent || !entOK) return false;
    const n = now(); if (ent.exp && ent.exp < n) return false;          // cached answer too old: must be re-verified online
    if (ent.state === 'active') return ent.expiresAt > n;
    if (ent.state === 'trial') return ent.trialRemaining - st.pending.length > 0;
    return false;
  }
  function remaining() { return ent && ent.state === 'trial' ? Math.max(0, ent.trialRemaining - st.pending.length) : 0; }
  function gate() { if (allowed()) return true; if (openFlag) return false;   /* auto-scan calls this every frame: never re-render or hijack an open panel */
    if (!ent || !entOK || (ent.exp && ent.exp < now())) { banner = 'verify'; refresh(); } else banner = ent.state; open('status'); return false; }
  function recordEvaluation(id) {
    if (!ON || !id) return; id = String(id).slice(0, 64);
    if (!st.pending.includes(id)) { st.pending.push(id); if (st.pending.length > 500) st.pending.shift(); save(); }
    paint(); sync();
  }

  /* ---------- tiny DOM helper (no innerHTML with data) ---------- */
  function h(tag, props, ...kids) {
    const e = document.createElement(tag);
    for (const k in (props || {})) { const v = props[k]; if (v == null || v === false) continue; if (k === 'class') e.className = v; else if (k === 'text') e.textContent = v; else if (k.startsWith('on')) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v === true ? '' : v); }
    for (const c of kids.flat(Infinity)) if (c != null && c !== false) e.append(c.nodeType ? c : document.createTextNode(String(c)));
    return e;
  }
  const NOCFG = 'Licensing server not configured. You can view the payment details here, but online payment submission and activation are not available until the licensing server is set up (license-config.js → api). No payment request has been submitted, and no licence can be activated from this app yet.';
  const noCfgAlert = () => h('div', { class: 'lic-alert warn', id: 'lic-nocfg', role: 'alert', text: NOCFG });
  const wa = text => 'https://wa.me/' + C.whatsappCountryCode + C.whatsapp + '?text=' + encodeURIComponent(text);
  const upiLink = () => 'upi://pay?pa=' + encodeURIComponent(C.upiId) + '&pn=' + encodeURIComponent(C.payeeName) + '&am=' + C.price + '&cu=INR&tn=' + encodeURIComponent('OMR Auto-Checker Annual License');
  const instructions = () => 'OMR Auto-Checker Annual License — ' + money(C.price) + '\n1. Pay exactly ' + money(C.price) + ' to UPI ID ' + C.upiId + ' (account name shown: ' + C.payeeName + '), or scan the PhonePe QR.\n2. Note the UPI transaction / reference ID from your UPI app.\n3. In the app open License → "I have paid", enter that reference ID and submit.\n4. After the administrator verifies the payment, enter the 4-digit activation code.';
  async function copy(text, label) { try { await navigator.clipboard.writeText(text); } catch (_) { const t = h('textarea', { 'aria-hidden': 'true' }); t.value = text; document.body.append(t); t.select(); try { document.execCommand('copy'); } catch (__) {} t.remove(); } flash(label + ' copied'); }
  function flash(msg) { ui.msg = { text: msg, kind: 'ok' }; const m = $('lic-flash'); if (m) { m.textContent = msg; m.className = 'lic-flash show'; clearTimeout(flash.t); flash.t = setTimeout(() => { m.className = 'lic-flash'; }, 2600); } }

  /* ---------- header pill ---------- */
  function paint() {
    const p = $('egf-lic-pill'); if (p) {
      p.hidden = false; {   // always visible, with or without a configured server
        let t = ON ? 'License…' : '🔑 License', c = 'lic-unknown';
        if (ent && entOK) {
          if (ent.state === 'trial') { const r = remaining(); t = r > 0 ? '🔑 Free trial · ' + r + ' left' : '⚠ Trial completed'; c = r > 0 ? 'lic-trial' : 'lic-warn'; }
          else if (ent.state === 'trial_completed') { t = '⚠ Trial completed'; c = 'lic-warn'; }
          else if (ent.state === 'active') { const d = Math.max(0, Math.ceil((ent.expiresAt - now()) / DAY)); t = '✓ Licensed · ' + d + ' days left'; c = d <= 30 ? 'lic-warn' : 'lic-ok'; }
          else if (ent.state === 'expired') { t = '⚠ License expired'; c = 'lic-bad'; } else if (ent.state === 'revoked') { t = '⚠ License revoked'; c = 'lic-bad'; }
        }
        p.textContent = t; p.className = 'p9-btn small lic-pill ' + c;
      }
    }
    paintHome();
    if (openFlag && view !== 'form' && view !== 'activate') render();   // never rebuild a screen the user is typing in
  }

  /* ---------- home-page licence card (static markup in index.html, always visible) ---------- */
  function paintHome() {
    const s = $('egf-home-lic-status'), w = $('egf-home-lic-warn'); if (!s) return;
    let t = 'Verifying your licence… (connect to the internet once)', c = 'unknown';
    if (!ON) { t = 'Licence status: not connected to a licensing server'; c = 'warn'; }
    else if (ent && entOK) {
      if (ent.state === 'trial') { const r = remaining(); t = r > 0 ? 'Free trial: ' + r + ' of ' + ent.trialAllowed + ' copies left' : 'Free trial completed — the annual license is needed for new sheets'; c = r > 0 ? 'info' : 'warn'; }
      else if (ent.state === 'trial_completed') { t = 'Free trial completed — the annual license is needed for new sheets'; c = 'warn'; }
      else if (ent.state === 'active') { t = 'License active until ' + dmy(ent.expiresAt) + ' · unlimited OMR checking'; c = 'ok'; }
      else if (ent.state === 'expired') { t = 'License expired on ' + dmy(ent.expiresAt) + ' — renew to check new sheets'; c = 'bad'; }
      else { t = 'License revoked — contact us on WhatsApp'; c = 'bad'; }
    }
    if (ON && st.req && !(ent && ent.state === 'active')) t += ' · Payment request ' + st.req.id + ' is waiting for admin approval';
    s.textContent = t; s.className = 'lic-home-status ' + c; if (w) { w.hidden = ON; w.textContent = NOCFG; }
  }

  /* ---------- License Center ---------- */
  function root() {
    let r = $('egf-lic'); if (r) return r;
    r = h('div', { id: 'egf-lic', class: 'lic-overlay', hidden: true, role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'lic-title' });
    r.addEventListener('click', e => { if (e.target === r) close(); }); document.body.append(r);
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && openFlag) close(); }); return r;
  }
  function open(v) { view = v || 'status'; openFlag = true; const r = root(); r.hidden = false; document.documentElement.classList.add('lic-open'); render(); const f = r.querySelector('[data-autofocus]') || r.querySelector('button,input'); if (f) f.focus({ preventScroll: true }); }
  function close() { openFlag = false; banner = ''; const r = $('egf-lic'); if (r) { r.hidden = true; r.replaceChildren(); } document.documentElement.classList.remove('lic-open'); const p = $('egf-lic-pill'); if (p && !p.hidden) p.focus({ preventScroll: true }); }
  function go(v) { if (!ON && (v === 'form' || v === 'pending')) v = 'pay'; view = v; ui.err = null; render(); const f = $('egf-lic').querySelector('[data-autofocus]'); if (f) f.focus({ preventScroll: true }); }

  function stat(label, val, cls) { return h('div', { class: 'lic-stat' }, h('span', { text: label }), h('b', { class: cls || '', text: String(val) })); }
  function statusCard() {
    if (!ON) return h('div', { class: 'lic-card lic-state-warn' }, h('div', { class: 'lic-row' }, h('h3', { text: 'Licence status' }), h('span', { class: 'lic-badge warn', text: 'Server not configured' })), h('p', { class: 'lic-muted', text: 'This copy of the app is not connected to a licensing server, so the free trial is not being counted and no licence can be verified or activated. Saved results and all scanning features work as usual.' }));
    if (!ent || !entOK) return h('div', { class: 'lic-card lic-state-unknown' }, h('h3', { text: 'Verifying your licence…' }), h('p', { class: 'lic-muted', text: 'Connect to the internet once so the licence server can confirm your plan. Your saved results stay available meanwhile.' }), h('button', { class: 'p9-btn small', type: 'button', text: 'Try again', onclick: () => refresh() }));
    const s = ent.state;
    if (s === 'trial' || s === 'trial_completed') {
      const used = Math.min(ent.trialAllowed, ent.trialUsed + st.pending.length), rem = Math.max(0, ent.trialAllowed - used), done = rem === 0;
      return h('div', { class: 'lic-card ' + (done ? 'lic-state-warn' : 'lic-state-trial') }, h('div', { class: 'lic-row' }, h('h3', { text: 'Plan: Free Trial' }), h('span', { class: 'lic-badge ' + (done ? 'warn' : 'info'), text: done ? 'Trial Completed' : 'Free Trial Active' })),
        h('div', { class: 'lic-stats' }, stat('Copies allowed', ent.trialAllowed), stat('Copies used', used), stat('Copies remaining', rem, done ? 'bad' : 'ok')),
        h('div', { class: 'lic-meter', role: 'progressbar', 'aria-valuemin': 0, 'aria-valuemax': ent.trialAllowed, 'aria-valuenow': used }, h('i', { class: 'w' + Math.round(used / ent.trialAllowed * 20) * 5 })),
        done ? h('p', { class: 'lic-note', text: 'Your free trial is complete. Purchase the annual license for ₹500 to continue checking new OMR sheets.' }) : h('p', { class: 'lic-muted', text: 'Each successfully checked student sheet uses one copy. Failed scans, camera previews and re-opening saved results are free.' }));
    }
    if (s === 'active') { const d = Math.max(0, Math.ceil((ent.expiresAt - now()) / DAY));
      return h('div', { class: 'lic-card lic-state-ok' }, h('div', { class: 'lic-row' }, h('h3', { text: 'Plan: Annual License' }), h('span', { class: 'lic-badge ok', text: 'Active' })),
        h('div', { class: 'lic-stats' }, stat('Payment', 'Verified', 'ok'), stat('Activation date', dmy(ent.activatedAt)), stat('Expiry date', dmy(ent.expiresAt)), stat('Days left', d, d <= 30 ? 'bad' : 'ok')), h('p', { class: 'lic-muted', text: 'OMR checking: Unlimited during active validity.' })); }
    if (s === 'expired') return h('div', { class: 'lic-card lic-state-bad' }, h('div', { class: 'lic-row' }, h('h3', { text: 'Plan: Annual License' }), h('span', { class: 'lic-badge bad', text: 'Expired' })), h('div', { class: 'lic-stats' }, stat('Expiry date', dmy(ent.expiresAt), 'bad')), h('p', { class: 'lic-note', text: 'Your annual license has expired. Renew your license to check new OMR sheets.' }), h('p', { class: 'lic-muted', text: 'All saved student results and PDFs stay available.' }));
    return h('div', { class: 'lic-card lic-state-bad' }, h('div', { class: 'lic-row' }, h('h3', { text: 'Plan: Annual License' }), h('span', { class: 'lic-badge bad', text: 'Revoked' })), h('p', { class: 'lic-note', text: 'This license was revoked by the administrator. Contact us on WhatsApp.' }), h('a', { class: 'p9-btn small', target: '_blank', rel: 'noopener', href: wa('Hello eGyan Classes, my OMR Auto-Checker license shows as revoked. My client ID is ' + st.cid.slice(0, 8) + '.'), text: 'Contact Us on WhatsApp' }));
  }
  function planCard() {
    const renew = ent && (ent.state === 'expired' || ent.state === 'active');
    return h('div', { class: 'lic-plan' }, h('span', { class: 'lic-eyebrow', text: 'OMR AUTO-CHECKER' }), h('h3', { text: 'Annual School License' }), h('div', { class: 'lic-price' }, h('b', { text: '₹500' }), h('span', { text: ' / Year' })),
      h('ul', { class: 'lic-list' }, ['Unlimited OMR checking during the active license', 'Student result management', 'PDF result generation', 'Existing OMR scanning features', '365-day license validity', 'Secure activation'].map(t => h('li', { text: t }))),
      h('button', { class: 'p9-btn primary lic-cta', type: 'button', 'data-autofocus': true, text: renew ? 'Renew — Pay ₹500 via UPI' : 'Pay ₹500 via UPI', onclick: () => go('pay') }),
      h('p', { class: 'lic-fine', text: 'A licence is activated only after the administrator confirms the money in the bank/UPI account and you enter the activation code.' }));
  }
  function requestBanner() {
    const r = st.req; if (!r) return null;
    return h('div', { class: 'lic-card lic-state-pending' }, h('div', { class: 'lic-row' }, h('h3', { text: 'Payment request ' + r.id }), h('span', { class: 'lic-badge pending', text: 'Pending Admin Approval' })),
      h('div', { class: 'lic-actions' }, h('button', { class: 'p9-btn small', type: 'button', text: 'Check status', onclick: () => go('pending') }), h('button', { class: 'p9-btn small', type: 'button', text: 'Enter activation code', onclick: () => go('activate') })));
  }
  const back = (to) => h('button', { class: 'lic-back', type: 'button', text: '← Back', onclick: () => go(to || 'status') });
  function field(label, props, hint) { const i = h('input', Object.assign({ id: 'lf-' + props.name, autocomplete: 'off' }, props)); return h('label', { class: 'lic-field', for: 'lf-' + props.name }, h('span', { text: label }), i, hint ? h('small', { text: hint }) : null); }

  function viewStatus() {
    const kids = []; if (!ON) kids.push(noCfgAlert());
    if (banner === 'verify') kids.push(h('div', { class: 'lic-alert warn', role: 'alert', text: 'Scanning is paused until your licence is verified online. Connect to the internet and tap “Try again”. Saved results are not affected.' }));
    else if (banner === 'expired') kids.push(h('div', { class: 'lic-alert bad', role: 'alert', text: 'Your annual license has expired. Renew your license to check new OMR sheets.' }));
    else if (banner === 'revoked') kids.push(h('div', { class: 'lic-alert bad', role: 'alert', text: 'This license is not active. New OMR checking is blocked.' }));
    kids.push(statusCard(), requestBanner(), (!ent || ent.state !== 'active' || (ent.expiresAt - now()) < 30 * DAY) ? planCard() : null);
    kids.push(h('p', { class: 'lic-fine', text: 'Offline use: saved results, records and PDFs always open without internet. Checking NEW sheets needs a licence verified online within the last 48 hours.' }));
    return kids;
  }
  function viewPay() {
    const qr = h('img', { class: 'lic-qr', src: C.qrImage, alt: 'PhonePe payment QR code for ' + C.upiId, width: 1220, height: 2422, decoding: 'async' });
    return [back(), ON ? null : noCfgAlert(), h('h3', { class: 'lic-h', text: 'Scan & Pay Using PhonePe or Any Supported UPI App' }),
      h('div', { class: 'lic-pay' }, h('div', { class: 'lic-qrbox' }, qr, h('a', { class: 'lic-fine', href: C.qrImage, target: '_blank', rel: 'noopener', text: 'Open QR in full size' })),
        h('div', { class: 'lic-paycol' },
          h('div', { class: 'lic-kv' }, h('span', { text: 'Merchant UPI ID' }), h('b', { class: 'lic-mono', id: 'lic-upi', text: C.upiId })),
          h('div', { class: 'lic-kv' }, h('span', { text: 'Payment amount' }), h('b', { text: money(C.price) + ' (exactly)' })),
          h('div', { class: 'lic-kv' }, h('span', { text: 'Account name on the QR' }), h('b', { text: C.payeeName })),
          h('div', { class: 'lic-status-line' }, h('span', { class: 'lic-dot' }), h('span', { text: 'Payment status: Awaiting payment — not verified until the administrator confirms it' })),
          h('div', { class: 'lic-actions wrap' }, h('button', { class: 'p9-btn small', id: 'lic-copy-upi', type: 'button', text: 'Copy UPI ID', onclick: () => copy(C.upiId, 'UPI ID') }), h('button', { class: 'p9-btn small', type: 'button', text: 'Copy transaction instructions', onclick: () => copy(instructions(), 'Instructions') }),
            h('a', { class: 'p9-btn small', href: upiLink(), text: 'Open UPI app', title: 'Works only on some phones' }), h('a', { class: 'p9-btn small', target: '_blank', rel: 'noopener', href: wa('Hello eGyan Classes, I want to buy the OMR Auto-Checker annual license (₹500).'), text: 'Contact Us on WhatsApp' })),
          h('ol', { class: 'lic-steps' }, h('li', { text: 'Scan the QR with PhonePe (or any UPI app), or pay to the UPI ID above.' }), h('li', { text: 'Before you confirm, check the payee name matches the name above and pay exactly ₹500.' }), h('li', { text: 'Write down the UPI transaction / reference ID shown after payment.' }), h('li', { text: 'Come back here and submit it for verification.' })),
          h('p', { class: 'lic-fine', text: 'Scanning the QR or opening a UPI app does not confirm payment. Your licence is created only after the administrator verifies the money in the account. The “Open UPI app” button may not work on every phone or browser.' }),
          ON ? h('button', { class: 'p9-btn primary lic-cta', type: 'button', 'data-autofocus': true, text: 'I have paid — submit for verification', onclick: () => go('form') }) : h('button', { class: 'p9-btn lic-cta', type: 'button', id: 'lic-submit-disabled', disabled: true, 'aria-disabled': 'true', text: 'Submit for verification — unavailable (server not configured)' })))];
  }
  function viewForm() {
    if (!ON) return [back('pay'), noCfgAlert()];
    const f = ui.form, dt = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16); let school = f.school; if (school == null) { try { school = JSON.parse(localStorage.getItem('p9_school_v1') || '{}').name || ''; } catch (_) { school = ''; } }
    const err = h('div', { class: 'lic-alert bad', role: 'alert', id: 'lic-err', hidden: !ui.err, text: ui.err || '' }), btn = h('button', { class: 'p9-btn primary lic-cta', type: 'submit', id: 'lic-submit', text: 'Submit payment for verification' });
    const form = h('form', { class: 'lic-form', novalidate: true, onsubmit: async ev => { ev.preventDefault(); await submitPayment(form, btn); } },
      field('School name *', { name: 'school', value: school, maxlength: 80, required: true, 'data-autofocus': true }), field('Authorised contact name *', { name: 'contactName', value: f.contactName || '', maxlength: 60, required: true, autocomplete: 'name' }),
      field('Contact number (optional)', { name: 'contactPhone', value: f.contactPhone || '', maxlength: 15, inputmode: 'tel', autocomplete: 'tel' }, 'Only used if the administrator needs to reach you about this payment.'),
      field('UPI transaction / reference ID *', { name: 'txnId', value: f.txnId || '', maxlength: 35, required: true, autocapitalize: 'characters', spellcheck: 'false' }, 'Copy it from your UPI app after paying (usually 12 digits or letters).'),
      h('div', { class: 'lic-two' }, field('Amount paid (₹) *', { name: 'amount', value: String(C.price), inputmode: 'numeric', required: true }, 'Must be exactly ₹' + C.price + '.'), field('Payment date & time *', { name: 'paidAt', type: 'datetime-local', value: f.paidAt || dt, required: true })),
      h('label', { class: 'lic-field', for: 'lf-shot' }, h('span', { text: 'Payment screenshot (optional)' }), h('input', { id: 'lf-shot', name: 'shot', type: 'file', accept: 'image/png,image/jpeg,image/webp' }), h('small', { text: 'Supporting information only — the administrator still checks the real payment.' })), err, btn);
    return [back('pay'), h('h3', { class: 'lic-h', text: 'Submit payment for verification' }), form];
  }
  async function shrink(file) {
    if (!file) return null; if (!/^image\/(png|jpeg|webp)$/.test(file.type)) throw new Error('Screenshot must be a PNG, JPG or WebP image.');
    const url = URL.createObjectURL(file); try {
      const im = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('That image could not be read.')); i.src = url; });
      for (const [max, q] of [[1100, .72], [900, .6], [700, .5], [520, .45]]) { const k = Math.min(1, max / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement('canvas'); c.width = Math.max(1, Math.round(im.naturalWidth * k)); c.height = Math.max(1, Math.round(im.naturalHeight * k)); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); const d = c.toDataURL('image/jpeg', q); if (d.length < 420000) return d; }
      throw new Error('Screenshot is too large. Use a smaller one or skip it.');
    } finally { URL.revokeObjectURL(url); }
  }
  async function submitPayment(form, btn) {
    if (busy || !ON) return; const g = n => (form.elements[n].value || '').trim(); ui.form = { school: g('school'), contactName: g('contactName'), contactPhone: g('contactPhone'), txnId: g('txnId'), paidAt: g('paidAt') };
    const fail = m => { ui.err = m; const e = $('lic-err'); e.textContent = m; e.hidden = false; };
    if (g('school').length < 2) return fail('Please enter the school name.'); if (g('contactName').length < 2) return fail('Please enter the authorised contact name.');
    if (!/^[A-Za-z0-9]{8,35}$/.test(g('txnId').replace(/\s+/g, ''))) return fail('Enter the UPI transaction / reference ID exactly as shown in your UPI app (8–35 letters or digits).');
    if (Number(g('amount')) !== C.price) return fail('The licence fee is exactly ₹' + C.price + '. If you paid a different amount, contact us on WhatsApp.');
    const paid = new Date(g('paidAt')).getTime(); if (!Number.isFinite(paid)) return fail('Please enter the payment date and time.');
    busy = true; btn.disabled = true; btn.textContent = 'Submitting…';
    try {
      const shot = await shrink(form.elements.shot.files[0]);
      if (!st.cid) await register();
      const j = await call('POST', '/api/v1/payments', { school: g('school'), contactName: g('contactName'), contactPhone: g('contactPhone'), txnId: g('txnId').replace(/\s+/g, ''), amount: C.price, paidAt: paid, screenshot: shot || undefined });
      st.req = { id: j.requestId, statusToken: j.statusToken, status: 'pending' }; save(); ui.form = {}; ui.check = null; ui.err = null; go('pending'); refresh();
    } catch (e) { if (e.code === 'already_pending' && e.requestId) fail('You already have a payment waiting for verification (' + e.requestId + ').'); else fail(e.message); btn.disabled = false; btn.textContent = 'Submit payment for verification'; }
    finally { busy = false; }
  }
  function viewPending() {
    if (!ON) return [back('status'), noCfgAlert()];
    const r = st.req; if (!r) return [back(), h('p', { class: 'lic-muted', text: 'No payment request yet.' })];
    const c = ui.check, kids = [back(), h('h3', { class: 'lic-h', text: 'Payment submitted for verification.' }),
      h('div', { class: 'lic-card lic-state-pending' }, h('div', { class: 'lic-kv' }, h('span', { text: 'Request ID' }), h('b', { class: 'lic-mono lic-big', id: 'lic-reqid', text: r.id })),
        h('div', { class: 'lic-kv' }, h('span', { text: 'Status' }), h('span', { class: 'lic-badge ' + (c && c.status === 'rejected' ? 'bad' : c && c.status === 'approved' ? 'ok' : 'pending'), id: 'lic-reqstatus', text: c && c.status === 'rejected' ? 'Rejected' : c && c.status === 'approved' ? 'Approved — enter your activation code' : 'Pending Admin Approval' })),
        h('p', { class: 'lic-muted', text: 'The administrator will check the real payment in the bank/UPI account. This usually takes a short while. Tap “Check status” to see the result — you do not need to pay again.' }))];
    if (c && c.status === 'approved' && c.activationCode) kids.push(h('div', { class: 'lic-card lic-state-ok' }, h('p', { class: 'lic-muted', text: 'Your payment is verified. Your activation code:' }), h('div', { class: 'lic-code', id: 'lic-code', text: c.activationCode }), h('button', { class: 'p9-btn primary lic-cta', type: 'button', text: 'Activate with this code', onclick: () => { ui.code = c.activationCode; go('activate'); } })));
    if (c && c.status === 'rejected') kids.push(h('div', { class: 'lic-alert bad', role: 'alert' }, 'Payment rejected: ' + (c.rejectReason || 'not verified') + '. If you did pay, contact us on WhatsApp or submit a corrected request.'), h('button', { class: 'p9-btn small', type: 'button', text: 'Submit a new request', onclick: () => { st.req = null; ui.check = null; save(); go('form'); } }));
    if (ui.err) kids.push(h('div', { class: 'lic-alert bad', role: 'alert', text: ui.err }));
    kids.push(h('div', { class: 'lic-actions wrap' }, h('button', { class: 'p9-btn small', id: 'lic-check', type: 'button', 'data-autofocus': true, text: busy ? 'Checking…' : 'Check status', disabled: busy, onclick: checkStatus }), h('button', { class: 'p9-btn small', type: 'button', text: 'Enter activation code', onclick: () => go('activate') }),
      h('a', { class: 'p9-btn small', target: '_blank', rel: 'noopener', href: wa('Hello eGyan Classes, I have submitted my OMR Auto-Checker annual license payment request. My Request ID is ' + r.id + '. Please verify my payment.'), text: 'Contact Us on WhatsApp' })),
      h('p', { class: 'lic-fine', text: 'Opening WhatsApp does not activate anything. Only the administrator’s approval and your activation code do.' }));
    return kids;
  }
  async function checkStatus() {
    if (busy || !ON || !st.req) return; busy = true; ui.err = null; render();
    try { ui.check = await call('GET', '/api/v1/payments/' + st.req.id, null, { 'x-status-token': st.req.statusToken }); } catch (e) { ui.err = e.message; } finally { busy = false; render(); }
  }
  function viewActivate() {
    if (!ON) return [back('status'), h('h3', { class: 'lic-h', text: 'Activate License' }), noCfgAlert(), h('p', { class: 'lic-muted', text: 'Activation needs the licensing server: it checks your payment and your 4-digit code. Nothing can be activated on this device without it.' }), h('button', { class: 'p9-btn primary', type: 'button', 'data-autofocus': true, text: 'See payment details', onclick: () => go('pay') })];
    const err = h('div', { class: 'lic-alert bad', role: 'alert', id: 'lic-err', hidden: !ui.err, text: ui.err || '' }), req = st.req ? st.req.id : '';
    const code = h('input', { id: 'lf-code', class: 'lic-codein', inputmode: 'numeric', pattern: '[0-9]{4}', maxlength: 4, autocomplete: 'one-time-code', placeholder: '0000', 'aria-label': '4-digit activation code', 'data-autofocus': true, value: ui.code || '' });
    code.addEventListener('input', () => { code.value = code.value.replace(/\D/g, '').slice(0, 4); });
    const btn = h('button', { class: 'p9-btn primary lic-cta', type: 'submit', id: 'lic-activate', text: 'Activate license' });
    const form = h('form', { class: 'lic-form', novalidate: true, onsubmit: async ev => { ev.preventDefault(); await activate(code.value, btn); } },
      h('label', { class: 'lic-field', for: 'lf-req' }, h('span', { text: 'Payment request ID' }), h('input', { id: 'lf-req', value: req, readonly: true, class: 'lic-mono' })), h('label', { class: 'lic-field', for: 'lf-code' }, h('span', { text: '4-digit activation code' }), code), err, btn);
    return [back(st.req ? 'pending' : 'status'), h('h3', { class: 'lic-h', text: 'Enter your activation code' }), st.req ? form : h('p', { class: 'lic-muted', text: 'No payment request found on this device. Pay ₹500 and submit the transaction ID first — the code is created only after the administrator verifies your payment.' }), st.req ? h('button', { class: 'p9-btn small', type: 'button', id: 'lic-getcode', text: 'Check payment status / get my code', onclick: () => { go('pending'); checkStatus(); } }) : h('button', { class: 'p9-btn primary', type: 'button', text: 'Pay ₹500 via UPI', onclick: () => go('pay') }),
      h('p', { class: 'lic-fine', text: 'The code only works for the request shown above, from this device. Too many wrong attempts lock activation for a while.' })];
  }
  async function activate(code, btn) {
    if (busy || !ON || !st.req) return; ui.code = code; const fail = m => { ui.err = m; const e = $('lic-err'); if (e) { e.textContent = m; e.hidden = false; } };
    if (!/^\d{4}$/.test(code)) return fail('Enter the 4-digit code.');
    busy = true; btn.disabled = true; btn.textContent = 'Activating…';
    try { const j = await call('POST', '/api/v1/license/activate', { requestId: st.req.id, code }); await apply(j.entitlement); st.req = null; ui.check = null; ui.code = ''; save(); banner = ''; ui.done = true; go('status'); }
    catch (e) { fail(e.code === 'locked' ? 'Too many wrong attempts. Try again in ' + Math.ceil((e.retryAfter || 900) / 60) + ' minutes.' : e.message); btn.disabled = false; btn.textContent = 'Activate license'; }
    finally { busy = false; }
  }
  function render() {
    const r = $('egf-lic'); if (!r || !openFlag) return; const keep = document.activeElement && document.activeElement.id; let body;
    body = view === 'pay' ? viewPay() : view === 'form' ? viewForm() : view === 'pending' ? viewPending() : view === 'activate' ? viewActivate() : viewStatus();
    const done = ui.done && view === 'status' ? h('div', { class: 'lic-alert ok', role: 'status', text: '✓ License activated. Unlimited OMR checking is now enabled until the expiry date shown below.' }) : null; if (view !== 'status') ui.done = false;
    r.replaceChildren(h('div', { class: 'lic-sheet', tabindex: '-1' }, h('div', { class: 'lic-head' }, h('div', { class: 'lic-brand' }, h('span', { class: 'lic-mark' }), h('div', {}, h('b', { id: 'lic-title', text: 'License' }), h('small', { text: 'eGyan Classes · OMR Auto-Checker' }))), h('button', { class: 'lic-x', type: 'button', 'aria-label': 'Close', text: '✕', onclick: close })), done, h('div', { class: 'lic-body' }, body), h('div', { id: 'lic-flash', class: 'lic-flash', role: 'status' })));
    if (keep && $(keep) && $(keep).tagName !== 'BUTTON') $(keep).focus({ preventScroll: true });
  }

  /* the last signed answer is re-verified on start-up, so a school that was verified recently can keep scanning offline (max 48 h) */
  async function restore() { try { if (st.token) { const p = await verify(st.token); if (p && p.cid === st.cid) { ent = p; entOK = true; } } } catch (_) {} }

  /* ---------- boot ---------- */
  function boot() {
    if (booted) return; booted = true; const p = $('egf-lic-pill'); if (p) { p.hidden = false; p.addEventListener('click', () => open('status')); }
    document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('[data-lic-open]'); if (b) open(b.getAttribute('data-lic-open')); });   // home-page card buttons
    paint();
    if (!ON) return;
    restore().then(() => { paint(); refresh(); });
    window.addEventListener('online', () => refresh()); document.addEventListener('visibilitychange', () => { if (!document.hidden && Date.now() - lastRefresh > 10 * 60000) refresh(); });
  }
  window.EgyanLicense = { enabled: ON, gate, canEvaluate: allowed, recordEvaluation, open, refresh, state: () => ent && Object.assign({ pending: st.pending.length, remaining: remaining() }, ent) };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
