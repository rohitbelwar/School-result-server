/* =========================================================
   PHASE 9 — ADVANCED OMR AUTO-CHECKER
   eGyan Classes — multi-school edition
   Vanilla JS + Canvas + OpenCV.js
   Geometry calibrated from the supplied omr_sheet_a4_final.pdf.
   ========================================================= */
(() => {
  'use strict';

  const $ = id => document.getElementById(id);
  const qs = s => document.querySelector(s);
  const qsa = s => [...document.querySelectorAll(s)];

  const OMR_CONFIG = {
    questions: 50,
    options: ['A','B','C','D'],
    columns: [
      {startQuestion:1,endQuestion:13},
      {startQuestion:14,endQuestion:26},
      {startQuestion:27,endQuestion:39},
      {startQuestion:40,endQuestion:50}
    ],
    targetWidth: 1600,
    targetHeightHalf: 1131,
    targetHeightFull: 2263,
    grid: { x:0, y:0, width:1, height:1 },
    columnGap: 0,
    bubbleDetection: {
      threshold:150,
      minFillRatio:0.20,
      strongFillRatio:0.40,
      ambiguityRatio:0.08,
      scoreWeights:{fillRatio:0.60,centerDarkness:0.25,inkDensity:0.15},
      localSearchRadius:0.018,
      bubbleRadius:0.009
    }
  };

  const QUALITY_CONFIG = {
    minSharpness:80,
    minBrightness:50,
    maxBrightness:230,
    minContrast:22,
    minDocumentCoverage:0.35,
    maxPerspectiveRatio:2.8
  };

  const AUTO_SCAN_CONFIG = {
    enabled:true,
    stableFramesRequired:3,
    minDocumentAreaRatio:0.35,
    maxBlurVariance:Infinity,
    cooldownMs:900,
    intervalMs:220
  };

  const ANSWER_KEY_STORAGE = 'tbws_p9_answer_keys_v2';

  function emptyAnswerKey(){
    const key={};
    for(let q=1;q<=OMR_CONFIG.questions;q++) key[String(q)]='';
    return key;
  }

  function loadAnswerKeys(){
    const fallback={A:emptyAnswerKey(),B:emptyAnswerKey()};
    try{
      const raw=localStorage.getItem(ANSWER_KEY_STORAGE);
      if(!raw)return fallback;
      const parsed=JSON.parse(raw);
      const out={A:emptyAnswerKey(),B:emptyAnswerKey()};
      for(const set of ['A','B']){
        const src=parsed&&parsed[set]&&typeof parsed[set]==='object'?parsed[set]:{};
        for(let q=1;q<=OMR_CONFIG.questions;q++){
          const v=String(src[String(q)]??'').trim().toUpperCase();
          if(OMR_CONFIG.options.includes(v))out[set][String(q)]=v;
        }
      }
      return out;
    }catch(e){return fallback;}
  }

  const ANSWER_KEYS = loadAnswerKeys();


  /* Supplied PDF geometry, normalized to the half-page coordinate system.
     Page is A4 portrait. Each half is approximately 595 x 421 pt and the
     actual printed answer bubbles sit in the lower ~60% of each half. */
  function rowFrac(p,r){return r/Math.max(1,Math.max(...p.rowCountByColumn)-1);}
  function rowY(p,r){return p.firstRowY+(p.lastRowY-p.firstRowY)*rowFrac(p,r);}

  const OMR_PROFILES = {
    TBWS_CLASS_7_SET_A: {
      set:'A',
      pageType:'half',
      bubbleCentersX:[0.0747,0.1260,0.1763,0.2267, 0.3065,0.3568,0.4064,0.4560, 0.5374,0.5886,0.6381,0.6882, 0.7674,0.8178,0.8682,0.9186],
      firstRowY:0.3580,
      lastRowY:0.8370,
      bubbleRadius:0.0086,
      rowCountByColumn:[13,13,13,11],
      headerCutY:0.285,
      footerCutY:0.872
    },
    TBWS_CLASS_7_SET_B: {
      set:'B',
      pageType:'half',
      bubbleCentersX:[0.0747,0.1260,0.1763,0.2267, 0.3065,0.3568,0.4064,0.4560, 0.5374,0.5886,0.6381,0.6882, 0.7674,0.8178,0.8682,0.9186],
      firstRowY:0.3580,
      lastRowY:0.8370,
      bubbleRadius:0.0086,
      rowCountByColumn:[13,13,13,11],
      headerCutY:0.285,
      footerCutY:0.872
    }
  };

  const DEFAULT_CALIBRATION = JSON.parse(JSON.stringify(OMR_PROFILES));
  const STORAGE = {
    calibration:'tbws_p9_calibration_v1',
    results:'tbws_p9_results_v1'
  };

  const state = {
    stream:null,
    cameraRunning:false,
    openCVReady:false,
    autoScan:true,
    scanning:false,
    scanLocked:false,
    rafId:0,
    lastDetectionAt:0,
    lastFrameAt:0,
    stableFrames:0,needRemoval:false,absentFrames:0,holdReview:false,prevQuad:null,
    lastQuad:null,
    lastQuality:null,
    currentWarp:null,
    currentMode:null,
    selectedSet:'AUTO',resultSet:null,
    currentResults:null,
    currentStudent:null,
    currentScanId:null,
    saved:false,
    debugOverlay:false,
    batch:false,
    batchPaused:false,
    batchStats:{scanned:0,successful:0,review:0},
    debugLog:[],
    matsCreated:0,
    matsDeleted:0,
    calibration:loadCalibration()
  };

  const els = {
    reviewCount:$('p9-review-count'), liveBox:$('p9-live'), examCard:$('p9-exam'), examClass:$('p9-exam-class'), examSubject:$('p9-exam-subject'), examSection:$('p9-exam-section'), examDate:$('p9-exam-date'), examMsg:$('p9-exam-msg'), examStart:$('p9-exam-start'), examState:$('p9-exam-state'), sessPdf:$('p9-sess-pdf'), sessPage:$('p9-sess-page'), sessPrev:$('p9-sess-prev'), sessNext:$('p9-sess-next'), liveAuto:$('p9-live-auto'), liveCounts:$('p9-live-counts'), liveLast:$('p9-live-last'), liveStatus:$('p9-live-status'), sessSummary:$('p9-sess-summary'), sessBody:$('p9-sess-body'), sessReset:$('p9-sess-reset'), sessExport:$('p9-sess-export'), video:$('p9-video'), camera:$('p9-camera'), guide:$('p9-guide'), guideLabel:$('p9-guide-label'),
    chip:$('p9-detection-chip'), statusDot:$('p9-status-dot'), error:$('p9-camera-error'),
    scanBtn:$('p9-scan-btn'), autoToggle:$('p9-auto-toggle'), stopCamera:$('p9-stop-camera'),
    opencv:$('p9-opencv-state'), opencvRetry:$('p9-opencv-retry'), fps:$('p9-fps'), liveQuality:$('p9-quality-live'),
    startCamera:$('p9-start-camera'), galleryBtn:$('p9-gallery-btn'), galleryInput:$('p9-gallery-input'), uploadCanvas:$('p9-upload-canvas'),
    keyTarget:$('p9-key-target'), keyText:$('p9-key-text'), keyFile:$('p9-key-file'), keyFileBtn:$('p9-key-file-btn'), keyApply:$('p9-key-apply'), keyStatus:$('p9-key-status'), keyClear:$('p9-key-clear'), keyPreview:$('p9-key-preview'),
    setNote:$('p9-set-note'), setButtons:qsa('.set-btn'), batchToggle:$('p9-batch-toggle'),
    batchStats:$('p9-batch-stats'), batchCount:$('p9-batch-count'), batchSuccess:$('p9-batch-success'), batchReview:$('p9-batch-review'),
    pauseBatch:$('p9-pause-batch'), finishBatch:$('p9-finish-batch'), calibrate:$('p9-calibrate'),
    debugToggle:$('p9-debug-toggle'), debugPanelToggle:$('p9-debug-panel-toggle'), debugPanel:$('p9-debug-panel'),
    debugLog:$('p9-debug-log'), copyLog:$('p9-copy-log'), result:$('p9-result'), scoreNumber:$('p9-score-number'),
    scorePercent:$('p9-score-percent'), correct:$('p9-correct'), wrong:$('p9-wrong'), unattempted:$('p9-unattempted'), invalid:$('p9-invalid'),
    studentFields:$('p9-student-fields'), review:$('p9-review'), save:$('p9-save'), saveNext:$('p9-save-next'),
    exportCSV:$('p9-export-csv'), exportJSON:$('p9-export-json'), print:$('p9-print'), retake:$('p9-retake'),
    calibrationPanel:$('p9-calibration-panel'), closeCalibration:$('p9-close-calibration'), calGrid:$('p9-cal-grid'), calCanvas:$('p9-cal-canvas'),
    saveCal:$('p9-save-cal'), resetCal:$('p9-reset-cal'), resultCanvas:$('p9-result-canvas'), toast:$('p9-toast')
  };

  function debugLog(message, data='') {
    const line = `[${new Date().toLocaleTimeString()}] ${message}${data ? ` ${typeof data === 'string' ? data : JSON.stringify(data)}` : ''}`;
    state.debugLog.push(line);
    if(state.debugLog.length>300) state.debugLog.shift();
    if(els.debugLog) els.debugLog.textContent=state.debugLog.join('\n');
  }

  function validateProfile(p,name){
    const e=[],fin=(v,lo,hi)=>typeof v==='number'&&Number.isFinite(v)&&v>=lo&&v<=hi;
    if(!p||typeof p!=='object')return[`${name}: missing`];
    if(!fin(p.firstRowY,0.05,0.95))e.push(`${name}: First Row Y must be between 0.05 and 0.95`);
    if(!fin(p.lastRowY,0.05,0.98))e.push(`${name}: Last Row Y must be between 0.05 and 0.98`);
    if(fin(p.firstRowY,0,1)&&fin(p.lastRowY,0,1)&&!(p.lastRowY-p.firstRowY>=0.2))e.push(`${name}: Last Row Y must be at least 0.2 below First Row Y`);
    if(!fin(p.headerCutY,0,0.6))e.push(`${name}: Header Cut Y must be between 0 and 0.6`);
    if(!fin(p.footerCutY,0.5,1))e.push(`${name}: Footer Cut Y must be between 0.5 and 1`);
    if(fin(p.headerCutY,0,1)&&fin(p.firstRowY,0,1)&&!(p.headerCutY<p.firstRowY))e.push(`${name}: Header Cut Y must be above the first row`);
    if(fin(p.footerCutY,0,1)&&fin(p.lastRowY,0,1)&&!(p.footerCutY>p.lastRowY))e.push(`${name}: Footer Cut Y must be below the last row`);
    if(!fin(p.bubbleRadius,0.002,0.03))e.push(`${name}: Bubble Radius must be between 0.002 and 0.03`);
    if(!Array.isArray(p.rowCountByColumn)||p.rowCountByColumn.join()!=='13,13,13,11')e.push(`${name}: row counts must stay 13, 13, 13, 11`);
    const xs=p.bubbleCentersX;
    if(!Array.isArray(xs)||xs.length!==16||!xs.every(v=>fin(v,0.01,0.99)))e.push(`${name}: the 16 bubble X positions must all be numbers between 0.01 and 0.99`);
    else{for(let i=1;i<16;i++)if(!(xs[i]>xs[i-1])){e.push(`${name}: bubble X positions must increase from left to right`);break;}
      for(let c=0;c<4;c++){const g=[xs[c*4+1]-xs[c*4],xs[c*4+2]-xs[c*4+1],xs[c*4+3]-xs[c*4+2]];if(g.some(v=>v<0.02||v>0.09)){e.push(`${name}: options A-D in column ${c+1} are too close or too far apart`);break;}}}
    return e;
  }
  function validateCalibration(cal){
    const e=[];
    if(!cal||typeof cal!=='object')return['Calibration data is missing or not an object'];
    e.push(...validateProfile(cal.TBWS_CLASS_7_SET_A,'Set A'),...validateProfile(cal.TBWS_CLASS_7_SET_B,'Set B'));
    return e;
  }
  function validateThresholds(t){
    const fin=v=>typeof v==='number'&&Number.isFinite(v),e=[];
    if(!fin(t.minFill)||t.minFill<=0||t.minFill>=1)e.push('Min Fill Ratio must be between 0 and 1');
    if(!fin(t.strongFill)||t.strongFill<=0||t.strongFill>1)e.push('Strong Fill Ratio must be between 0 and 1');
    if(fin(t.minFill)&&fin(t.strongFill)&&t.strongFill<=t.minFill)e.push('Strong Fill Ratio must be higher than Min Fill Ratio');
    if(!fin(t.ambiguity)||t.ambiguity<=0||t.ambiguity>=0.5)e.push('Ambiguity Threshold must be between 0 and 0.5');
    return e;
  }
  function loadCalibration(){
    try{
      const raw=localStorage.getItem(STORAGE.calibration);
      if(!raw) return JSON.parse(JSON.stringify(DEFAULT_CALIBRATION));
      const saved=JSON.parse(raw),out=JSON.parse(JSON.stringify(DEFAULT_CALIBRATION));
      for(const k of ['TBWS_CLASS_7_SET_A','TBWS_CLASS_7_SET_B']){
        const merged={...DEFAULT_CALIBRATION[k],...(saved&&saved[k]&&typeof saved[k]==='object'?saved[k]:{})};
        if(validateProfile(merged,k).length===0)out[k]=merged;   // older/incomplete values are filled from defaults; broken ones fall back to the defaults
      }
      return out;
    }catch(e){return JSON.parse(JSON.stringify(DEFAULT_CALIBRATION));}
  }

  function saveCalibrationStore(){localStorage.setItem(STORAGE.calibration,JSON.stringify(state.calibration));}

  function showToast(message,ms=2600){
    els.toast.textContent=message;els.toast.classList.add('show');clearTimeout(showToast.t);
    showToast.t=setTimeout(()=>els.toast.classList.remove('show'),ms);
  }

  function showScanError(msg){
    els.error.textContent='⚠ Scan failed: '+msg;
    els.error.hidden=false;
    showToast('⚠ '+msg,7000);
    try{els.error.scrollIntoView({behavior:'smooth',block:'center'});}catch(_){}
  }

  function setStatus(type,label){
    els.statusDot.className='status-dot'+(type==='live'?' live':type==='error'?' error':'');
    els.chip.textContent=label;if(els.liveStatus)els.liveStatus.textContent=label;
    els.chip.classList.toggle('detected',type==='live');
  }

  const OPENCV_SOURCES=['https://docs.opencv.org/4.8.0/opencv.js','opencv.js'];
  const OPENCV_NEEDED=['Mat','matFromImageData','matFromArray','warpPerspective','findContours','cvtColor','threshold','adaptiveThreshold','Laplacian'];
  function opencvComplete(){return window.cv&&OPENCV_NEEDED.every(k=>typeof window.cv[k]==='function');}
  function loadOpenCV(){
    if(state.opencvLoading)return;state.opencvLoading=true;state.openCVReady=false;
    els.opencv.textContent='OpenCV: loading…';els.opencvRetry.hidden=true;els.startCamera.disabled=true;
    let idx=0;
    const done=()=>{state.opencvLoading=false;state.openCVReady=true;els.opencv.textContent='OpenCV: ready';els.opencvRetry.hidden=true;els.startCamera.disabled=false;debugLog('OpenCV ready; waiting for explicit camera start');renderAnswerKeyStatus();};
    const fail=why=>{state.opencvLoading=false;state.openCVReady=false;els.opencv.textContent='OpenCV: failed — '+why;els.opencvRetry.hidden=false;els.startCamera.disabled=true;handleAppError(new Error(why),'OpenCV');};
    const waitReady=(then)=>{const t0=Date.now();const poll=()=>{if(window.cv&&typeof window.cv.Mat==='function'){if(opencvComplete())done();else fail('incomplete OpenCV build');return;}if(Date.now()-t0>15000){then();return;}setTimeout(poll,100);};poll();};
    const tryNext=()=>{
      if(opencvComplete()){done();return;}
      if(idx>=OPENCV_SOURCES.length){fail('could not load OpenCV (check internet, or put opencv.js next to index.html)');return;}
      const old=document.getElementById('p9-opencv-script');if(old)old.remove();
      const sc=document.createElement('script');sc.id='p9-opencv-script';sc.async=true;sc.src=OPENCV_SOURCES[idx++];
      let settled=false;const timer=setTimeout(()=>{if(settled)return;settled=true;debugLog('OpenCV load timeout',sc.src);tryNext();},25000);
      sc.onload=()=>{if(settled)return;settled=true;clearTimeout(timer);waitReady(tryNext);};
      sc.onerror=()=>{if(settled)return;settled=true;clearTimeout(timer);debugLog('OpenCV load error',sc.src);tryNext();};
      document.head.appendChild(sc);
    };
    tryNext();
  }
  function waitForOpenCV(){loadOpenCV();}

  async function initCamera(){
    if(initCamera.busy)return false;initCamera.busy=true;
    try{return await initCameraInner();}finally{initCamera.busy=false;}
  }
  async function initCameraInner(){
    if(!requireExam())return;
    if(!state.openCVReady){showToast('OpenCV is still loading. Please wait.');return false;}
    if(state.stream) stopCamera();
    els.error.hidden=true;
    els.startCamera.disabled=true;
    els.scanBtn.disabled=true;
    if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
      showCameraError('Camera unavailable. Your browser does not provide MediaDevices camera access.');
      els.startCamera.disabled=false;
      return false;
    }
    if(location.protocol!=='https:' && location.hostname!=='localhost' && location.hostname!=='127.0.0.1'){
      showCameraError('HTTPS required. Open this scanner from a secure HTTPS page or localhost.');
      els.startCamera.disabled=false;
      return false;
    }
    let stream=null;
    try{
      try{
        stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:1920},height:{ideal:1080}},audio:false});
      }catch(primary){
        debugLog('Preferred camera constraints rejected; using fallback',primary&&primary.name||'unknown');
        stream=await navigator.mediaDevices.getUserMedia({video:true,audio:false});
      }
      state.stream=stream;
      state.cameraRunning=true;
      els.video.srcObject=stream;
      els.video.muted=true;
      els.video.playsInline=true;
      const playError=await els.video.play().catch(playErr=>{
        console.error('OMR camera video.play() failed:',playErr);
        debugLog('Video play() rejected',playErr&&playErr.name||'unknown');
        return playErr||new Error('Video playback rejected');
      });
      if(playError){
        stopCamera();
        showCameraError('Camera opened, but the browser blocked video playback. Tap Start Camera again or check browser autoplay/media permissions.');
        els.startCamera.disabled=false;
        return false;
      }
      if(els.video.paused){
        stopCamera();
        showCameraError('The camera stream is ready but video playback did not start. Tap Start Camera again.');
        els.startCamera.disabled=false;
        return false;
      }
      els.startCamera.textContent='↻ Restart Camera';
      els.scanBtn.disabled=false;
      setStatus('live','Camera ready');
      debugLog('Camera initialized after explicit user action');
      startDetectionLoop();
      return true;
    }catch(err){
      const name=err&&err.name||'';
      if(name==='NotAllowedError'||name==='SecurityError') showCameraError('Camera permission denied. Allow camera access in your browser settings and try again.');
      else if(name==='NotFoundError'||name==='DevicesNotFoundError') showCameraError('No camera found. Connect a camera and try again.');
      else if(name==='NotReadableError'||name==='TrackStartError') showCameraError('Camera unavailable. Another app may already be using the camera.');
      else showCameraError('Camera could not be started. Please check camera permissions and try again.');
      debugLog('Camera initialization failed',name);
      if(stream){try{stream.getTracks().forEach(t=>t.stop());}catch(_){}}
      stopCamera();
      els.startCamera.disabled=false;
      return false;
    }
  }

  function showCameraError(msg){
    state.cameraRunning=false;
    els.error.textContent=msg;
    els.error.hidden=false;
    setStatus('error','Camera error');
  }


  // Fractions of the real video frame. The guide is wider than the 1.414:1 half-A4 sheet needs, so a whole sheet always fits inside it.
  function guideGeometry(ar){const gw=.96,gh=Math.min(.94,Math.max(.3,gw*ar/1.1));return{gw,gh};}
  function applyCameraLayout(){
    const vw=els.video.videoWidth,vh=els.video.videoHeight;if(!vw||!vh)return;
    const ar=vw/vh,maxH=Math.max(260,window.innerHeight*.8);
    els.camera.style.aspectRatio=String(ar);els.camera.style.minHeight='0';els.camera.style.height='auto';
    els.camera.style.maxWidth=Math.round(maxH*ar)+'px';els.camera.style.marginInline='auto';
    const{gw,gh}=guideGeometry(ar);
    const g=els.guide.style;g.width=(gw*100)+'%';g.height=(gh*100)+'%';g.maxWidth='none';g.maxHeight='none';g.left=((1-gw)/2*100)+'%';g.top=((1-gh)/2*100)+'%';g.right='auto';g.bottom='auto';
    debugLog('Camera layout',{video:vw+'x'+vh,ratio:+ar.toFixed(3)});
  }

  function stopCamera(){
    state.needRemoval=false;state.holdReview=false;state.prevQuad=null;
    if(state.rafId) cancelAnimationFrame(state.rafId);
    state.rafId=0;
    if(state.stream){
      state.stream.getTracks().forEach(track=>{try{track.stop();}catch(_){}});
      state.stream=null;
    }
    if(els.video){els.video.pause();els.video.srcObject=null;}
    state.cameraRunning=false;
    state.stableFrames=0;
    state.lastQuad=null;
    if(els.scanBtn)els.scanBtn.disabled=true;
    if(els.startCamera){els.startCamera.disabled=!state.openCVReady;els.startCamera.textContent='▶ Start Camera';}
    setStatus('','Camera stopped');
    debugLog('Camera stopped');
  }

  function startAutoScan(){state.autoScan=true;els.autoToggle.classList.add('active');els.autoToggle.textContent='Auto Scan ON';els.autoToggle.setAttribute('aria-pressed','true');startDetectionLoop();renderSession();}
  function stopAutoScan(){state.autoScan=false;els.autoToggle.classList.remove('active');els.autoToggle.textContent='Auto Scan OFF';els.autoToggle.setAttribute('aria-pressed','false');state.stableFrames=0;renderSession();}

  function startDetectionLoop(){
    if(state.rafId) cancelAnimationFrame(state.rafId);
    let lastDetectionTick=0;
    const loop=(now)=>{
      state.rafId=requestAnimationFrame(loop);
      if(!state.cameraRunning||!state.openCVReady||state.scanning) return;
      if(now-lastDetectionTick<AUTO_SCAN_CONFIG.intervalMs) return;
      lastDetectionTick=now;
      const t=performance.now();
      let frame=null;
      try{
        frame=captureFrame(true);
        if(!frame) return;
        const detection=gridPresence(frame);
        if(detection){
          if(state.needRemoval){deleteMat(frame.mat);frame.mat=null;state.absentFrames=0;els.guideLabel.textContent='REMOVE SHEET';setStatus('live','REMOVE SHEET');return;}
          if(state.holdReview){deleteMat(frame.mat);frame.mat=null;els.guideLabel.textContent='Review the result, then press Save & Scan Next';return;}
          const pq=state.prevQuad,diag=Math.hypot(frame.width,frame.height),moved=pq?Math.max(...detection.quad.map((p,i)=>{const o=pq[i]||p;return Math.hypot(p.x-o.x,p.y-o.y);}))/diag:1;
          state.prevQuad=detection.quad;
          state.lastQuad=detection.quad;state.lastQuality=detection.quality;state.stableFrames=moved<.02?state.stableFrames+1:0;
          const detectedFull=detection.full;
          deleteMat(frame.mat);frame.mat=null;
          els.liveQuality.textContent=`Quality ${Math.round(detection.quality.score)}%`;
          els.guideLabel.textContent=detectedFull?'Show one half only (Set A or B)':(state.stableFrames>=3?'HOLD STEADY…':'SHEET CANDIDATE');
          els.setNote.textContent=state.selectedSet==='AUTO'
            ? (detectedFull?'Full page detected. Select Set A or Set B to choose the half to score.':'Half-page detected. Auto set detection enabled.')
            : (detectedFull?`Full page detected · Set ${state.selectedSet} selected.`:`Half-page detected · Set ${state.selectedSet} selected.`);
          setStatus('live',detectedFull?'ONE HALF ONLY':(state.stableFrames>=3?'HOLD STEADY…':'SHEET CANDIDATE'));
          if(state.autoScan && !detectedFull && state.stableFrames>=AUTO_SCAN_CONFIG.stableFramesRequired && performance.now()-state.lastDetectionAt>AUTO_SCAN_CONFIG.cooldownMs){
            state.lastDetectionAt=performance.now();captureAndAnalyze();
          }
        }else{
          deleteMat(frame.mat);frame.mat=null;state.prevQuad=null;
          if(state.needRemoval&&++state.absentFrames>=2){state.needRemoval=false;state.absentFrames=0;setStatus('live','READY FOR NEXT');}
          state.stableFrames=0;els.guideLabel.textContent=state.needRemoval?'REMOVE SHEET':'Align OMR inside the frame';setStatus('live',state.needRemoval?'REMOVE SHEET':'SEARCHING FOR OMR');
        }
        const dt=performance.now()-t;els.fps.textContent=`CV ${Math.round(1000/Math.max(dt,1))} fps`;
      }catch(err){debugLog('Detection error',err.message);state.stableFrames=0;}
      finally{if(frame&&frame.mat)deleteMat(frame.mat);}
    };
    state.rafId=requestAnimationFrame(loop);
  }

  // Ownership: the returned `mat` belongs to the caller. Every caller deletes it in a finally/cleanup path.
  function captureFrame(lowRes=false){
    if(!els.video.videoWidth||!els.video.videoHeight) return null;
    const maxW=lowRes?400:Math.max(1280,els.video.videoWidth);
    const scale=Math.min(1,maxW/els.video.videoWidth);
    const w=Math.round(els.video.videoWidth*scale),h=Math.round(els.video.videoHeight*scale);
    const canvas=$('p9-detection-canvas');canvas.width=w;canvas.height=h;const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(els.video,0,0,w,h);
    const rgba=ctx.getImageData(0,0,w,h);const mat=cv.matFromImageData(rgba);state.matsCreated++;return {mat,width:w,height:h,canvas};
  }

  function detectDocument(src,width,height){
    let gray=null,blur=null,edges=null,kernel=null,closed=null,contours=null,hierarchy=null;
    try{
      gray=new cv.Mat();blur=new cv.Mat();edges=new cv.Mat();kernel=cv.getStructuringElement(cv.MORPH_RECT,new cv.Size(5,5));closed=new cv.Mat();contours=new cv.MatVector();hierarchy=new cv.Mat();
      cv.cvtColor(src,gray,cv.COLOR_RGBA2GRAY);cv.GaussianBlur(gray,blur,new cv.Size(5,5),0);cv.Canny(blur,edges,60,160);cv.morphologyEx(edges,closed,cv.MORPH_CLOSE,kernel,new cv.Point(-1,-1),2);cv.findContours(closed,contours,hierarchy,cv.RETR_LIST,cv.CHAIN_APPROX_SIMPLE);
      const frameArea=width*height;let best=null;
      for(let i=0;i<contours.size();i++){
        let c=null,approx=null;
        try{
          c=contours.get(i);const peri=cv.arcLength(c,true);if(!peri)continue;approx=new cv.Mat();cv.approxPolyDP(c,approx,0.025*peri,true);const area=Math.abs(cv.contourArea(approx));
          if(approx.rows!==4||area/frameArea<AUTO_SCAN_CONFIG.minDocumentAreaRatio)continue;
          const pts=[];for(let j=0;j<4;j++)pts.push({x:approx.data32S[j*2],y:approx.data32S[j*2+1]});const valid=validateQuadrilateral(pts,width,height);
          if(valid.ok&&(!best||valid.score>best.score))best={quad:pts,score:valid.score,quality:quickFrameQuality(gray,area/frameArea,valid.perspective)};
        }finally{deleteMat(approx);deleteMat(c);}
      }
      return best;
    }finally{[gray,blur,edges,kernel,closed,contours,hierarchy].forEach(deleteMat);}
  }

  function validateQuadrilateral(points,w,h){
    if(points.length!==4) return {ok:false,score:0};
    const p=sortCorners(points);const sides=[dist(p[0],p[1]),dist(p[1],p[2]),dist(p[2],p[3]),dist(p[3],p[0])];
    const long=(sides[0]+sides[2])/2,short=(sides[1]+sides[3])/2;const ratio=long/Math.max(short,1);const area=polygonArea(p)/(w*h);const angles=p.map((_,i)=>cornerAngle(p[(i+3)%4],p[i],p[(i+1)%4]));
    const angleErr=angles.reduce((a,v)=>a+Math.abs(v-90),0)/4;const convex=polygonConvex(p);const reasonable=ratio>1.15&&ratio<2.2||ratio>.45&&ratio<.87;
    const perspective=Math.max(...sides)/Math.max(Math.min(...sides),1);const ok=convex&&area>=AUTO_SCAN_CONFIG.minDocumentAreaRatio&&reasonable&&angleErr<32&&perspective<QUALITY_CONFIG.maxPerspectiveRatio;
    const score=Math.max(0,100-(angleErr*1.3)-(perspective-1)*18)+area*30;
    return {ok,score,perspective};
  }

  function quickFrameQuality(gray,coverage,perspective){
    const mean=cv.mean(gray)[0];let lap=null;
    try{lap=new cv.Mat();cv.Laplacian(gray,lap,cv.CV_64F);const sharp=meanStd(lap).std**2;const contrast=meanStd(gray).std;const brightnessScore=Math.max(0,100-Math.abs(mean-145)*.75);const sharpScore=Math.min(100,(sharp/180)*100);const contrastScore=Math.min(100,(contrast/55)*100);return {sharpness:sharp,brightness:mean,contrast,coverage,perspective,score:Math.max(0,Math.min(100,sharpScore*.45+brightnessScore*.25+contrastScore*.2+Math.min(100,coverage*100)*.1))};}finally{deleteMat(lap);}
  }

  function polygonConvex(p){let sign=0;for(let i=0;i<4;i++){const a=p[i],b=p[(i+1)%4],c=p[(i+2)%4];const z=(b.x-a.x)*(c.y-b.y)-(b.y-a.y)*(c.x-b.x);if(Math.abs(z)<1e-5)continue;if(!sign)sign=Math.sign(z);else if(sign!==Math.sign(z))return false;}return true}
  function polygonArea(p){let a=0;for(let i=0;i<p.length;i++){const q=p[(i+1)%p.length];a+=p[i].x*q.y-q.x*p[i].y}return Math.abs(a)/2}
  function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}
  function cornerAngle(a,b,c){const ab={x:a.x-b.x,y:a.y-b.y},cb={x:c.x-b.x,y:c.y-b.y};const den=Math.hypot(ab.x,ab.y)*Math.hypot(cb.x,cb.y)||1;return Math.acos(Math.max(-1,Math.min(1,(ab.x*cb.x+ab.y*cb.y)/den)))*180/Math.PI}
  function sortCorners(points){
    if(!Array.isArray(points)||points.length!==4)return [];
    const cx=points.reduce((s,p)=>s+p.x,0)/4,cy=points.reduce((s,p)=>s+p.y,0)/4;
    const ordered=[...points].map(p=>({x:Number(p.x),y:Number(p.y)}))
      .sort((a,b)=>Math.atan2(a.y-cy,a.x-cx)-Math.atan2(b.y-cy,b.x-cx));
    let start=0,best=Infinity;
    ordered.forEach((p,i)=>{const key=p.x+p.y;if(key<best){best=key;start=i;}});
    return ordered.slice(start).concat(ordered.slice(0,start));
  }
  const deletedMats = new WeakSet();
  function deleteMat(m){
    if(!m || typeof m.delete!=='function' || deletedMats.has(m)) return;
    // OpenCV.js does not expose one consistent public `isDeleted` property
    // across all 4.x builds, so WeakSet is the primary guard. If a build does
    // expose a deletion flag, respect it as an additional safety check.
    try{
      if(m.isDeleted===true || m.deleted===true) { deletedMats.add(m); return; }
    }catch(_){ /* ignore */ }
    try{
      m.delete();
      deletedMats.add(m);
      state.matsDeleted++;
    }catch(_){
      // Never let cleanup throw during batch processing.
      deletedMats.add(m);
    }
  }

  function meanStd(mat){
    let m=null,sd=null;
    try{m=new cv.Mat();sd=new cv.Mat();cv.meanStdDev(mat,m,sd);return {mean:m.data64F[0],std:sd.data64F[0]};}
    finally{deleteMat(m);deleteMat(sd);}
  }

  function wholeImageDetection(mat,w,h){
    let gray=null;
    try{
      gray=new cv.Mat();cv.cvtColor(mat,gray,cv.COLOR_RGBA2GRAY);
      return {quad:[{x:0,y:0},{x:w-1,y:0},{x:w-1,y:h-1},{x:0,y:h-1}],score:100,quality:quickFrameQuality(gray,1,1)};
    }finally{deleteMat(gray);}
  }

  /* ---------- Grid registration: finds the printed bubble grid itself, so paper edges / rotation do not matter ---------- */
  function solveLinear(A,b){const n=b.length;for(let i=0;i<n;i++){let m=i;for(let r=i+1;r<n;r++)if(Math.abs(A[r][i])>Math.abs(A[m][i]))m=r;[A[i],A[m]]=[A[m],A[i]];[b[i],b[m]]=[b[m],b[i]];if(Math.abs(A[i][i])<1e-12)return null;for(let r=i+1;r<n;r++){const f=A[r][i]/A[i][i];for(let c=i;c<n;c++)A[r][c]-=f*A[i][c];b[r]-=f*b[i];}}const x=new Array(n);for(let i=n-1;i>=0;i--){let s=b[i];for(let c=i+1;c<n;c++)s-=A[i][c]*x[c];x[i]=s/A[i][i];}return x;}
  function fitHomography(src,dst){
    const norm=pts=>{const n=pts.length;let cx=0,cy=0;pts.forEach(p=>{cx+=p[0];cy+=p[1];});cx/=n;cy/=n;let d=0;pts.forEach(p=>d+=Math.hypot(p[0]-cx,p[1]-cy));d=d/n||1;const s=Math.SQRT2/d;return{s,cx,cy,pts:pts.map(p=>[(p[0]-cx)*s,(p[1]-cy)*s])};};
    const S=norm(src),D=norm(dst),AtA=Array.from({length:8},()=>new Array(8).fill(0)),Atb=new Array(8).fill(0);
    const add=(r,v)=>{for(let i=0;i<8;i++){Atb[i]+=r[i]*v;for(let j=0;j<8;j++)AtA[i][j]+=r[i]*r[j];}};
    for(let i=0;i<S.pts.length;i++){const[x,y]=S.pts[i],[u,v]=D.pts[i];add([x,y,1,0,0,0,-u*x,-u*y],u);add([0,0,0,x,y,1,-v*x,-v*y],v);}
    const h=solveLinear(AtA,Atb);if(!h)return null;
    const Hn=[h[0],h[1],h[2],h[3],h[4],h[5],h[6],h[7],1];
    const Ts=[S.s,0,-S.cx*S.s,0,S.s,-S.cy*S.s,0,0,1],Td=[1/D.s,0,D.cx,0,1/D.s,D.cy,0,0,1];
    return mul3(Td,mul3(Hn,Ts));
  }
  function fitAffine(src,dst){
    const M=[[0,0,0],[0,0,0],[0,0,0]],bx=[0,0,0],by=[0,0,0];
    for(let i=0;i<src.length;i++){const r=[src[i][0],src[i][1],1];for(let a=0;a<3;a++){bx[a]+=r[a]*dst[i][0];by[a]+=r[a]*dst[i][1];for(let b=0;b<3;b++)M[a][b]+=r[a]*r[b];}}
    const cx=solveLinear(M.map(r=>r.slice()),bx.slice()),cy=solveLinear(M.map(r=>r.slice()),by.slice());
    return cx&&cy?[cx[0],cx[1],cx[2],cy[0],cy[1],cy[2],0,0,1]:null;
  }
  function mul3(a,b){const o=new Array(9).fill(0);for(let i=0;i<3;i++)for(let j=0;j<3;j++)for(let k=0;k<3;k++)o[i*3+j]+=a[i*3+k]*b[k*3+j];return o;}
  function applyH(H,x,y){const w=H[6]*x+H[7]*y+H[8];return[(H[0]*x+H[1]*y+H[2])/w,(H[3]*x+H[4]*y+H[5])/w];}
  function invert3(m){const[a,b,c,d,e,f,g,h,i]=m,A=e*i-f*h,B=-(d*i-f*g),C=d*h-e*g,det=a*A+b*B+c*C;if(Math.abs(det)<1e-14)return null;return[A/det,-(b*i-c*h)/det,(b*f-c*e)/det,B/det,(a*i-c*g)/det,-(a*f-c*d)/det,C/det,-(a*h-b*g)/det,(a*e-b*d)/det];}

  function bubbleCandidates(gray,w,h){
    const I=new Float64Array((w+1)*(h+1));
    for(let y=0;y<h;y++){let row=0;for(let x=0;x<w;x++){row+=gray[y*w+x];I[(y+1)*(w+1)+x+1]=I[y*(w+1)+x+1]+row;}}
    const half=Math.max(8,Math.round(Math.min(w,h)/36)),mask=new Uint8Array(w*h);
    for(let y=0;y<h;y++){const y0=Math.max(0,y-half),y1=Math.min(h,y+half+1);for(let x=0;x<w;x++){const x0=Math.max(0,x-half),x1=Math.min(w,x+half+1);const sum=I[y1*(w+1)+x1]-I[y0*(w+1)+x1]-I[y1*(w+1)+x0]+I[y0*(w+1)+x0];if(gray[y*w+x]<sum/((x1-x0)*(y1-y0))-22)mask[y*w+x]=1;}}
    const seen=new Uint8Array(w*h),stack=[],comps=[],wide=[];
    for(let s=0;s<w*h;s++){if(!mask[s]||seen[s])continue;let minx=w,maxx=0,miny=h,maxy=0,area=0,sx=0,sy=0;stack.length=0;stack.push(s);seen[s]=1;
      while(stack.length){const p=stack.pop(),x=p%w,y=(p/w)|0;area++;sx+=x;sy+=y;if(x<minx)minx=x;if(x>maxx)maxx=x;if(y<miny)miny=y;if(y>maxy)maxy=y;
        if(x>0&&mask[p-1]&&!seen[p-1]){seen[p-1]=1;stack.push(p-1);}if(x<w-1&&mask[p+1]&&!seen[p+1]){seen[p+1]=1;stack.push(p+1);}
        if(y>0&&mask[p-w]&&!seen[p-w]){seen[p-w]=1;stack.push(p-w);}if(y<h-1&&mask[p+w]&&!seen[p+w]){seen[p+w]=1;stack.push(p+w);}}
      const bw=maxx-minx+1,bh=maxy-miny+1;
      if(bw>=5&&bw<=90&&bh>=5&&bh<=90&&bw/bh>.8&&bw/bh<1.25&&area/(bw*bh)>.12&&area/(bw*bh)<.92)comps.push({x:(minx+maxx)/2,y:(miny+maxy)/2,s:(bw+bh)/2});
      else if(bh>=5&&bh<=90&&bw/bh>=1.25&&bw/bh<=3.4&&area>=bh*bh*.5)wide.push({x:(minx+maxx)/2,y:(miny+maxy)/2,h:bh,w:bw});}
    if(comps.length<20)return[];
    const sizes=comps.map(c=>c.s).sort((a,b)=>a-b),med=sizes[sizes.length>>1];
    const out=comps.filter(c=>c.s>med*.75&&c.s<med*1.3);out.wide=wide.filter(c=>c.h>med*.7&&c.h<med*1.4);return out;
  }

  function registerGrid(gray,w,h,profile,hint){
    const C=bubbleCandidates(gray,w,h);if(C.length<40)return null;
    if(C.length>330){C.ambiguous=true;return{ambiguous:true,inliers:0,candidates:C.length};}
    const tpl=[],W=OMR_CONFIG.targetWidth,H=OMR_CONFIG.targetHeightHalf;
    profile.rowCountByColumn.forEach((rows,c)=>{for(let r=0;r<rows;r++){const y=rowY(profile,r)*H;for(let k=0;k<4;k++)tpl.push([profile.bubbleCentersX[c*4+k]*W,y]);}});
    const pitchT=(profile.lastRowY-profile.firstRowY)/Math.max(1,Math.max(...profile.rowCountByColumn)-1)*H;
    // nearest-neighbour vectors -> vertical pitch direction and scale
    const nn=[];for(let i=0;i<C.length;i++){let best=1e9,bj=-1;for(let j=0;j<C.length;j++){if(i===j)continue;const d=Math.hypot(C[i].x-C[j].x,C[i].y-C[j].y);if(d<best){best=d;bj=j;}}nn.push({d:best,a:Math.atan2(C[bj].y-C[i].y,C[bj].x-C[i].x)});}
    const ds=nn.map(n=>n.d).sort((a,b)=>a-b),dm=ds[ds.length>>1];let sx=0,sy=0;
    nn.forEach(n=>{if(n.d>dm*.8&&n.d<dm*1.25){sx+=Math.cos(2*n.a);sy+=Math.sin(2*n.a);}});
    const thv=Math.atan2(sy,sx)/2,scale=dm/pitchT;let best=null;
    const refine=H0=>{
      let Hc=H0,inl=0;
      const maxX=Math.max(...tpl.map(q=>q[0])),
        plan=[[.30,.5,0],[.30,.4,0],[.52,.5,0],[.52,.4,0],[.72,.5,1],[.72,.4,1],[2,.5,1],[2,.4,1],[2,.3,1],[2,.25,1],[2,.2,1]];
      for(const[lim,fr,hom]of plan){
        const tol=dm*fr,src=[],dst=[];
        for(const q of tpl){if(q[0]>lim*W)continue;const[px,py]=applyH(Hc,q[0],q[1]);let bd=tol,bc=null;for(const c of C){const d=Math.hypot(c.x-px,c.y-py);if(d<bd){bd=d;bc=c;}}if(bc){src.push(q);dst.push([bc.x,bc.y]);}}
        if(src.length<12)return null;inl=src.length;
        const Hn=(hom&&src.length>=24)?fitHomography(src,dst):fitAffine(src,dst);if(!Hn)return null;Hc=Hn;
      }
      return{H:Hc,inliers:inl};
    };
    const buildTrials=()=>{const trials=[];
    for(const base of [thv-Math.PI/2,thv+Math.PI/2])for(const ds of [-.06,-.03,0,.03,.06])for(const da of [-.05,-.025,0,.025,.05]){
      const phi=base+da,sc=scale*(1+ds),cs=Math.cos(phi)*sc,sn=Math.sin(phi)*sc,cell=dm*.4,votes=new Map();
      for(const q of tpl){if(q[0]>.55*W)continue;const rx=cs*q[0]-sn*q[1],ry=sn*q[0]+cs*q[1];for(const c of C){const kx=Math.round((c.x-rx)/cell),ky=Math.round((c.y-ry)/cell);const key=kx*100003+ky;votes.set(key,(votes.get(key)||0)+1);}}
      let top=null;votes.forEach((v,k)=>{if(!top||v>top.v)top={k,v};});
      if(!top)continue;const ky=((top.k%100003)+100003+50001)%100003-50001,kx=Math.round((top.k-ky)/100003);
      trials.push({v:top.v,H:[cs,-sn,kx*cell,sn,cs,ky*cell,0,0,1]});
    }
    trials.sort((a,b)=>b.v-a.v);return trials;};
    const hits=(Hc,pts)=>{let n=0;for(const q of pts){const[px,py]=applyH(Hc,q[0],q[1]);if(C.some(c=>Math.hypot(c.x-px,c.y-py)<dm*.4))n++;}return n;};
    const sorted=Array.from(gray.length>200000?gray.filter((_,i)=>i%7===0):gray).sort((p,q)=>p-q),paper=sorted[sorted.length>>1];
    const numberHits=Hc=>{let n=0;for(let g=0;g<4;g++)for(let r=0;r<profile.rowCountByColumn[g];r++){const y=rowY(profile,r)*H,x0=profile.bubbleCentersX[g*4]*W;let dark=0;
      for(let i=0;i<5;i++)for(let j=0;j<3;j++){const[px,py]=applyH(Hc,x0-60+i*9,y-8+j*8),ix=Math.round(px),iy=Math.round(py);if(ix>=0&&iy>=0&&ix<w&&iy<h&&paper-gray[iy*w+ix]>60)dark++;}
      if(dark>=3)n++;}return n;};
    const groupHits=(Hc,g)=>{let n=0;for(const q of tpl){if(Math.abs(q[0]-profile.bubbleCentersX[g*4+1]*W)>W*.12)continue;const[px,py]=applyH(Hc,q[0],q[1]);if(C.some(c=>Math.hypot(c.x-px,c.y-py)<dm*.3))n++;}return n;};
    let hinted=false;
    if(hint){const hr=refine(hint);if(hr&&hr.inliers>=tpl.length*.7){hr.orient=numberHits(hr.H);if(hr.orient>=20){best=hr;hinted=true;}}}
    for(const t of (hinted?[]:buildTrials()).slice(0,30)){
      const r=refine(t.H);if(!r)continue;
      r.orient=numberHits(r.H);r.score=r.inliers+2*r.orient;
      if(!best||r.score>best.score)best=r;
      if(best.inliers>=tpl.length*.7&&best.orient>=20)break;
    }
    if(!best)return null;
    // rows are periodic: try +-2 row shifts and keep the one where printed numbers + bubbles line up best
    const matched=Hc=>{let n=0;for(const q of tpl){const[px,py]=applyH(Hc,q[0],q[1]);if(C.some(c=>Math.hypot(c.x-px,c.y-py)<dm*.3))n++;}return n;};
    let bestShift=null;
    for(const sh of [-2,-1,0,1,2]){
      const Hs=mul3(best.H,[1,0,0,0,1,sh*pitchT,0,0,1]),sc=matched(Hs)+numberHits(Hs)*1.5;
      if(!bestShift||sc>bestShift.sc)bestShift={sc,H:Hs,sh};
    }
    if(bestShift.sh!==0){const r=refine(bestShift.H);if(r)best={...best,H:r.H,inliers:r.inliers};}
    const Hc=best.H,inl=best.inliers;
    return{H:Hc,inliers:inl,orient:best.orient,total:tpl.length,candidates:C.length,pitch:dm};
  }

  function toWorkingGray(imageData,width,height){
    const longSide=Math.max(width,height),k=Math.max(1,longSide/1000),w=Math.round(width/k),h=Math.round(height/k),out=new Uint8Array(w*h),d=imageData.data;
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){let sum=0,n=0;for(let j=0;j<3;j++)for(let i=0;i<3;i++){const sx=Math.min(width-1,Math.floor((x+(i+.5)/3)*k)),sy=Math.min(height-1,Math.floor((y+(j+.5)/3)*k)),o=(sy*width+sx)*4;sum+=d[o]*.299+d[o+1]*.587+d[o+2]*.114;n++;}out[y*w+x]=sum/n;}
    return{gray:out,w,h,k};
  }
  function tryRegisterGrid(imageData,width,height){
    try{
      const g=toWorkingGray(imageData,width,height),prof=state.calibration.TBWS_CLASS_7_SET_A,r=registerGrid(g.gray,g.w,g.h,prof,state.lastRegH);
      if(r&&r.ambiguous){debugLog('Layout not detected: both sets visible; select a set and capture one half');return null;}
      if(!r||r.inliers<60){debugLog('Grid registration failed',r?{inliers:r.inliers}:'no grid');return null;}
      setStatus('live','GRID REGISTERED');state.lastRegH=r.H.slice();const f=g.k;r.Hfull=[r.H[0]*f,r.H[1]*f,r.H[2]*f,r.H[3]*f,r.H[4]*f,r.H[5]*f,r.H[6],r.H[7],r.H[8]];
      debugLog('Grid registration ok',{inliers:r.inliers,candidates:r.candidates});return r;
    }catch(e){debugLog('Grid registration error',String(e&&e.stack||e));return null;}
  }
  function warpByGrid(imageData,Hfull){
    let src=null,dst=null,M=null;
    try{
      src=cv.matFromImageData(imageData);state.matsCreated++;
      const inv=invert3(Hfull);if(!inv)return null;
      M=cv.matFromArray(3,3,cv.CV_64FC1,inv);dst=new cv.Mat();
      cv.warpPerspective(src,dst,M,new cv.Size(OMR_CONFIG.targetWidth,OMR_CONFIG.targetHeightHalf),cv.INTER_LINEAR,cv.BORDER_CONSTANT,new cv.Scalar(255,255,255,255));
      const out=dst;dst=null;return{mat:out};
    }finally{[src,dst,M].forEach(deleteMat);}
  }


  /* ---------- Exam (session-level) details ---------- */
  const EXAM_KEY='p9_exam_v1';
  function todayISO(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
  function fmtDate(iso){const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(iso||'');return m?`${m[3]}/${m[2]}/${m[1]}`:(iso||'');}
  const exam=(()=>{try{const j=JSON.parse(localStorage.getItem(EXAM_KEY)||'null');if(j&&typeof j==='object')return Object.assign({className:'',subject:'',section:'',date:todayISO(),started:false},j);}catch(_){}return{className:'',subject:'',section:'',date:todayISO(),started:false};})();
  function examReady(){return !!(exam.started&&exam.className&&exam.subject&&exam.section&&exam.date);}
  function requireExam(){if(examReady())return true;showToast('Fill Exam Details and press START SCANNING first',4000);try{els.examCard.scrollIntoView({behavior:'smooth',block:'center'});}catch(_){}return false;}
  function renderExam(){
    els.examClass.value=exam.className;els.examSubject.value=exam.subject;els.examSection.value=exam.section;els.examDate.value=exam.date;
    els.examStart.textContent=examReady()?'UPDATE DETAILS':'START SCANNING';
    els.examState.textContent=examReady()?'✓ Session active':'Required before scanning';els.examState.classList.toggle('ok',examReady());
  }
  async function applyExam(){
    const v={className:els.examClass.value.trim(),subject:els.examSubject.value.trim(),section:els.examSection.value.trim(),date:els.examDate.value};
    const miss=[['className','Class'],['subject','Subject'],['section','Section'],['date','Date']].filter(([k])=>!v[k]).map(([,l])=>l);
    if(miss.length){els.examMsg.textContent='Please fill: '+miss.join(', ');els.examMsg.hidden=false;return;}
    if(applyExam.busy)return;applyExam.busy=true;
    try{
      els.examMsg.hidden=true;Object.assign(exam,v,{started:true});
      try{localStorage.setItem(EXAM_KEY,JSON.stringify(exam));}catch(e){handleAppError(e,'save exam details');}
      if(state.currentStudent)Object.assign(state.currentStudent,{className:exam.className,subject:exam.subject,section:exam.section,date:fmtDate(exam.date)});
      renderExam();
      const changed=session.rows.filter(r=>r.className!==exam.className||r.subject!==exam.subject||r.section!==exam.section||r.date!==exam.date);
      changed.forEach(r=>Object.assign(r,{className:exam.className,subject:exam.subject,section:exam.section,date:exam.date,updatedAt:Date.now()}));
      let bad=0;
      for(let i=0;i<changed.length;i+=50){const batch=changed.slice(i,i+50);const res=await Promise.all(batch.map(r=>flushRow(r,true)));bad+=res.filter(x=>!x).length;if(changed.length>50)showToast(`Updating records… ${Math.min(i+50,changed.length)}/${changed.length}`,1500);await new Promise(r=>setTimeout(r,0));}
      renderSession();
      showToast(bad?`⚠ Exam details saved, but ${bad} record(s) could not be updated — use Retry Save`:'Exam details saved — applies to all students',bad?7000:2600);
    }finally{applyExam.busy=false;}
  }

  /* ---------- School settings (multi-school) ----------
     Stored in its own localStorage key — never mixed with student records (IndexedDB) or exam/answer-key/calibration keys.
     "eGyan Classes" is the software brand; the school below is the customer identity shown on reports. */
  const SCHOOL_KEY='p9_school_v1',SCHOOL_LIM={name:80,address:200,contact:120,logo:150000};
  const cleanText=(v,max)=>String(v==null?'':v).replace(/[\u0000-\u001f\u007f]+/g,' ').replace(/\s+/g,' ').trim().slice(0,max);
  const validLogo=v=>typeof v==='string'&&v.length<=SCHOOL_LIM.logo&&/^data:image\/(png|jpeg);base64,[A-Za-z0-9+\/=]+$/.test(v);
  function normalizeSchool(o){o=o&&typeof o==='object'&&!Array.isArray(o)?o:{};return{name:cleanText(o.name,SCHOOL_LIM.name),address:cleanText(o.address,SCHOOL_LIM.address),contact:cleanText(o.contact,SCHOOL_LIM.contact),logo:validLogo(o.logo)?o.logo:''};}
  function validateSchoolName(v){
    const n=cleanText(v,500);
    if(!n)return 'School Name is required';
    if(n.length<2)return 'School Name must be at least 2 characters';
    if(n.length>SCHOOL_LIM.name)return `School Name must be ${SCHOOL_LIM.name} characters or fewer`;
    if(!/[\p{L}\p{N}]/u.test(n))return 'School Name must contain letters or numbers';
    if(/[<>]/.test(n))return 'School Name cannot contain < or >';
    return '';
  }
  function loadSchool(){try{const raw=localStorage.getItem(SCHOOL_KEY);if(raw)return normalizeSchool(JSON.parse(raw));}catch(_){}return normalizeSchool(null);}
  let school=loadSchool(),schoolDraftLogo='';
  const schoolReady=()=>!validateSchoolName(school.name);
  function persistSchool(next){try{localStorage.setItem(SCHOOL_KEY,JSON.stringify(next));school=next;return true;}catch(e){handleAppError(e,'save school settings');return false;}}
  function renderSchoolHeader(){
    const ok=schoolReady(),n=$('p9-school-name'),a=$('p9-school-address'),c=$('p9-school-contact'),lg=$('p9-school-logo'),st=$('p9-school-state');
    n.textContent=ok?school.name:'School name not set';n.classList.toggle('unset',!ok);
    a.textContent=school.address;a.hidden=!school.address;c.textContent=school.contact;c.hidden=!school.contact;
    if(school.logo){lg.src=school.logo;lg.hidden=false;}else{lg.removeAttribute('src');lg.hidden=true;}
    $('p9-school-setup').hidden=ok;
    if(typeof renderOmrGen==='function')renderOmrGen();
    st.textContent=ok?'✓ Configured':'Not configured';st.classList.toggle('ok',ok);
  }
  function drawSchoolLogoPreview(){
    const im=$('p9-school-in-logo-prev'),em=$('p9-school-in-logo-empty'),cl=$('p9-school-logo-clear');
    if(schoolDraftLogo){im.src=schoolDraftLogo;im.hidden=false;em.hidden=true;cl.hidden=false;}else{im.removeAttribute('src');im.hidden=true;em.hidden=false;cl.hidden=true;}
  }
  function fillSchoolForm(){
    $('p9-school-in-name').value=school.name;$('p9-school-in-address').value=school.address;$('p9-school-in-contact').value=school.contact;
    schoolDraftLogo=school.logo;drawSchoolLogoPreview();$('p9-school-msg').hidden=true;
  }
  /* Logo is resized on a canvas (max 256 px) so it stays small in localStorage and in every PDF */
  function prepareLogo(file){return new Promise((res,rej)=>{
    if(!file)return rej(new Error('No file selected'));
    if(!/^image\/(png|jpeg|webp)$/.test(file.type))return rej(new Error('Choose a PNG or JPG image'));
    if(file.size>8*1024*1024)return rej(new Error('Image is too large (maximum 8 MB)'));
    const url=URL.createObjectURL(file),im=new Image();
    im.onload=()=>{
      try{
        let max=256;
        for(let t=0;t<4;t++){
          const k=Math.min(1,max/Math.max(im.naturalWidth,im.naturalHeight)),w=Math.max(1,Math.round(im.naturalWidth*k)),h=Math.max(1,Math.round(im.naturalHeight*k)),c=document.createElement('canvas');
          c.width=w;c.height=h;const g=c.getContext('2d');let out='';
          if(file.type!=='image/jpeg'){g.drawImage(im,0,0,w,h);out=c.toDataURL('image/png');}
          if(!validLogo(out)){g.clearRect(0,0,w,h);g.fillStyle='#fff';g.fillRect(0,0,w,h);g.drawImage(im,0,0,w,h);out=c.toDataURL('image/jpeg',0.88);}
          if(validLogo(out)){res(out);return;}
          max=Math.round(max*0.7);
        }
        rej(new Error('Logo is too detailed — use a simpler or smaller image'));
      }catch(e){rej(e);}finally{URL.revokeObjectURL(url);}
    };
    im.onerror=()=>{URL.revokeObjectURL(url);rej(new Error('This image could not be read'));};
    im.src=url;
  });}
  function saveSchoolFromForm(){
    const msg=$('p9-school-msg'),name=cleanText($('p9-school-in-name').value,500),err=validateSchoolName(name);
    if(err){msg.textContent=err;msg.hidden=false;$('p9-school-in-name').focus();return false;}
    const next=normalizeSchool({name,address:$('p9-school-in-address').value,contact:$('p9-school-in-contact').value,logo:schoolDraftLogo});
    if(!persistSchool(next)){msg.textContent='School settings could not be saved on this device (storage full or blocked). Try a smaller logo.';msg.hidden=false;return false;}
    renderSchoolHeader();fillSchoolForm();showToast('✓ School settings saved');return true;
  }
  /* Final reports need a school name: ask once, save it, then continue */
  function ensureSchoolForReport(){
    if(schoolReady())return Promise.resolve(true);
    return new Promise(resolve=>{
      const m=modal(`<h3>SCHOOL NAME REQUIRED</h3><div class="modal-body"><p>The school name is printed in the header of every report. Enter it once — it is saved in School Settings and you can change it any time.</p><label class="school-ask">School Name<input id="p9-school-ask" type="text" maxlength="80" autocomplete="organization" placeholder="e.g. THE BETTER WORLD SCHOOL"></label><p id="p9-school-ask-err" class="p9-error" hidden></p></div><div class="modal-actions"><button class="p9-btn" data-r="cancel" type="button">Cancel</button><button class="p9-btn primary" data-r="ok" type="button">Save &amp; Continue</button></div>`);
      const inp=m.querySelector('#p9-school-ask'),er=m.querySelector('#p9-school-ask-err');
      const done=ok=>{closeModal();if(!ok)showToast('School Name is required to create a report',4000);resolve(ok);};
      const submit=()=>{
        const name=cleanText(inp.value,500),e=validateSchoolName(name);
        if(e){er.textContent=e;er.hidden=false;inp.focus();return;}
        if(!persistSchool(normalizeSchool(Object.assign({},school,{name})))){er.textContent='Could not save on this device — storage may be full or blocked.';er.hidden=false;return;}
        renderSchoolHeader();$('p9-school-in-name').value=school.name;done(true);
      };
      m.onclick=e=>{const b=e.target.closest('[data-r]');if(b){if(b.dataset.r==='ok')submit();else done(false);}else if(e.target===m)done(false);};
      inp.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();submit();}});
      setTimeout(()=>inp.focus(),30);
    });
  }
  function schoolHeadHtml(){
    const extra=[school.address,school.contact].filter(Boolean).join(' | ');
    return `${school.logo?`<img class="logo" src="${school.logo}" alt="">`:''}<h1>${escapeHtml(school.name)}</h1>${extra?`<p class="sch">${escapeHtml(extra)}</p>`:''}`;
  }
  function initSchool(){
    $('p9-school-save').addEventListener('click',saveSchoolFromForm);
    $('p9-school-revert').addEventListener('click',()=>{fillSchoolForm();showToast('Changes discarded');});
    $('p9-school-logo-btn').addEventListener('click',()=>$('p9-school-logo-file').click());
    $('p9-school-logo-clear').addEventListener('click',()=>{schoolDraftLogo='';drawSchoolLogoPreview();});
    $('p9-school-logo-file').addEventListener('change',async e=>{
      const f=e.target.files&&e.target.files[0];e.target.value='';if(!f)return;
      try{schoolDraftLogo=await prepareLogo(f);drawSchoolLogoPreview();$('p9-school-msg').hidden=true;showToast('Logo ready — press Save School Settings');}
      catch(err){const m=$('p9-school-msg');m.textContent=(err&&err.message)||'Logo could not be used';m.hidden=false;}
    });
    $('p9-school-in-name').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();saveSchoolFromForm();}});
    renderSchoolHeader();fillSchoolForm();
  }

  /* ---------- Local database (IndexedDB): every checked copy is saved immediately ---------- */
  const DB_NAME='OMR_AutoChecker_DB';let dbPromise=null;
  function openDB(){return dbPromise||(dbPromise=new Promise((res,rej)=>{if(!window.indexedDB){rej(new Error('IndexedDB not supported'));return;}const q=indexedDB.open(DB_NAME,2);
    q.onupgradeneeded=e=>{const d=q.result,t=q.transaction;
      if(!d.objectStoreNames.contains('results')){const st=d.createObjectStore('results',{keyPath:'id'});st.createIndex('className','className');st.createIndex('sessionId','sessionId');}
      if(!d.objectStoreNames.contains('settings'))d.createObjectStore('settings',{keyPath:'key'});
      if(!d.objectStoreNames.contains('images'))d.createObjectStore('images',{keyPath:'id'});
      if(e.oldVersion>=1){const rs=t.objectStore('results'),is=t.objectStore('images');rs.openCursor().onsuccess=ev=>{const c=ev.target.result;if(!c)return;const r=c.value;if(r.nameImg||r.rollImg){is.put({id:r.id,nameImg:r.nameImg||'',rollImg:r.rollImg||''});delete r.nameImg;delete r.rollImg;c.update(r);}c.continue();};}
    };
    q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error);q.onblocked=()=>rej(new Error('Close other tabs using this app, then reload'));}));}
  function dbTx(names,mode,fn){return openDB().then(d=>new Promise((res,rej)=>{const t=d.transaction(names,mode),o={};names.forEach(n=>{o[n]=t.objectStore(n);});let out;try{out=fn(o);}catch(e){try{t.abort();}catch(_){}rej(e);return;}t.oncomplete=()=>res(out&&typeof out==='object'&&'result' in out?out.result:undefined);t.onerror=()=>rej(t.error);t.onabort=()=>rej(t.error||new Error('Transaction aborted'));}));}
  const dbRun=(mode,fn)=>dbTx(['results'],mode,o=>fn(o.results));
  const splitRec=r=>{const rec={};for(const k in r){if(k==='nameImg'||k==='rollImg'||k[0]==='_')continue;rec[k]=r[k];}return rec;};
  const putOne=(o,r)=>{
    o.results.put(splitRec(r));
    if(!('nameImg' in r)&&!('rollImg' in r))return;                       // nothing about images in this write: leave stored images untouched
    const req=o.images.get(r.id);
    req.onsuccess=()=>{const cur=req.result||{},next={id:r.id,nameImg:'nameImg' in r?(r.nameImg||''):(cur.nameImg||''),rollImg:'rollImg' in r?(r.rollImg||''):(cur.rollImg||'')};
      if(!next.nameImg&&!next.rollImg)o.images.delete(r.id);else o.images.put(next);};   // cleared crops remove the stored entry
  };
  const dbPruneOrphanImages=()=>dbTx(['results','images'],'readwrite',o=>{const rk=o.results.getAllKeys();rk.onsuccess=()=>{const have=new Set(rk.result);const ik=o.images.getAllKeys();ik.onsuccess=()=>{ik.result.forEach(k=>{if(!have.has(k))o.images.delete(k);});};};});
  const dbPutMany=list=>dbTx(['results','images'],'readwrite',o=>{list.forEach(r=>putOne(o,r));});
  const dbPut=r=>dbPutMany([r]);
  const dbDeleteMany=ids=>dbTx(['results','images'],'readwrite',o=>{ids.forEach(id=>{o.results.delete(id);o.images.delete(id);});});
  const dbGet=id=>dbRun('readonly',st=>st.get(id));
  const dbCount=()=>dbRun('readonly',st=>st.count());
  const dbAll=()=>dbRun('readonly',st=>st.getAll());
  const dbAllImages=()=>dbTx(['images'],'readonly',o=>o.images.getAll());
  const dbBySession=id=>dbRun('readonly',st=>st.index('sessionId').getAll(id));
  const dbClear=()=>dbTx(['results','images'],'readwrite',o=>{o.results.clear();o.images.clear();});
  const dbReplaceAll=list=>dbTx(['results','images'],'readwrite',o=>{o.results.clear();o.images.clear();list.forEach(r=>putOne(o,r));});
  const IMG=new Map();
  const imgOf=(r,k)=>r[k]||((IMG.get(r.id)||{})[k])||'';
  function evictImages(){while(IMG.size>600)IMG.delete(IMG.keys().next().value);}
  async function primeImages(ids){const need=ids.filter(id=>!IMG.has(id));if(!need.length)return 0;let n=0;const d=await openDB();await new Promise((res,rej)=>{const t=d.transaction('images','readonly'),st=t.objectStore('images');need.forEach(id=>{st.get(id).onsuccess=ev=>{IMG.set(id,ev.target.result||{});if(ev.target.result)n++;};});t.oncomplete=res;t.onerror=()=>rej(t.error);});evictImages();return n;}
  function handleAppError(err,ctx){const msg=(err&&err.message)||String(err);try{debugLog('ERROR ['+ctx+'] '+msg,(err&&err.stack)||'');}catch(_){}console.error('['+ctx+']',err);showToast('✕ '+ctx+': '+msg,7000);}
  let REVIEW_ON_UNATTEMPTED=localStorage.getItem('p9_review_unatt')==='1';
  const detailsMissing=r=>!r.name&&!r.roll;
  const reviewStatus=st=>st==='low-confidence'||st==='multiple'||st==='invalid'||(st==='unattempted'&&REVIEW_ON_UNATTEMPTED);
  function isNeedsAttention(r){return (r.rev>0)||(r.invalid>0)||/[lmx]/.test(r.st||'');}
  function isNeedsReview(r){return !r.reviewed&&(isNeedsAttention(r)||r.flagged===true||(REVIEW_ON_UNATTEMPTED&&r.unattempted>0));}
  function reviewReason(r){if(r.reviewed)return '';const p=[],c=ch=>(r.st||'').split(ch).length-1;if(c('l'))p.push(c('l')+' low-confidence');if(c('m'))p.push(c('m')+' multiple-marked');if(c('x'))p.push(c('x')+' invalid');if(REVIEW_ON_UNATTEMPTED&&r.unattempted>0)p.push(r.unattempted+' unattempted');if(r.flagged)p.push('flagged by teacher');return p.join(', ');}
  function statusText(r){return r._saveError?'Failed to save':(r.reviewed?'Reviewed':(r.review?'Needs Review':'Saved'));}

  /* ---------- Session (current scanning run) ---------- */
  const SESSION_ID=(()=>{let id=localStorage.getItem('p9_session_id');if(!id){id='S'+Date.now();try{localStorage.setItem('p9_session_id',id);}catch(_){}}return id;})();
  let sessionId=SESSION_ID;
  const session={failed:Number(localStorage.getItem('p9_failed')||0),rows:[]};
  const ST={detected:'d',unattempted:'u','low-confidence':'l',multiple:'m'},ST_R={d:'detected',u:'unattempted',l:'low-confidence',m:'multiple',x:'invalid'};
  const putTimers=new Map();
  function saveFailed(){try{localStorage.setItem('p9_failed',String(session.failed));}catch(_){}}
  function persistRow(r,quiet){clearTimeout(putTimers.get(r.id));putTimers.set(r.id,setTimeout(()=>flushRow(r,quiet),quiet?400:0));}
  const saveChains=new Map();
  function flushRow(r,quiet){
    clearTimeout(putTimers.get(r.id));putTimers.delete(r.id);
    const prev=saveChains.get(r.id)||Promise.resolve();
    const next=prev.then(async()=>{
      if(r._deleted)return false;
      try{await dbPut(r);r._saveError=false;r._saved=true;if(r.nameImg||r.rollImg){IMG.set(r.id,{nameImg:r.nameImg||'',rollImg:r.rollImg||''});delete r.nameImg;delete r.rollImg;evictImages();}REC.loaded=false;if(!quiet)showToast('✓ Saved locally',1200);return true;}
      catch(e){r._saveError=true;handleAppError(e,'save');return false;}
      finally{renderSaveRetry();renderSession();}
    });
    const tracked=next.catch(()=>false);saveChains.set(r.id,tracked);tracked.then(()=>{if(saveChains.get(r.id)===tracked)saveChains.delete(r.id);});return next;
  }
  async function flushAllPending(){
    for(const id of [...putTimers.keys()]){const r=session.rows.find(x=>x.id===id);if(r)await flushRow(r,true);else{clearTimeout(putTimers.get(id));putTimers.delete(id);}}
    for(const r of session.rows.filter(x=>x._saveError||(!x._saved&&!saveChains.has(x.id))))await flushRow(r,true);
    await Promise.all([...saveChains.values()]);
    const failed=session.rows.filter(r=>r._saveError||!r._saved).map(r=>r.id);
    return{ok:failed.length===0,failed};
  }
  function resetCurrentScan(){state.epoch=(state.epoch||0)+1;state.currentResults=null;state.currentScanId=null;state.currentStudent=null;state.saved=false;if(state.currentWarp){deleteMat(state.currentWarp);state.currentWarp=null;}if(els.result)els.result.hidden=true;if(els.resultCanvas)els.resultCanvas.classList.remove('show');[els.save,els.saveNext,els.print].forEach(b=>{if(b)b.disabled=true;});}
  function renderSaveRetry(){const b=document.getElementById('p9-save-retry');if(b)b.hidden=!session.rows.some(r=>r._saveError);}
  async function retrySave(){for(const r of session.rows.filter(x=>x._saveError))await flushRow(r,false);}
  function packAnswers(results){const a=[],t=[];for(let q=1;q<=50;q++){const r=results.find(x=>x.question===q);a.push(r&&r.detected?r.detected:'-');t.push(r?(ST[r.status]||'x'):'u');}return{ans:a.join(''),st:t.join('')};}
  function rowFromCurrent(){const set=resultSet(),sc=calculateScore(state.currentResults,ANSWER_KEYS[set]);const o=Object.assign({set,correct:sc.correct,wrong:sc.wrong,unattempted:sc.unattempted,invalid:sc.invalid,rev:sc.review,score:sc.score,total:sc.total||50,pct:Math.round(sc.percentage),review:false},packAnswers(state.currentResults));o.review=isNeedsReview(o);return o;}
  function syncRowFromCurrent(){if(!state.currentResults||!state.currentScanId)return;const st=state.currentStudent||{};sessionUpdate(state.currentScanId,Object.assign({name:st.name||'',roll:st.rollNo||''},rowFromCurrent()));}
  function dispCell(text,img){return text?escapeHtml(text):(img?`<img class="cell-crop" src="${img}" alt="from sheet">`:'<i class="ne">Not entered</i>');}
  function sessionCounts(){
    const rows=session.rows,saved=rows.filter(r=>r._saved&&!r._saveError),failedSave=rows.filter(r=>r._saveError).length,pending=rows.length-saved.length-failedSave;
    const review=saved.filter(r=>r.review).length,rejected=session.failed;
    return{detected:Math.max(state.detected||0,rows.length+rejected),processed:rows.length,saved:saved.length,pending,saveFailed:failedSave,review,rejected};
  }
  const SESS={page:1,per:50,q:''};
  function drawSessionBody(){
    if(!els.sessBody)return;const q=SESS.q.trim().toLowerCase();
    const all=session.rows.map((r,i)=>({r,no:i+1})).filter(x=>!q||`${x.r.name||''} ${x.r.roll||''}`.toLowerCase().includes(q)).reverse();
    const pages=Math.max(1,Math.ceil(all.length/SESS.per));if(SESS.page>pages)SESS.page=pages;const from=(SESS.page-1)*SESS.per;
    els.sessBody.innerHTML=all.slice(from,from+SESS.per).map(({r,no})=>`<tr><td>${no}</td><td>${dispCell(r.name,imgOf(r,'nameImg'))}</td><td>${dispCell(r.roll,imgOf(r,'rollImg'))}</td><td>${escapeHtml(r.set)}</td><td>${r.score}/${r.total}</td><td>${r.pct}%</td><td>${escapeHtml(statusText(r))}</td><td><button class="p9-btn small" data-pdf="${escapeHtml(r.id)}" type="button">Preview</button></td></tr>`).join('');
    if(els.sessPage)els.sessPage.textContent=`Page ${SESS.page} / ${pages} · showing ${Math.min(SESS.per,Math.max(0,all.length-from))} of ${all.length}${q?' (filtered)':''}`;
    if(els.sessPrev)els.sessPrev.disabled=SESS.page<=1;if(els.sessNext)els.sessNext.disabled=SESS.page>=pages;
  }
  function renderSession(){
    if(!els.liveBox)return;const c=sessionCounts(),rows=session.rows;
    els.liveAuto.textContent=state.autoScan?'🟢 AUTO SCAN ON':'⚪ AUTO SCAN OFF';
    els.liveCounts.textContent=`Detected ${c.detected} · Saved ${c.saved} · Pending ${c.pending} · Save failed ${c.saveFailed} · Review ${c.review} · Rejected ${c.rejected}`;
    const last=rows[rows.length-1];
    els.liveLast.textContent=last?`Last: #${rows.length} · Roll ${last.roll||'Not entered'} · ${last.score}/${last.total}${state.scanTimes&&state.scanTimes.length?' · avg '+(state.scanTimes.reduce((a,b)=>a+b,0)/state.scanTimes.length/1000).toFixed(1)+'s/sheet':''}`:'Last: —';
    if(els.sessSummary)els.sessSummary.textContent=`Detected: ${c.detected} · Processed: ${c.processed} · Saved: ${c.saved} · Save pending: ${c.pending} · Save failed: ${c.saveFailed} · Needs review: ${c.review} · Rejected scans: ${c.rejected}`;
    drawSessionBody();
    const need=rows.slice(-100).map(r=>r.id).filter(id=>!IMG.has(id));
    if(need.length&&!renderSession.busy){renderSession.busy=true;primeImages(need).then(n=>{renderSession.busy=false;if(n)drawSessionBody();}).catch(e=>{renderSession.busy=false;handleAppError(e,'load images');});}
    updateBatchUI();
  }
  function sessionAdd(row){const now=Date.now(),rec=Object.assign({sessionId,className:exam.className,subject:exam.subject,section:exam.section,date:exam.date,createdAt:now,updatedAt:now},row);session.rows.push(rec);renderSession();rec._p=flushRow(rec,false);}
  function sessionFail(){session.failed++;saveFailed();renderSession();}
  function sessionUpdate(id,patch){const r=session.rows.find(x=>x.id===id);if(r){Object.assign(r,patch,{updatedAt:Date.now()});renderSession();persistRow(r,true);}}
  async function sessionRemove(id){clearTimeout(putTimers.get(id));putTimers.delete(id);const sr=session.rows.find(x=>x.id===id);if(sr)sr._deleted=true;try{await (saveChains.get(id)||Promise.resolve());await dbDeleteMany([id]);if(await dbGet(id))throw new Error('Record could not be deleted');}catch(e){if(sr)sr._deleted=false;throw e;}if(id===state.currentScanId)state.saved=false;const i=session.rows.findIndex(x=>x.id===id);if(i>=0)session.rows.splice(i,1);IMG.delete(id);REC.loaded=false;renderSession();}
  function resetSessionCounters(){state.detected=0;state.scanTimes=[];session.rows=[];session.failed=0;saveFailed();}
  async function resetSession(){
    if(!await confirmModal({title:'START A NEW SESSION?',body:`<p>The on-screen list and counters will be cleared.</p><p><b>All ${session.rows.length} saved records stay in RECORDS</b> and nothing is deleted.</p>`,confirmText:'Start New Session',danger:false}))return;
    let fl=await flushAllPending();
    while(!fl.ok){
      const c=await choiceModal({title:'SOME RESULTS ARE NOT SAVED',body:`<p><b>${fl.failed.length}</b> scanned result(s) could not be saved to this device. Starting a new session now would lose them.</p><p>Retry saving, or cancel and keep working. You can also discard them explicitly.</p>`,choices:[{id:'cancel',label:'Cancel'},{id:'retry',label:'Retry save',cls:'primary'},{id:'discard',label:'Discard unsaved results',cls:'danger'}]});
      if(c==='cancel'){showToast('New session cancelled — results kept; press Retry Save',5000);renderSaveRetry();return;}
      if(c==='discard'){if(!await confirmModal({title:'DISCARD UNSAVED RESULTS?',body:`<p>${fl.failed.length} result(s) will be lost permanently.</p>`,confirmText:'Discard'}))continue;break;}
      fl=await flushAllPending();
    }
    resetCurrentScan();sessionId='S'+Date.now();try{localStorage.setItem('p9_session_id',sessionId);}catch(_){}
    resetSessionCounters();renderSession();showToast('New session started — saved records are kept');
  }
  async function initStore(){
    try{
      await openDB();
      try{await dbPruneOrphanImages();}catch(e){handleAppError(e,'clean up images');}
      try{const old=JSON.parse(localStorage.getItem('p9_session_v2')||'null');if(old&&Array.isArray(old.rows)&&old.rows.length){const t=Date.now();await dbPutMany(old.rows.map((r,i)=>Object.assign({sessionId,className:exam.className,subject:exam.subject,section:exam.section,date:exam.date,createdAt:t+i,updatedAt:t+i},r)));localStorage.removeItem('p9_session_v2');}}catch(_){}
      session.rows=(await dbBySession(sessionId)).sort((a,b)=>a.createdAt-b.createdAt).map(r=>Object.assign(r,{_saved:true}));renderSession();
      if(session.rows.length){const c=await choiceModal({title:'PREVIOUS SESSION FOUND',body:`<p><b>${session.rows.length}</b> students are already saved in the previous session.</p><p>Resume to continue adding sheets, or start a new session. Nothing is deleted either way.</p>`,choices:[{id:'new',label:'Start New Session'},{id:'resume',label:'Resume',cls:'primary'}]});
        if(c==='new'){sessionId='S'+Date.now();try{localStorage.setItem('p9_session_id',sessionId);}catch(_){}resetSessionCounters();renderSession();}}
    }catch(e){handleAppError(e,'open local database');}
  }

  /* ---------- Modals (replace browser confirm) ---------- */
  function modal(html){const m=document.getElementById('p9-modal');m.innerHTML=`<div class="modal-card" role="dialog" aria-modal="true">${html}</div>`;m.hidden=false;document.body.classList.add('modal-open');return m;}
  function closeModal(){const m=document.getElementById('p9-modal');m.hidden=true;m.innerHTML='';m.onclick=null;document.body.classList.remove('modal-open');}
  function choiceModal({title,body,choices}){return new Promise(res=>{const m=modal(`<h3>${escapeHtml(title)}</h3><div class="modal-body">${body}</div><div class="modal-actions">${choices.map(c=>`<button class="p9-btn ${c.cls||''}" data-r="${c.id}" type="button">${escapeHtml(c.label)}</button>`).join('')}</div>`);const cancel=m.querySelector('[data-r="cancel"]');if(cancel)cancel.focus();m.onclick=e=>{const b=e.target.closest('[data-r]');if(b){closeModal();res(b.dataset.r);}else if(e.target===m){closeModal();res('cancel');}};});}
  async function confirmModal({title,body,confirmText='Delete Permanently',danger=true}){return (await choiceModal({title,body,choices:[{id:'cancel',label:'Cancel'},{id:'ok',label:confirmText,cls:danger?'danger':'primary'}]}))==='ok';}
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){const pm=document.getElementById('p9-pdf-modal');if(pm&&!pm.hidden){closePdfPreview();return;}const m=document.getElementById('p9-modal');if(m&&!m.hidden){const c=m.querySelector('[data-r="cancel"]')||m.querySelector('[data-close]');if(c)c.click();}}});

  /* ---------- Reports (built from saved records) ---------- */
  const safeName=t=>String(t||'').trim().replace(/[\\/:*?"<>|]+/g,'').replace(/\s+/g,'_')||'NA';
  const REPORT_CSS='@page{size:A4;margin:12mm 10mm 14mm;@bottom-center{content:"Page " counter(page) " of " counter(pages);font:9px Arial;color:#555}}*{box-sizing:border-box}body{font-family:Arial,sans-serif;color:#111;font-size:11px}h1{font-size:18px;margin:0;text-align:center}h2{font-size:13px;margin:2px 0 6px;text-align:center;letter-spacing:.08em}.meta{display:flex;justify-content:space-between;flex-wrap:wrap;gap:4px 14px;margin:6px 0;padding:6px 0;border-top:1px solid #333;border-bottom:1px solid #333;font-weight:bold}table{border-collapse:collapse;width:100%}th,td{border:1px solid #999;padding:3px 5px;text-align:left;vertical-align:middle}thead{display:table-header-group}tr{page-break-inside:avoid}th{background:#e8edf3}.num{text-align:right}.sum{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin:8px 0 10px}.sum div{border:1px solid #999;padding:5px;border-radius:4px}.sum b{display:block;font-size:14px}img.c{max-height:24px;max-width:130px;vertical-align:middle}.head td{border:none;padding:0 0 4px}.bad{color:#b3261e}.sch{text-align:center;margin:0 0 4px;font-size:10px;color:#333}img.logo{max-height:46px;max-width:90px;float:left;margin-right:8px}';
  const uniq=(list,k)=>{const s=[...new Set(list.map(r=>r[k]).filter(Boolean))];return s.length===1?s[0]:(s.length?'Multiple':'—');};
  function reportHead(list){return `<div class="meta"><span>Class: ${escapeHtml(uniq(list,'className'))}</span><span>Subject: ${escapeHtml(uniq(list,'subject'))}</span><span>Section: ${escapeHtml(uniq(list,'section'))}</span><span>Date: ${escapeHtml(fmtDate(uniq(list,'date')))}</span></div>`;}
  function pdfCell(text,img){return text?escapeHtml(text):(img?`<img class="c" src="${img}" alt="">`:'—');}
  function rowAnswers(r){return Array.from({length:50},(_,i)=>({question:i+1,detected:r.ans[i]==='-'?null:r.ans[i],status:ST_R[r.st[i]]||'unattempted'}));}
  function studentReportHtml(r){
    const key=ANSWER_KEYS[r.set]||{},rows=rowAnswers(r).map(a=>`<tr><td>${a.question}</td><td>${a.detected||'—'}</td><td>${key[a.question]||'—'}</td><td>${statusLabel(a.status,a.detected,key[a.question])}</td></tr>`).join('');
    return `<!doctype html><html><head><meta charset="utf-8"><title>OMR_Result_${safeName(r.roll||'NA')}_${safeName(r.name||'Student')}</title><style>${REPORT_CSS}</style></head><body>${schoolHeadHtml()}<h2>OMR EXAMINATION RESULT</h2>${reportHead([r])}<table><tr><th>Student Name</th><td>${pdfCell(r.name,imgOf(r,'nameImg'))}</td><th>Roll No.</th><td>${pdfCell(r.roll,imgOf(r,'rollImg'))}</td><th>Set</th><td>${r.set}</td></tr></table><div class="sum"><div><b>${r.correct}</b>Correct</div><div><b>${r.wrong}</b>Wrong</div><div><b>${r.unattempted}</b>Unattempted</div><div><b>${r.invalid}</b>Invalid</div></div><p><b>Score: ${r.score} / ${r.total}</b> &nbsp; <b>Percentage: ${r.pct}%</b>${r.review?' &nbsp; <span class="bad">(Review required)</span>':''}</p><table><thead><tr><th>Q</th><th>Marked</th><th>Correct</th><th>Result</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
  }
  function allReportHtml(R,o={}){
    const off=o.offset||0,F=o.full||R,n=F.length,sum=k=>F.reduce((t,r)=>t+(r[k]||0),0),sc=F.map(r=>r.score),review=F.filter(r=>r.review).length;
    const body=R.map((r,i)=>`<tr><td class="num">${off+i+1}</td><td>${pdfCell(r.name,imgOf(r,'nameImg'))}</td><td>${pdfCell(r.roll,imgOf(r,'rollImg'))}</td><td>${r.set}</td><td class="num">${r.correct}</td><td class="num">${r.wrong}</td><td class="num">${r.unattempted}</td><td class="num">${r.invalid}</td><td class="num">${r.score}/${r.total}</td><td class="num">${r.pct}%</td><td>${r.review?'Review':'OK'}</td></tr>`).join('');
    const title=`OMR_All_Students_${safeName(uniq(F,'className'))}_${safeName(uniq(F,'subject'))}_${safeName(fmtDate(uniq(F,'date')).replace(/\//g,'-'))}${o.partLabel?'_'+safeName(o.partLabel):''}`;
    const summary=o.last===false?'':`<div class="sum" style="margin-top:12px"><div><b>${n}</b>Total Students</div><div><b>${n-review}</b>Complete</div><div><b>${review}</b>Needs Review</div><div><b>${session.failed}</b>Failed scans (this session)</div><div><b>${n?(sc.reduce((a,b)=>a+b,0)/n).toFixed(1):0}</b>Average Marks</div><div><b>${n?sc.reduce((m,v)=>Math.max(m,v),0):0}</b>Highest</div><div><b>${n?sc.reduce((m,v)=>Math.min(m,v),1e9):0}</b>Lowest</div><div><b>${sum('correct')} / ${sum('wrong')} / ${sum('unattempted')} / ${sum('invalid')}</b>Correct / Wrong / Unatt. / Invalid</div></div>`;
    return `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title><style>${REPORT_CSS}</style></head><body><table><thead><tr class="head"><td colspan="11">${schoolHeadHtml()}<h2>OMR EXAMINATION RESULT${o.partLabel?' — '+escapeHtml(o.partLabel):''}</h2>${reportHead(F)}</td></tr><tr><th>S.No.</th><th>Student Name</th><th>Roll No.</th><th>Set</th><th>Correct</th><th>Wrong</th><th>Unattempted</th><th>Invalid</th><th>Marks</th><th>%</th><th>Status</th></tr></thead><tbody>${body}</tbody></table>${summary}</body></html>`;
  }
  function openReport(html,w){w=w||window.open('','_blank');if(!w){showToast('Allow pop-ups, then try again',4000);return;}try{w.document.open();w.document.write(html);w.document.close();setTimeout(()=>{try{w.focus();w.print();}catch(e){handleAppError(e,'print');}},500);}catch(e){handleAppError(e,'open report');}}
  /* ---------- Real PDF generation (jsPDF, loaded on first use) ---------- */
  const PDF_PART=100,PDF_ROWS=26,tick=()=>new Promise(r=>setTimeout(r,0));let pdfParts=[],lastPdfJob=null;
  const JSPDF_SOURCES=['jspdf.umd.min.js','https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js'];
  function loadJsPdf(){
    if(window.jspdf&&window.jspdf.jsPDF)return Promise.resolve(window.jspdf.jsPDF);
    return loadJsPdf.p||(loadJsPdf.p=(async()=>{
      for(const src of JSPDF_SOURCES){try{await new Promise((res,rej)=>{const sc=document.createElement('script');sc.src=src;sc.onload=res;sc.onerror=()=>rej(new Error('Could not load '+src));document.head.appendChild(sc);});if(window.jspdf&&window.jspdf.jsPDF)return window.jspdf.jsPDF;}catch(e){debugLog('PDF library',String(e.message||e));}}
      loadJsPdf.p=null;throw new Error('PDF library could not be loaded. Connect to the internet once, or put jspdf.umd.min.js next to index.html.');
    })());
  }
  const isLatin=t=>/^[\x20-\x7E\u00A0-\u00FF]*$/.test(t||'');
  const imgOk=u=>typeof u==='string'&&u.indexOf('data:image')===0;
  function downloadPdfBlob(blob,name){const url=URL.createObjectURL(blob);triggerDownload(url,name);setTimeout(()=>URL.revokeObjectURL(url),60000);}
  function triggerDownload(url,name){const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();}
  function pdfResultText(a,key){if(a.status==='unattempted')return 'Unattempted';if(a.status==='multiple')return 'Multiple';if(a.status==='invalid')return 'Invalid';if(a.status==='low-confidence')return 'Low confidence';return a.detected===key?'Correct':'Wrong';}
  function pdfFooters(doc){const n=doc.getNumberOfPages();doc.setFont('helvetica','normal');doc.setFontSize(8);for(let k=1;k<=n;k++){doc.setPage(k);doc.text(`Page ${k} of ${n}`,105,292,{align:'center'});doc.setFontSize(7);doc.text('Generated with eGyan Classes - OMR Auto-Checker',200,292,{align:'right'});doc.setFontSize(8);}}
  /* Non-Latin school names (e.g. Hindi) cannot be drawn with the built-in PDF font, so they are rendered to a small image instead */
  function pdfTextImage(text,pt,bold,color){
    const S=3,fp=pt*96/72*S,font=`${bold?'700 ':''}${fp}px "Noto Sans Devanagari","Nirmala UI",Mangal,Arial,sans-serif`,c=document.createElement('canvas'),g=c.getContext('2d');
    g.font=font;const w=Math.ceil(g.measureText(text).width)+6;c.width=w;c.height=Math.ceil(fp*1.6);
    g.font=font;g.textBaseline='middle';g.fillStyle=color||'#000';g.fillText(text,3,c.height/2);
    const k=0.2645833/S;return{url:c.toDataURL('image/png'),w:c.width*k,h:c.height*k};
  }
  function pdfCenterText(doc,text,y,pt,bold,maxW){
    doc.setFont('helvetica',bold?'bold':'normal');let size=pt;
    if(isLatin(text)){
      doc.setFontSize(size);while(size>6&&doc.getTextWidth(text)>maxW){size-=0.5;doc.setFontSize(size);}
      while(text.length>4&&doc.getTextWidth(text)>maxW)text=text.slice(0,-2);
      doc.text(text,105,y,{align:'center'});return;
    }
    try{const im=pdfTextImage(text,size,bold);let w=im.w,h=im.h;if(w>maxW){h*=maxW/w;w=maxW;}doc.addImage(im.url,'PNG',105-w/2,y-size*0.1235-h/2,w,h);}
    catch(e){debugLog('PDF text image',String((e&&e.message)||e));doc.setFontSize(size);doc.text(text.replace(/[^\x20-\x7E]/g,'?'),105,y,{align:'center'});}
  }
  function pdfSchoolLogo(doc){
    if(!school.logo)return;
    try{const fmt=school.logo.indexOf('data:image/png')===0?'PNG':'JPEG',p=doc.getImageProperties(school.logo),box=14,k=Math.min(box/p.width,box/p.height),w=p.width*k,h=p.height*k;doc.addImage(school.logo,fmt,10+(box-w)/2,5+(box-h)/2,w,h);}
    catch(e){debugLog('PDF school logo',String((e&&e.message)||e));}
  }
  function pdfPageHeader(doc,list,label,scope){
    const extra=[school.address,school.contact].filter(Boolean).join('   |   ');
    pdfSchoolLogo(doc);pdfCenterText(doc,school.name,extra?10.5:12,15,true,150);
    if(extra)pdfCenterText(doc,extra,15.4,7.5,false,150);
    doc.setFont('helvetica','bold');doc.setFontSize(10);doc.text('OMR EXAMINATION RESULT'+(label?'  -  '+label:''),105,extra?20.5:18,{align:'center'});
    doc.setFont('helvetica','normal');doc.setFontSize(9);
    doc.text(`Class: ${uniq(list,'className')}    Subject: ${uniq(list,'subject')}    Section: ${uniq(list,'section')}    Date: ${fmtDate(uniq(list,'date'))}`,10,25);doc.line(10,27,200,27);
    doc.setFontSize(7);doc.text(`${scope?'Scope: '+scope+'  |  ':''}Generated: ${new Date().toLocaleString()}`,10,31);doc.setFontSize(9);
  }
  const PDF_COLS=[['S.No.',10],['Student Name',22],['Roll No.',70],['Set',92],['Correct',100],['Wrong',112],['Unatt.',124],['Invalid',136],['Marks',148],['%',166],['Status',177]];
  function pdfColHeader(doc){doc.setFont('helvetica','bold');doc.setFontSize(8);PDF_COLS.forEach(([t,x])=>doc.text(t,x,33));doc.line(10,35,200,35);doc.setFont('helvetica','normal');}
  function pdfRow(doc,r,no,y){
    doc.setFontSize(9);doc.text(String(no),10,y+5);
    if(r.name&&isLatin(r.name))doc.text(String(r.name).slice(0,26),22,y+5);else if(imgOk(imgOf(r,'nameImg')))doc.addImage(imgOf(r,'nameImg'),'JPEG',22,y,44,6.5);else doc.text(r.name?'(see sheet)':'Not entered',22,y+5);
    if(r.roll&&isLatin(r.roll))doc.text(String(r.roll).slice(0,10),70,y+5);else if(imgOk(imgOf(r,'rollImg')))doc.addImage(imgOf(r,'rollImg'),'JPEG',70,y,13,6.5);else doc.text(r.roll?'(see sheet)':'Not entered',70,y+5);
    [[r.set,92],[r.correct,100],[r.wrong,112],[r.unattempted,124],[r.invalid,136],[`${r.score}/${r.total}`,148],[`${r.pct}%`,166],[r.review?'Review':'OK',177]].forEach(([t,x])=>doc.text(String(t),x,y+5));
    doc.setDrawColor(210);doc.line(10,y+8,200,y+8);doc.setDrawColor(0);
  }
  function pdfSummary(doc,F,y,isSession){
    const n=F.length,sum=k=>F.reduce((t,r)=>t+(r[k]||0),0),sc=F.map(r=>r.score),review=F.filter(r=>r.review).length;
    if(y>250){doc.addPage();y=20;}y+=8;doc.setFont('helvetica','bold');doc.setFontSize(10);doc.text('SUMMARY',10,y);doc.setFont('helvetica','normal');doc.setFontSize(9);
    const L=[`Total Students: ${n}`,`Complete: ${n-review}    Needs Review: ${review}`+(isSession?`    Failed scans (this session): ${session.failed}`:''),`Average Marks: ${n?(sc.reduce((a,b)=>a+b,0)/n).toFixed(1):0}    Highest: ${n?sc.reduce((m,v)=>Math.max(m,v),0):0}    Lowest: ${n?sc.reduce((m,v)=>Math.min(m,v),1e9):0}`,`Total Correct: ${sum('correct')}    Wrong: ${sum('wrong')}    Unattempted: ${sum('unattempted')}    Invalid: ${sum('invalid')}`];
    L.forEach((t,i)=>doc.text(t,10,y+7+i*6));
  }
  function pdfStatus(msg,o={}){const el=document.getElementById('p9-pdf-status');if(!el)return;el.hidden=!msg;el.querySelector('.pdf-msg').textContent=msg||'';el.querySelector('[data-pdf-retry]').hidden=!o.retry;el.querySelector('.pdf-parts').innerHTML=(o.parts||[]).map((p,i)=>`<button class="p9-btn small primary" data-part="${i}" type="button">Download part ${i+1} of ${o.parts.length} (students ${p.from}–${p.to})</button>`).join('');}
  function revokePdfParts(){pdfParts.forEach(p=>{if(p&&p.url)URL.revokeObjectURL(p.url);});pdfParts=[];}
  let pdfBusy=false;const PDFV={parts:[],idx:0,renderToken:0};
  /* Android Chrome / WebViews cannot show a PDF inside an iframe (they start a download instead, often named download.bin),
     so the preview is drawn page by page from the generated PDF with pdf.js; the iframe is used only where the browser has a real inline viewer. */
  const PDFJS_LIB=['pdf.min.js','https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js'],PDFJS_WORKER=['pdf.worker.min.js','https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'];
  function loadScriptOnce(src){return new Promise((res,rej)=>{const sc=document.createElement('script');const t=setTimeout(()=>rej(new Error('timeout '+src)),20000);sc.onload=()=>{clearTimeout(t);res();};sc.onerror=()=>{clearTimeout(t);rej(new Error('Could not load '+src));};sc.src=src;document.head.appendChild(sc);});}
  function loadPdfJs(){
    if(window.pdfjsLib&&window.pdfjsLib.__p9ready)return Promise.resolve(window.pdfjsLib);
    return loadPdfJs.p||(loadPdfJs.p=(async()=>{
      for(const src of PDFJS_LIB){if(window.pdfjsLib)break;try{await loadScriptOnce(src);}catch(e){debugLog('pdf.js',String(e.message||e));}}
      const lib=window.pdfjsLib;if(!lib){loadPdfJs.p=null;throw new Error('Preview library could not be loaded. Connect to the internet once, or put pdf.min.js and pdf.worker.min.js next to index.html.');}
      // Load the worker as a normal script (no blob/Worker): some WebViews turn a blob worker into a 1 MB 'download.bin'.
      let ws=PDFJS_WORKER[1];for(const src of PDFJS_WORKER){try{await loadScriptOnce(src);if(window.pdfjsWorker){ws=src;break;}}catch(e){debugLog('pdf.js worker',String(e.message||e));}}
      lib.GlobalWorkerOptions.workerSrc=ws;lib.__p9ready=true;return lib;
    })());
  }
  async function renderPdfPages(blob,host,token){
    const lib=await loadPdfJs(),pdf=await lib.getDocument({data:new Uint8Array(await blob.arrayBuffer())}).promise;
    try{
      if(token!==PDFV.renderToken)return;host.innerHTML='';
      const cssW=Math.max(260,host.clientWidth-16),ratio=Math.min(window.devicePixelRatio||1,2);
      for(let i=1;i<=pdf.numPages;i++){
        if(token!==PDFV.renderToken)return;
        const page=await pdf.getPage(i),vp0=page.getViewport({scale:1}),vp=page.getViewport({scale:cssW/vp0.width*ratio});
        const cv=document.createElement('canvas');cv.width=Math.floor(vp.width);cv.height=Math.floor(vp.height);cv.className='pdf-canvas';cv.setAttribute('role','img');cv.setAttribute('aria-label',`PDF page ${i} of ${pdf.numPages}`);
        await page.render({canvasContext:cv.getContext('2d'),viewport:vp}).promise;page.cleanup();
        if(token!==PDFV.renderToken)return;
        const lab=document.createElement('div');lab.className='pdf-page-label';lab.textContent=`Page ${i} of ${pdf.numPages}`;host.appendChild(cv);host.appendChild(lab);await tick();
      }
    }finally{try{pdf.destroy();}catch(_){}}
  }
  const canShareFiles=()=>{try{return !!(navigator.canShare&&navigator.share&&navigator.canShare({files:[new File([new Blob(['x'],{type:'application/pdf'})],'x.pdf',{type:'application/pdf'})]}));}catch(_){return false;}};
  function closePdfPreview(){PDFV.renderToken=(PDFV.renderToken||0)+1;revokePdfParts();PDFV.parts=[];pdfParts=[];const m=document.getElementById('p9-pdf-modal');m.hidden=true;m.innerHTML='';m.onclick=null;document.body.classList.remove('modal-open');}
  function openPdfPreview(parts,title){
    PDFV.renderToken=(PDFV.renderToken||0)+1;PDFV.parts=parts;PDFV.idx=0;
    const m=document.getElementById('p9-pdf-modal');m.hidden=false;document.body.classList.add('modal-open');
    const share=canShareFiles();
    const draw=()=>{const p=PDFV.parts[PDFV.idx],n=PDFV.parts.length,tok=++PDFV.renderToken;
      m.innerHTML=`<div class="modal-card pdf-card" role="dialog" aria-modal="true" aria-label="PDF preview"><h3>${escapeHtml(title)}${n>1?` — Part ${PDFV.idx+1} of ${n}`:''}</h3>${n>1?`<p class="muted">This report was split into ${n} files to keep the app fast. This part has students ${p.from}–${p.to}. Every student is in exactly one part.</p>`:''}<div class="pdf-pages" id="p9-pdf-pages" aria-live="polite"><p class="muted">Drawing preview from the generated PDF…</p></div><p class="muted">Preview only — nothing is downloaded until you press Download PDF.</p><div class="modal-actions">${n>1?`<button class="p9-btn" data-pv="prev" type="button"${PDFV.idx?'':' disabled'}>◀ Previous part</button><button class="p9-btn" data-pv="next" type="button"${PDFV.idx<n-1?'':' disabled'}>Next part ▶</button>`:''}<button class="p9-btn" data-pv="close" type="button">Close</button>${share?'<button class="p9-btn" data-pv="share" type="button">Share / Save…</button>':''}<button class="p9-btn primary" data-pv="dl" type="button">Download PDF${n>1?` (part ${PDFV.idx+1})`:''}</button></div></div>`;
      const host=document.getElementById('p9-pdf-pages');renderPdfPages(p.blob,host,tok).catch(e=>{if(tok!==PDFV.renderToken)return;handleAppError(e,'PDF preview');host.innerHTML='<p class="muted">The preview could not be drawn on this device ('+escapeHtml((e&&e.message)||String(e))+'). The PDF itself is ready — use Download PDF.</p>';});};
    draw();
    m.onclick=e=>{const b=e.target.closest('[data-pv]');if(!b){if(e.target===m)closePdfPreview();return;}const a=b.dataset.pv;
      if(a==='close')closePdfPreview();
      else if(a==='dl'){const p=PDFV.parts[PDFV.idx];if(p)downloadPdfBlob(p.blob,p.name);}
      else if(a==='share'){const p=PDFV.parts[PDFV.idx];if(p)navigator.share({files:[new File([p.blob],p.name,{type:'application/pdf'})],title:p.name}).catch(err=>{if(err&&err.name!=='AbortError')handleAppError(err,'share');});}
      else if(a==='prev'&&PDFV.idx>0){PDFV.idx--;draw();}
      else if(a==='next'&&PDFV.idx<PDFV.parts.length-1){PDFV.idx++;draw();}};
  }
  /* ---------- OMR Sheet Generator ----------
     Builds a customised copy of the supplied template omr_sheet_a4_final.pdf (embedded in omr_template_3_2_2.js).
     The template's bubbles, numbering, score board and cut line are reused byte-for-byte; ONLY the old school-name / address
     text is removed from the page content and the saved School Settings are drawn in its place. Nothing leaves the device. */
  const OMR={W:595.275591,H:841.889764,HALF:420.944882,SHIFT:405.685,CX:297.64,MAXW:440,MAXCOPIES:500,NAMEY:34.81,ADDRY:49.82,LOGO:{x:24,y:21,box:35},
    /* The supplied template prints its cut line OVER Set A's last row (Q13/Q26/Q39; Q26 C-D and Q39 A-B are hidden under the label).
       'Fix' moves ONLY the cut-line graphics (dashes + scissors label) 16.4 css-px down into the free gap above Set B's header. Bubbles are never moved. */
    CUTDY:16.4,BND_FIX:428.5};
  const PDFLIB_SOURCES=['pdf-lib.min.js','https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js'];
  let omrBusy=false,omrCache=null;
  function loadPdfLib(){
    if(window.PDFLib&&window.PDFLib.PDFDocument)return Promise.resolve(window.PDFLib);
    return loadPdfLib.p||(loadPdfLib.p=(async()=>{
      for(const src of PDFLIB_SOURCES){try{await loadScriptOnce(src);if(window.PDFLib&&window.PDFLib.PDFDocument)return window.PDFLib;}catch(e){debugLog('pdf-lib',String(e.message||e));}}
      loadPdfLib.p=null;throw new Error('The PDF library could not be loaded. Connect to the internet once, or put pdf-lib.min.js next to index.html.');
    })());
  }
  const omrBin=u=>{let t='';for(let i=0;i<u.length;i+=8192)t+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return t;};
  const omrUnbin=t=>{const u=new Uint8Array(t.length);for(let i=0;i<t.length;i++)u[i]=t.charCodeAt(i);return u;};
  function omrTemplateBytes(){
    const b64=window.OMR_TEMPLATE_B64;if(!b64)throw new Error('The OMR template data file (omr_template_3_2_2.js) is missing. Keep it next to index.html.');
    const bin=atob(b64),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);return u;
  }
  /* Removes the template's own school-name and address text (4 text blocks: name + address in Set A and in Set B) from the page content,
     so the old identity does not exist anywhere in the output file. Refuses to continue if the template is not the expected one. */
  function omrStripOldIdentity(PL,doc,keep,fixCut){
    const page=doc.getPage(0),ctx=doc.context,c=page.node.Contents();
    const parts=c instanceof PL.PDFArray?c.asArray().map(r=>ctx.lookup(r)):[c];
    let txt=parts.map(st=>omrBin(PL.decodePDFRawStream(st).decode())).join('\n');
    const fonts=page.node.Resources().lookup(PL.PDFName.of('Font'),PL.PDFDict),names={};
    fonts.entries().forEach(([k,v])=>{const bf=ctx.lookup(v,PL.PDFDict).get(PL.PDFName.of('BaseFont'));names[String(k).replace(/^\//,'')]=String(bf).replace(/^\//,'').split('+').pop();});
    if(fixCut){
      const a=txt.indexOf('q\nq\n763.464567 546.141732 m\n'),lb=txt.indexOf('BT\n1 0 0 -1 411.850394 550.256967 Tm'),et=lb<0?-1:txt.indexOf('\nET',lb),e=et<0?-1:txt.indexOf('\nQ\nQ',et);
      if(a<0||lb<0||e<0||a>lb)throw new Error('The OMR template cut line was not recognised. Nothing was generated.');
      const seg=txt.slice(a,e+4),nq=(seg.match(/^q$/gm)||[]).length,nQ=(seg.match(/^Q$/gm)||[]).length;
      if(nq!==nQ)throw new Error('The OMR template cut line could not be moved safely. Nothing was generated.');
      txt=txt.slice(0,a)+'q\n1 0 0 1 0 '+OMR.CUTDY+' cm\n'+seg+'\nQ'+txt.slice(e+4);
    }
    let removed=0;
    txt=txt.replace(/BT\n[\s\S]*?\nET/g,blk=>{
      const m=/\/(\w+) [\d.]+ Tf/.exec(blk),bn=m&&names[m[1]];
      if(bn==='Noto-Sans-Ultra-Bold'||bn==='Noto-Sans-Semi-Bold'){removed++;return '';}
      /* single-set files: also drop the (already clipped, invisible) text of the other half, so it is not hidden inside the file */
      if(keep==='A'||keep==='B'){const t=/1 0 0 -1 [\d.]+ ([\d.]+) Tm/.exec(blk);if(t){const y=parseFloat(t[1])*0.75;if((keep==='A'&&y>OMR.HALF)||(keep==='B'&&y<=OMR.HALF))return '';}}
      return blk;});
    if(removed!==4)throw new Error('The OMR template was not recognised (expected 4 school-identity text blocks, found '+removed+'). Nothing was generated.');
    page.node.set(PL.PDFName.of('Contents'),ctx.register(ctx.flateStream(omrUnbin(txt))));
  }
  const omrFileSafe=t=>{const n=String(t||'').normalize('NFC').replace(/[\\/:*?"<>|\u0000-\u001f\u007f]+/g,' ').replace(/\s+/g,'_').replace(/^[._]+|[._]+$/g,'').slice(0,40).replace(/_+$/,'');return n||'School';};
  function omrConfig(){
    const set=(document.querySelector('input[name="omr-set"]:checked')||{}).value||'both',raw=($('omr-copies').value||'').trim(),fix=$('omr-fixcut').checked;
    if(!/^\d+$/.test(raw))return{err:'Number of copies must be a whole number such as 1, 10 or 50.'};
    const copies=parseInt(raw,10);
    if(copies<1)return{err:'Number of copies must be at least 1.'};
    if(copies>OMR.MAXCOPIES)return{err:`Number of copies cannot be more than ${OMR.MAXCOPIES}. Generate it in several files if you need more.`};
    return{set,copies,fix};
  }
  const omrKey=cfg=>JSON.stringify([cfg.set,cfg.copies,cfg.fix,school]);
  function omrFileName(cfg){
    const sn=omrFileSafe(school.name),part=cfg.set==='both'?'Both_Sets':'Set_'+cfg.set;
    return `${sn}_OMR_${part}${cfg.copies>1?'_'+cfg.copies+'_Copies':''}.pdf`;
  }
  function omrStatus(msg,kind){const el=$('omr-status');if(!msg){el.hidden=true;el.textContent='';return;}el.hidden=false;el.textContent=msg;el.classList.toggle('omr-err',kind==='err');}
  function omrSetBusy(on){omrBusy=on;['omr-preview-btn','omr-download-btn'].forEach(id=>{$(id).disabled=on||!schoolReady();});$('omr-copies').disabled=on;document.querySelectorAll('input[name="omr-set"]').forEach(i=>{i.disabled=on;});}
  function renderOmrGen(){
    const ok=schoolReady(),st=$('omr-state');
    st.textContent=ok?'Ready to Generate OMR Sheet':'School Settings Required';st.classList.toggle('ok',ok);
    $('omr-gate').hidden=ok;
    $('omr-school-name').textContent=ok?school.name:'School name not set';
    const a=$('omr-school-addr'),c=$('omr-school-contact'),lg=$('omr-school-logo');
    a.textContent=school.address;a.hidden=!school.address;c.textContent=school.contact;c.hidden=!school.contact;
    if(school.logo){lg.src=school.logo;lg.hidden=false;}else{lg.removeAttribute('src');lg.hidden=true;}
    $('omr-preview-btn').disabled=omrBusy||!ok;$('omr-download-btn').disabled=omrBusy||!ok;
    $('omr-preview-btn').title=ok?'':'Save the school name in School Settings first';$('omr-download-btn').title=$('omr-preview-btn').title;
  }
  /* Draws the school identity into the blank header band of one half (shift = 0 for Set A, OMR.SHIFT for Set B) */
  async function omrPrepIdentity(PL,out){
    const font=await out.embedFont(PL.StandardFonts.HelveticaBold),NAVY=PL.rgb(0.102,0.212,0.365),GREY=PL.rgb(0.29,0.333,0.408),jobs=[];
    const extra=[school.address,school.contact].filter(Boolean).join('   |   ');
    const prep=async(text,pt,color,hex,baseY)=>{
      if(isLatin(text)){let sz=pt;while(sz>6&&font.widthOfTextAtSize(text,sz)>OMR.MAXW)sz-=0.5;let t=text;while(t.length>4&&font.widthOfTextAtSize(t,sz)>OMR.MAXW)t=t.slice(0,-2);
        const w=font.widthOfTextAtSize(t,sz);return shift=>({kind:'t',text:t,size:sz,color,x:OMR.CX-w/2,y:OMR.H-(baseY+shift)});}
      const im=pdfTextImage(text,pt,true,hex),k=72/25.4;let w=im.w*k,hh=im.h*k;if(w>OMR.MAXW){hh*=OMR.MAXW/w;w=OMR.MAXW;}
      const png=await out.embedPng(im.url);return shift=>({kind:'i',img:png,w,h:hh,x:OMR.CX-w/2,y:OMR.H-(baseY+shift-pt*0.35+hh/2)});
    };
    jobs.push(await prep(school.name,14,NAVY,'#1a365d',OMR.NAMEY));
    if(extra)jobs.push(await prep(extra,9.5,GREY,'#4a5568',OMR.ADDRY));
    let logo=null;
    if(school.logo){try{const img=school.logo.indexOf('data:image/png')===0?await out.embedPng(school.logo):await out.embedJpg(school.logo),k=Math.min(OMR.LOGO.box/img.width,OMR.LOGO.box/img.height);logo={img,w:img.width*k,h:img.height*k};}catch(e){debugLog('OMR logo',String((e&&e.message)||e));}}
    return(page,shift)=>{
      jobs.forEach(j=>{const d=j(shift);if(d.kind==='t')page.drawText(d.text,{x:d.x,y:d.y,size:d.size,font,color:d.color});else page.drawImage(d.img,{x:d.x,y:d.y,width:d.w,height:d.h});});
      if(logo)page.drawImage(logo.img,{x:OMR.LOGO.x+(OMR.LOGO.box-logo.w)/2,y:OMR.H-(OMR.LOGO.y+shift+OMR.LOGO.box/2+logo.h/2),width:logo.w,height:logo.h});
    };
  }
  async function omrBuildPdf(cfg,onProgress){
    const PL=await loadPdfLib(),src=await PL.PDFDocument.load(omrTemplateBytes());
    omrStripOldIdentity(PL,src,cfg.set,cfg.fix);
    const sp=src.getPage(0),out=await PL.PDFDocument.create(),drawId=await omrPrepIdentity(PL,out);
    const both=cfg.set==='both',useA=both||cfg.set==='A',useB=both||cfg.set==='B';
    const eFull=both?await out.embedPage(sp):null;
    const bnd=cfg.fix?OMR.BND_FIX:OMR.HALF;   /* top-down y that separates the Set A sheet (with its cut line) from the Set B sheet */
    const eA=!both&&useA?await out.embedPage(sp,{left:0,bottom:OMR.H-bnd,right:OMR.W,top:OMR.H}):null;
    const eB=!both&&useB?await out.embedPage(sp,{left:0,bottom:0,right:OMR.W,top:OMR.H-bnd}):null;
    for(let i=0;i<cfg.copies;i++){
      const pg=out.addPage([OMR.W,OMR.H]);
      if(both)pg.drawPage(eFull,{x:0,y:0});
      if(eA)pg.drawPage(eA,{x:0,y:OMR.H-bnd});
      if(eB)pg.drawPage(eB,{x:0,y:0});
      if(useA)drawId(pg,0);if(useB)drawId(pg,OMR.SHIFT);
      if(i%10===9&&i+1<cfg.copies){if(onProgress)onProgress(i+1,cfg.copies);await tick();}
    }
    out.setTitle(`OMR Answer Sheet - ${school.name}`);out.setProducer('eGyan Classes - OMR Auto-Checker');out.setCreator('eGyan Classes OMR Sheet Generator');
    const bytes=await out.save();return new Blob([bytes],{type:'application/pdf'});
  }
  /* One build per distinct configuration: Preview and Download share the cached file */
  async function omrEnsurePdf(){
    if(omrBusy)return null;
    omrStatus('');$('omr-msg').hidden=true;
    if(!schoolReady()){renderOmrGen();showToast('Save the School Name in School Settings first',4000);showTab('school');return null;}
    const cfg=omrConfig();if(cfg.err){const m=$('omr-msg');m.textContent=cfg.err;m.hidden=false;$('omr-copies').focus();return null;}
    const key=omrKey(cfg);if(omrCache&&omrCache.key===key)return omrCache;
    omrSetBusy(true);
    try{
      omrStatus('Preparing the OMR sheet…');await tick();
      const blob=await omrBuildPdf(cfg,(d,t)=>omrStatus(`Generating copies… ${d} of ${t}`));
      omrCache={key,blob,name:omrFileName(cfg)};omrStatus(`✓ Ready: ${omrCache.name} (${Math.max(1,Math.round(blob.size/1024))} KB, ${cfg.copies} page${cfg.copies>1?'s':''})`);return omrCache;
    }catch(e){omrCache=null;omrStatus('Could not create the PDF: '+((e&&e.message)||String(e)),'err');handleAppError(e,'OMR sheet');return null;}
    finally{omrSetBusy(false);renderOmrGen();}
  }
  async function omrPreview(){const r=await omrEnsurePdf();if(r)openPdfPreview([{blob:r.blob,name:r.name}],'OMR Sheet Preview');}
  async function omrDownload(){const r=await omrEnsurePdf();if(r){downloadPdfBlob(r.blob,r.name);showToast('✓ '+r.name,3500);}}
  function omrShowSchoolDetails(){
    const ok=schoolReady(),row=(k,v)=>`<p class="omr-det"><span>${k}</span><b>${v?escapeHtml(v):'<i>not set</i>'}</b></p>`;
    const m=modal(`<h3>SCHOOL DETAILS</h3><div class="modal-body">${school.logo?`<img class="omr-det-logo" src="${school.logo}" alt="School logo">`:''}${row('School name',ok?school.name:'')}${row('Address',school.address)}${row('Contact',school.contact)}<p class="muted">${ok?'These saved details are printed on every OMR sheet.':'School Name is required before an OMR sheet can be generated.'}</p></div><div class="modal-actions"><button class="p9-btn" data-r="cancel" type="button">Close</button><button class="p9-btn primary" data-r="edit" type="button">Edit School Settings</button></div>`);
    m.onclick=e=>{const b=e.target.closest('[data-r]');if(b){closeModal();if(b.dataset.r==='edit'){showTab('school');setTimeout(()=>$('p9-school-in-name').focus(),50);}}else if(e.target===m)closeModal();};
  }
  function initOmrGen(){
    const th=window.OMR_TEMPLATE_THUMB;if(th){$('omr-thumb').src=th;$('omr-thumb').hidden=false;$('omr-thumb-empty').hidden=true;}
    $('omr-preview-btn').addEventListener('click',omrPreview);$('omr-download-btn').addEventListener('click',omrDownload);
    $('omr-view-school').addEventListener('click',omrShowSchoolDetails);$('p9-school-preview').addEventListener('click',omrShowSchoolDetails);
    $('omr-edit-school').addEventListener('click',()=>setTimeout(()=>$('p9-school-in-name').focus(),50));
    $('omr-copies').addEventListener('input',()=>{$('omr-msg').hidden=true;});
    renderOmrGen();
  }
  async function generateAllPdf(list,scope,isSession){
    if(!list.length){showToast('No records in this report');return;}
    if(!await ensureSchoolForReport())return;
    if(pdfBusy){showToast('A PDF is already being generated');return;}
    pdfBusy=true;lastPdfJob=()=>generateAllPdf(list,scope,isSession);
    revokePdfParts();
    try{
      await flushAllPending();const snap=list.map(r=>session.rows.find(x=>x.id===r.id)||r);
      pdfStatus(`Preparing PDF for ${snap.length} students…`);await tick();
      const made=[];
      const JsPDF=await loadJsPdf(),total=Math.ceil(snap.length/PDF_PART),base=`OMR_All_Students_${safeName(uniq(snap,'className'))}_${safeName(uniq(snap,'subject'))}_${safeName(fmtDate(uniq(snap,'date')).replace(/\//g,'-'))}`;
      for(let p=0;p<total;p++){
        const from=p*PDF_PART,chunk=snap.slice(from,from+PDF_PART),label=total>1?`Part ${p+1} of ${total}`:'';
        pdfStatus(`Processing ${from+1}–${from+chunk.length} (compressing images)…`);await primeImages(chunk.map(r=>r.id));
        const doc=new JsPDF({unit:'mm',format:'a4'});let y=39,pageRow=PDF_ROWS;
        for(let i=0;i<chunk.length;i++){
          if(pageRow>=PDF_ROWS){if(i>0)doc.addPage();pdfPageHeader(doc,snap,label,scope);pdfColHeader(doc);y=37;pageRow=0;}
          pdfRow(doc,chunk[i],from+i+1,y);y+=9;pageRow++;
          if(i%10===9){pdfStatus(`Student ${from+i+1} / ${snap.length} (part ${p+1}/${total})`);await tick();}
        }
        if(p===total-1)pdfSummary(doc,snap,y,!!isSession);
        pdfFooters(doc);
        const blob=new Blob([doc.output('arraybuffer')],{type:'application/pdf'});made.push({blob,name:`${base}${total>1?'_Part'+(p+1):''}.pdf`,from:from+1,to:from+chunk.length});await tick();
      }
      pdfParts=made;pdfStatus('');openPdfPreview(made,`All Students — ${snap.length} students`);
    }catch(e){handleAppError(e,'PDF');pdfStatus('PDF failed: '+((e&&e.message)||e)+' — your records are safe.',{retry:true});}
    finally{pdfBusy=false;}
  }
  async function studentPdf(r){
    if(!await ensureSchoolForReport())return;
    if(pdfBusy){showToast('A PDF is already being generated');return;}
    pdfBusy=true;lastPdfJob=()=>studentPdf(r);
    try{
      pdfStatus('Preparing PDF…');await flushAllPending();r=session.rows.find(x=>x.id===r.id)||r;const JsPDF=await loadJsPdf();await primeImages([r.id]);await tick();
      const doc=new JsPDF({unit:'mm',format:'a4'}),key=ANSWER_KEYS[r.set]||{},ans=rowAnswers(r);
      pdfPageHeader(doc,[r],'','');doc.setFontSize(10);
      doc.setFont('helvetica','bold');doc.text('Student Name:',10,40);doc.text('Roll No:',112,40);doc.text(`Set: ${r.set}`,178,40);doc.setFont('helvetica','normal');
      if(r.name&&isLatin(r.name))doc.text(r.name,38,40);else if(imgOk(imgOf(r,'nameImg')))doc.addImage(imgOf(r,'nameImg'),'JPEG',38,34,66,9.7);else doc.text(r.name?'(see sheet)':'Not entered',38,40);
      if(r.roll&&isLatin(r.roll))doc.text(r.roll,128,40);else if(imgOk(imgOf(r,'rollImg')))doc.addImage(imgOf(r,'rollImg'),'JPEG',128,34,19,9.7);else doc.text(r.roll?'(see sheet)':'Not entered',128,40);
      doc.setFont('helvetica','bold');doc.text(`Score: ${r.score} / ${r.total}    Percentage: ${r.pct}%    Status: ${statusText(r)}`,10,50);doc.setFont('helvetica','normal');
      doc.text(`Correct: ${r.correct}    Wrong: ${r.wrong}    Unattempted: ${r.unattempted}    Invalid/Multiple: ${r.invalid}`,10,56);
      if(reviewReason(r)){doc.setFontSize(8);doc.text('Review reason: '+reviewReason(r),10,61);doc.setFontSize(10);}
      for(let col=0;col<2;col++){const x0=10+col*97;doc.setFont('helvetica','bold');doc.setFontSize(8);[['Q',0],['Marked',12],['Key',32],['Result',46]].forEach(([t,dx])=>doc.text(t,x0+dx,67));doc.line(x0,68.5,x0+90,68.5);doc.setFont('helvetica','normal');
        for(let i=0;i<25;i++){const a=ans[col*25+i],y=74+i*8;doc.text(String(a.question),x0,y);doc.text(a.detected||'-',x0+12,y);doc.text(String(key[a.question]||'-'),x0+32,y);doc.text(pdfResultText(a,key[a.question]),x0+46,y);}}
      pdfFooters(doc);
      const blob=new Blob([doc.output('arraybuffer')],{type:'application/pdf'});pdfStatus('');
      openPdfPreview([{blob,name:`OMR_Result_${safeName(r.roll||'NA')}_${safeName(r.name||'Student')}.pdf`,from:1,to:1}],`Student Report — ${r.name||'Not entered'}`);
    }catch(e){handleAppError(e,'PDF');pdfStatus('PDF failed: '+((e&&e.message)||e)+' — your records are safe.',{retry:true});}
    finally{pdfBusy=false;}
  }
  function downloadAllPdf(){generateAllPdf(session.rows,'Current session',true);}
  function exportSession(){const h='No,Name,Roll,Class,Subject,Section,Date,Set,Correct,Wrong,Unattempted,Invalid,Score,Percent,Status\n',b=session.rows.map((r,i)=>[i+1,r.name,r.roll,r.className,r.subject,r.section,fmtDate(r.date),r.set,r.correct,r.wrong,r.unattempted,r.invalid,r.score,r.pct,r.review?'Review':'Complete'].map(csvEscape).join(',')).join('\n');downloadBlob(h+b,'omr-session.csv','text/csv');}

  /* ---------- RECORDS: search / filter / class view / edit / delete / backup ---------- */
  const REC={all:[],loaded:false,page:1,per:25,sel:new Set(),f:{q:'',cls:'',sec:'',sub:'',set:'',status:'',date:'',min:'',sort:'new'}};
  const $id=id=>document.getElementById(id);
  const classLabel=r=>`${r.className||'—'}${r.section?'-'+r.section:''}`;
  function recalc(r){const sc=calculateScore(rowAnswers(r),ANSWER_KEYS[r.set]||{});Object.assign(r,{correct:sc.correct,wrong:sc.wrong,unattempted:sc.unattempted,invalid:sc.invalid,rev:sc.review,score:sc.score,total:sc.total||50,pct:Math.round(sc.percentage),review:false});r.review=isNeedsReview(r);}
  async function loadRecords(){
    $id('p9-rec-body').innerHTML='<tr><td colspan="10" class="empty">Loading saved records…</td></tr>';
    try{REC.all=await dbAll();REC.loaded=true;}catch(e){showToast('✕ Could not read records: '+(e&&e.message||e),6000);REC.all=[];}
    renderRecords();
  }
  function filteredRecords(){
    const f=REC.f,q=f.q.trim().toLowerCase(),min=f.min===''?null:Number(f.min);
    let L=REC.all.filter(r=>(!q||`${r.name||''} ${r.roll||''} ${r.className||''} ${r.section||''} ${r.subject||''}`.toLowerCase().includes(q))&&(!f.cls||r.className===f.cls)&&(!f.sec||r.section===f.sec)&&(!f.sub||r.subject===f.sub)&&(!f.set||r.set===f.set)&&(!f.date||r.date===f.date)&&(!f.status||(f.status==='review')===!!r.review)&&(min===null||r.pct>=min));
    const cmp={new:(a,b)=>b.createdAt-a.createdAt,old:(a,b)=>a.createdAt-b.createdAt,name:(a,b)=>String(a.name||'').localeCompare(String(b.name||'')),roll:(a,b)=>(parseInt(a.roll)||1e9)-(parseInt(b.roll)||1e9),score:(a,b)=>b.score-a.score,pct:(a,b)=>b.pct-a.pct}[f.sort]||((a,b)=>b.createdAt-a.createdAt);
    return L.sort(cmp);
  }
  function fillSelect(id,label,values,cur){const el=$id(id);el.innerHTML=`<option value="">${label}</option>`+values.map(v=>`<option value="${escapeHtml(v)}"${v===cur?' selected':''}>${escapeHtml(v)}</option>`).join('');}
  function renderRecords(){
    const A=REC.all,uniqSorted=k=>[...new Set(A.map(r=>r[k]).filter(Boolean))].sort((a,b)=>String(a).localeCompare(String(b),undefined,{numeric:true}));
    const dk=r=>`${r.roll}|${r.className}|${r.section}|${r.subject}|${r.date}`,grp={};A.forEach(r=>{if(r.roll)(grp[dk(r)]=grp[dk(r)]||[]).push(r.id);});REC.dup=new Set();Object.values(grp).forEach(g=>{if(g.length>1)g.forEach(id=>REC.dup.add(id));});
    const today=new Date().toDateString(),avg=A.length?Math.round(A.reduce((t,r)=>t+r.pct,0)/A.length):0,last=A.reduce((m,r)=>Math.max(m,r.createdAt||0),0);
    $id('p9-kpi-total').textContent=A.length;$id('p9-kpi-today').textContent=A.filter(r=>new Date(r.createdAt).toDateString()===today).length;$id('p9-kpi-classes').textContent=uniqSorted('className').length;$id('p9-kpi-avg').textContent=A.length?avg+'%':'—';$id('p9-kpi-last').textContent=last?new Date(last).toLocaleString():'—';
    fillSelect('p9-f-class','All classes',uniqSorted('className'),REC.f.cls);fillSelect('p9-f-section','All sections',uniqSorted('section'),REC.f.sec);fillSelect('p9-f-subject','All subjects',uniqSorted('subject'),REC.f.sub);
    const byClass={};A.forEach(r=>{const c=r.className||'—';(byClass[c]=byClass[c]||[]).push(r);});
    $id('p9-class-cards').innerHTML=Object.keys(byClass).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true})).map(c=>{const L=byClass[c],av=Math.round(L.reduce((t,r)=>t+r.pct,0)/L.length);return `<div class="class-card"><b>Class ${escapeHtml(c)}</b><span>${L.length} students · Avg ${av}%</span><div><button class="p9-btn small" data-cls-view="${escapeHtml(c)}" type="button">View</button><button class="p9-btn small danger" data-cls-del="${escapeHtml(c)}" type="button">Delete</button></div></div>`;}).join('')||'';
    const L=filteredRecords(),pages=Math.max(1,Math.ceil(L.length/REC.per));if(REC.page>pages)REC.page=pages;const from=(REC.page-1)*REC.per,pageRows=L.slice(from,from+REC.per);
    $id('p9-rec-count').textContent=`${L.length} of ${A.length} records`;$id('p9-rec-page').textContent=`Page ${REC.page} / ${pages}`;
    $id('p9-rec-prev').disabled=REC.page<=1;$id('p9-rec-next').disabled=REC.page>=pages;$id('p9-rec-del-sel').textContent=`Delete Selected (${REC.sel.size})`;$id('p9-rec-del-sel').disabled=!REC.sel.size;
    $id('p9-rec-empty').hidden=A.length>0;$id('p9-rec-tablewrap').hidden=!A.length;
    const draw=()=>{$id('p9-rec-body').innerHTML=pageRows.map(r=>`<tr><td data-l=""><input type="checkbox" data-sel="${escapeHtml(r.id)}" aria-label="Select"${REC.sel.has(r.id)?' checked':''}></td><td data-l="Student">${dispCell(r.name,imgOf(r,'nameImg'))}</td><td data-l="Roll">${dispCell(r.roll,imgOf(r,'rollImg'))}</td><td data-l="Class">${escapeHtml(classLabel(r))}</td><td data-l="Subject">${escapeHtml(r.subject||'—')}</td><td data-l="Score"><b>${r.score}/${r.total}</b></td><td data-l="%">${r.pct}%</td><td data-l="Date">${escapeHtml(fmtDate(r.date))}</td><td data-l="Status">${escapeHtml(statusText(r))}${reviewReason(r)?`<small class="reason">${escapeHtml(reviewReason(r))}</small>`:''}${detailsMissing(r)?'<small class="reason">name/roll not entered</small>':''}${REC.dup&&REC.dup.has(r.id)?'<small class="reason">⚠ duplicate roll no.</small>':''}</td><td class="acts"><button class="p9-btn small" data-act="view" data-id="${escapeHtml(r.id)}" type="button">View</button><button class="p9-btn small" data-act="pdf" data-id="${escapeHtml(r.id)}" type="button">Preview</button><button class="p9-btn small danger" data-act="del" data-id="${escapeHtml(r.id)}" type="button">Delete</button></td></tr>`).join('');};draw();const need=pageRows.map(r=>r.id).filter(id=>!IMG.has(id));if(need.length)primeImages(need).then(n=>{if(n)draw();}).catch(e=>handleAppError(e,'load images'));
  }
  async function saveRecord(r){r.updatedAt=Date.now();const light=splitRec(r),sr=session.rows.find(x=>x.id===r.id);if(sr){Object.assign(sr,light,{nameImg:r.nameImg||'',rollImg:r.rollImg||''});if(!await flushRow(sr,true))throw new Error('Could not save the record');}else{await flushAllPending();await dbPut(r);IMG.set(r.id,{nameImg:r.nameImg||'',rollImg:r.rollImg||''});}const i=REC.all.findIndex(x=>x.id===r.id);if(i>=0)REC.all[i]=light;renderSession();if(REC.loaded)renderRecords();showToast('✓ Record updated');}
  async function openRecord(id){
    const r0=REC.all.find(x=>x.id===id);if(!r0)return;try{await primeImages([id]);}catch(e){handleAppError(e,'load images');}const r=Object.assign(JSON.parse(JSON.stringify(r0)),{nameImg:imgOf(r0,'nameImg'),rollImg:imgOf(r0,'rollImg')}),key=()=>ANSWER_KEYS[r.set]||{};
    const qrows=()=>Array.from({length:50},(_,i)=>{const q=i+1,d=r.ans[i],k=key()[q];return `<label class="qcell ${d==='-'?'':(d===k?'good':'bad')}">Q${q}<select data-q="${q}">${['-','A','B','C','D'].map(o=>`<option${o===d?' selected':''}>${o}</option>`).join('')}</select><small>${k||''}</small></label>`;}).join('');
    const m=modal(`<h3>STUDENT RECORD</h3><div class="modal-body rec-edit"><div class="rec-stats"><b id="rv-score">${r.score} / ${r.total}</b><span id="rv-pct">${r.pct}%</span><span id="rv-split">Correct ${r.correct} · Wrong ${r.wrong} · Unattempted ${r.unattempted} · Invalid ${r.invalid}</span></div>
      <div class="rec-fields"><label>Student Name${r.nameImg?`<img class="field-crop" src="${r.nameImg}" alt="">`:''}<input data-f="name" value="${escapeHtml(r.name||'')}"></label><label>Roll No.${r.rollImg?`<img class="field-crop" src="${r.rollImg}" alt="">`:''}<input data-f="roll" value="${escapeHtml(r.roll||'')}"></label><label>Class<input data-f="className" value="${escapeHtml(r.className||'')}"></label><label>Section<input data-f="section" value="${escapeHtml(r.section||'')}"></label><label>Subject<input data-f="subject" value="${escapeHtml(r.subject||'')}"></label><label>Date<input data-f="date" type="date" value="${escapeHtml(r.date||'')}"></label><label class="chk"><input type="checkbox" data-f="reviewed"${r.reviewed?' checked':''}> Mark as reviewed</label><label class="chk"><input type="checkbox" data-f="flagged"${r.flagged?' checked':''}> Needs review (flag)</label><label>Set<select data-f="set"><option${r.set==='A'?' selected':''}>A</option><option${r.set==='B'?' selected':''}>B</option></select></label></div>
      <p class="muted">${reviewReason(r)?'Review reason: '+escapeHtml(reviewReason(r))+'. ':''}Question-wise answers (change a bubble if the scan was wrong; score updates automatically):</p><div class="qgrid" id="rv-q">${qrows()}</div></div>
      <div class="modal-actions"><button class="p9-btn" data-r="cancel" type="button">Close</button><button class="p9-btn" data-r="pdf" type="button">Preview PDF</button><button class="p9-btn danger" data-r="del" type="button">Delete</button><button class="p9-btn primary" data-r="save" type="button">Save Changes</button></div>`);
    const refresh=()=>{recalc(r);$id('rv-score').textContent=`${r.score} / ${r.total}`;$id('rv-pct').textContent=r.pct+'%';$id('rv-split').textContent=`Correct ${r.correct} · Wrong ${r.wrong} · Unattempted ${r.unattempted} · Invalid ${r.invalid}`;$id('rv-q').innerHTML=qrows();};
    m.addEventListener('change',e=>{const f=e.target.closest('[data-f]'),q=e.target.closest('[data-q]');if(f){r[f.dataset.f]=f.type==='checkbox'?f.checked:f.value.trim();if(['set','reviewed','flagged'].includes(f.dataset.f))refresh();}else if(q){const i=Number(q.dataset.q)-1,v=q.value,a=r.ans.split(''),t=r.st.split('');a[i]=v;t[i]=v==='-'?'u':'d';r.ans=a.join('');r.st=t.join('');refresh();}});
    m.onclick=async e=>{const b=e.target.closest('[data-r]');if(!b){if(e.target===m)closeModal();return;}const act=b.dataset.r;
      if(act==='cancel'){closeModal();}
      else if(act==='pdf'){studentPdf(r);}
      else if(act==='save'){try{await saveRecord(r);closeModal();}catch(err){showToast('✕ Save failed: '+(err&&err.message||err),6000);}}
      else if(act==='del'){closeModal();deleteRecords([id]);}};
  }
  async function deleteRecords(ids){
    if(deleteRecords.busy)return;deleteRecords.busy=true;
    try{await deleteRecordsInner(ids);}finally{deleteRecords.busy=false;}
  }
  async function deleteRecordsInner(ids){
    const L=ids.map(id=>REC.all.find(r=>r.id===id)).filter(Boolean);if(!L.length)return;
    const body=L.length===1?`<p><b>${escapeHtml(L[0].name||'Student')}</b> · Roll ${escapeHtml(L[0].roll||'—')}<br>${L[0].score}/${L[0].total} · Class ${escapeHtml(classLabel(L[0]))}</p><p>This action cannot be undone.</p>`:`<p>Delete <b>${L.length}</b> selected student records?</p><p>This action cannot be undone.</p>`;
    if(!await confirmModal({title:L.length===1?'DELETE STUDENT?':'DELETE SELECTED RECORDS?',body}))return;
    const set=new Set(L.map(r=>r.id)),touched=session.rows.filter(r=>set.has(r.id));
    try{await flushAllPending();touched.forEach(r=>{r._deleted=true;});await dbDeleteMany(L.map(r=>r.id));if(set.has(state.currentScanId))resetCurrentScan();REC.all=REC.all.filter(r=>!set.has(r.id));session.rows=session.rows.filter(r=>!set.has(r.id));set.forEach(id=>{REC.sel.delete(id);IMG.delete(id);});renderSession();renderRecords();showToast(`✓ Deleted ${L.length} record(s)`);}
    catch(e){touched.forEach(r=>{r._deleted=false;});handleAppError(e,'delete — nothing was removed');renderSession();renderRecords();}
  }
  async function deleteClass(c){
    if(deleteClass.busy)return;deleteClass.busy=true;
    try{await deleteClassInner(c);}finally{deleteClass.busy=false;}
  }
  async function deleteClassInner(c){
    const L=REC.all.filter(r=>(r.className||'—')===c);if(!L.length)return;
    if(!await confirmModal({title:`DELETE CLASS ${c} DATA?`,body:`<p>Delete all saved results for <b>Class ${escapeHtml(c)}</b>?</p><p>This removes <b>${L.length}</b> student records, their results and stored name/roll images. Other classes are not touched.</p>`,confirmText:'Continue'}))return;
    if(!await confirmModal({title:'FINAL CONFIRMATION',body:`<p>Permanently delete <b>${L.length}</b> records of <b>Class ${escapeHtml(c)}</b>?</p><p>Tip: use Backup first if you may need them again.</p>`}))return;
    const set=new Set(L.map(r=>r.id)),touched=session.rows.filter(r=>set.has(r.id));
    try{await flushAllPending();touched.forEach(r=>{r._deleted=true;});await dbDeleteMany(L.map(r=>r.id));if(set.has(state.currentScanId))resetCurrentScan();REC.all=REC.all.filter(r=>!set.has(r.id));session.rows=session.rows.filter(r=>!set.has(r.id));set.forEach(id=>IMG.delete(id));REC.sel.clear();renderSession();renderRecords();showToast(`✓ Class ${c} data deleted`);}
    catch(e){touched.forEach(r=>{r._deleted=false;});handleAppError(e,'delete class — nothing was removed');renderSession();renderRecords();}
  }
  /* ---------- Data management: stats, backup, restore, clear ---------- */
  async function renderStorage(){
    let all=[];try{all=await dbAll();}catch(_){}
    let used=0;try{if(navigator.storage&&navigator.storage.estimate){used=(await navigator.storage.estimate()).usage||0;}}catch(_){}
    if(!used)used=all.reduce((t,r)=>t+JSON.stringify(r).length,0);
    $id('p9-st-students').textContent=all.length.toLocaleString();$id('p9-st-classes').textContent=new Set(all.map(r=>r.className)).size;$id('p9-st-size').textContent=(used/1048576).toFixed(1)+' MB';
  }
  async function backupData(full){
    try{
      await flushAllPending();const all=await dbAll(),imgs={};if(full)(await dbAllImages()).forEach(i=>{imgs[i.id]=i;});
      const settings={answerKeys:ANSWER_KEYS,calibration:state.calibration,exam:{className:exam.className,subject:exam.subject,section:exam.section,date:exam.date},sessionId,school:schoolReady()?school:undefined};
      const parts=[`{"app":"OMR_AutoChecker","backupVersion":2,"full":${!!full},"exportedAt":${JSON.stringify(new Date().toISOString())},"count":${all.length},"settings":${JSON.stringify(settings)},"records":[`];
      all.forEach((r,i)=>{const o=full&&imgs[r.id]?Object.assign({},r,{nameImg:imgs[r.id].nameImg,rollImg:imgs[r.id].rollImg}):r;parts.push((i?',':'')+JSON.stringify(o));});parts.push(']}');
      const d=new Date(),ds=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`,url=URL.createObjectURL(new Blob(parts,{type:'application/json'})),a=document.createElement('a');
      a.href=url;a.download=`OMR_Backup_${full?'Full':'DataOnly'}_${ds}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);showToast(`✓ ${full?'Full':'Data-only'} backup created (${all.length} records)`);
    }catch(e){handleAppError(e,'backup');}
  }
  const ID_RE=/^[A-Za-z0-9_-]{1,64}$/;
  const cleanStr=(v,max)=>String(v==null?'':v).replace(/[\u0000-\u001f<>"'`]/g,'').slice(0,max||80);
  const cleanImg=v=>(typeof v==='string'&&v.length<=120000&&/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(v))?v:'';
  function sanitizeRecord(r){
    if(!r||typeof r!=='object'||!ID_RE.test(String(r.id||''))||!/^[ABCD-]{50}$/.test(String(r.ans||''))||!/^[dulmx]{50}$/.test(String(r.st||''))||(r.set!=='A'&&r.set!=='B'))return null;
    const num=(v,lo,hi)=>{v=Number(v);return Number.isFinite(v)&&v>=lo&&v<=hi?Math.round(v):null;};
    const f={correct:num(r.correct,0,50),wrong:num(r.wrong,0,50),unattempted:num(r.unattempted,0,50),invalid:num(r.invalid,0,50),score:num(r.score,0,50),pct:num(r.pct,0,100)};
    if(Object.values(f).some(v=>v===null)||f.correct+f.wrong+f.unattempted+f.invalid>50)return null;
    const t=num(r.createdAt,0,4e12)||Date.now();
    const o=Object.assign({id:String(r.id),sessionId:ID_RE.test(String(r.sessionId||''))?String(r.sessionId):'imported',name:cleanStr(r.name,80),roll:cleanStr(r.roll,20),className:cleanStr(r.className,20),section:cleanStr(r.section,10),subject:cleanStr(r.subject,40),date:/^\d{4}-\d{2}-\d{2}$/.test(String(r.date||''))?r.date:'',set:r.set,ans:r.ans,st:r.st,total:50,rev:num(r.rev,0,50)||0,createdAt:t,updatedAt:num(r.updatedAt,0,4e12)||t,flagged:r.flagged===true,reviewed:r.reviewed===true,nameImg:cleanImg(r.nameImg),rollImg:cleanImg(r.rollImg)},f);
    o.review=isNeedsReview(o);return o;
  }
  const validRecord=r=>!!sanitizeRecord(r);
  function validateBackupSettings(st){
    const out={},errs=[];
    if(st===undefined||st===null)return{out,errs};
    if(typeof st!=='object'||Array.isArray(st))return{out,errs:['settings: wrong structure']};
    if(st.answerKeys!==undefined){
      const ak=st.answerKeys;
      if(!ak||typeof ak!=='object'||Array.isArray(ak))errs.push('answer keys: wrong structure');
      else{const clean={};
        for(const k of Object.keys(ak)){
          if(k!=='A'&&k!=='B'){errs.push(`answer keys: unknown set "${k}"`);continue;}
          const m=ak[k];if(!m||typeof m!=='object'||Array.isArray(m)){errs.push(`answer keys: Set ${k} is not a question map`);continue;}
          const c={};for(const q of Object.keys(m)){const n=Number(q);if(!Number.isInteger(n)||n<1||n>OMR_CONFIG.questions||String(n)!==q||!(m[q]===''||OMR_CONFIG.options.includes(m[q]))){errs.push(`answer keys: Set ${k} question ${q} has an invalid answer`);break;}c[q]=m[q];}
          clean[k]=c;}
        out.answerKeys=clean;}
    }
    if(st.calibration!==undefined){
      const e=validateCalibration(st.calibration);
      if(e.length)errs.push('calibration: '+e[0]+(e.length>1?` (+${e.length-1} more)`:''));
      else out.calibration={TBWS_CLASS_7_SET_A:st.calibration.TBWS_CLASS_7_SET_A,TBWS_CLASS_7_SET_B:st.calibration.TBWS_CLASS_7_SET_B};
    }
    if(st.exam!==undefined){
      const x=st.exam;if(!x||typeof x!=='object'||Array.isArray(x))errs.push('exam details: wrong structure');
      else out.exam={className:cleanStr(x.className,20),subject:cleanStr(x.subject,40),section:cleanStr(x.section,10),date:/^\d{4}-\d{2}-\d{2}$/.test(String(x.date||''))?x.date:todayISO()};
    }
    if(st.school!==undefined){
      const x=st.school;if(!x||typeof x!=='object'||Array.isArray(x))errs.push('school details: wrong structure');
      else{const sc=normalizeSchool(x),e=validateSchoolName(sc.name);if(e)errs.push('school details: '+e);else out.school=sc;}
    }
    return{out,errs};
  }
  async function restoreData(file){
    if(!file)return;
    let data;try{data=JSON.parse(await file.text());}catch(_){showToast('✕ This is not a valid backup file',5000);return;}
    const ver=data&&(data.backupVersion||data.version);
    if(!data||data.app!=='OMR_AutoChecker'||!Array.isArray(data.records)||![1,2].includes(ver)){showToast('✕ This is not a supported OMR Auto-Checker backup',5000);return;}
    if(data.records.length>20000){showToast('✕ Backup has too many records (max 20000)',5000);return;}
    const sv=validateBackupSettings(data.settings);
    if(sv.errs.length){handleAppError(new Error('Backup rejected — '+sv.errs.slice(0,3).join('; ')),'restore');return;}
    const seen=new Set();let dup=0;
    const good=data.records.map(sanitizeRecord).filter(r=>{if(!r)return false;if(seen.has(r.id)){dup++;return false;}seen.add(r.id);return true;}),bad=data.records.length-good.length;
    if(!good.length){showToast('✕ No valid records in this backup',5000);return;}
    const choice=await choiceModal({title:'RESTORE BACKUP',body:`<p><b>${good.length}</b> valid records found. Rejected: <b>${bad}</b>${dup?` (including ${dup} duplicate IDs)`:''}. Backup format v${ver}.</p><p><b>Merge</b> adds only records whose ID is not already saved (nothing is overwritten; settings are kept).<br><b>Replace</b> swaps ALL current records and settings in one safe step; if it fails, nothing changes.</p>`,choices:[{id:'cancel',label:'Cancel'},{id:'merge',label:'Merge',cls:'primary'},{id:'replace',label:'Replace',cls:'danger'}]});
    if(choice==='cancel')return;
    try{
      await flushAllPending();
      if(choice==='replace'){
        if(!await confirmModal({title:'REPLACE ALL DATA?',body:'<p>All current saved records and settings are replaced by the backup.</p>',confirmText:'Replace'}))return;
        const keys={[ANSWER_KEY_STORAGE]:sv.out.answerKeys,[STORAGE.calibration]:sv.out.calibration,[EXAM_KEY]:sv.out.exam&&Object.assign({},sv.out.exam,{started:true}),[SCHOOL_KEY]:sv.out.school};
        const old={};Object.keys(keys).forEach(k=>{old[k]=localStorage.getItem(k);});
        const undo=()=>Object.keys(old).forEach(k=>{try{old[k]===null?localStorage.removeItem(k):localStorage.setItem(k,old[k]);}catch(_){}});
        try{Object.keys(keys).forEach(k=>{if(keys[k]!==undefined)localStorage.setItem(k,JSON.stringify(keys[k]));});await dbReplaceAll(good);}
        catch(e){undo();throw e;}
        session.rows.forEach(r=>{r._deleted=true;});
        showToast('✓ Backup restored — reloading…');setTimeout(()=>location.reload(),1200);return;
      }
      const have=new Set((await dbAll()).map(r=>r.id)),add=good.filter(r=>!have.has(r.id));await dbPutMany(add);
      REC.loaded=false;IMG.clear();session.rows=(await dbBySession(sessionId)).sort((a,b)=>a.createdAt-b.createdAt).map(r=>Object.assign(r,{_saved:true}));renderSession();if(!$id('tab-records').hidden)loadRecords();renderStorage();showToast(`✓ Backup merged (${add.length} added, ${good.length-add.length} already present)`);
    }catch(e){handleAppError(e,'restore — your current data was not changed');}
  }
  async function clearAllData(){
    const n=await dbCount().catch(()=>0);
    const choice=await choiceModal({title:'CLEAR DATA',body:`<p><b>Clear scanned results only</b> deletes the ${n} saved student records, their images and the session list. Answer keys, calibration and exam details are kept.</p><p><b>Clear ALL data</b> also deletes answer keys, calibration and exam details stored on this device, and reloads the app.</p><p>Create a backup first if you may need anything.</p>`,choices:[{id:'cancel',label:'Cancel'},{id:'results',label:'Clear results only',cls:'danger'},{id:'all',label:'Clear ALL data',cls:'danger'}]});
    if(choice==='cancel')return;
    if(!await confirmModal({title:'FINAL CONFIRMATION',body:choice==='all'?'<p>Permanently delete records AND all settings on this device?</p>':`<p>Permanently delete ${n} saved records?</p>`}))return;
    const failed=[];await flushAllPending();session.rows.forEach(r=>{r._deleted=true;});resetCurrentScan();
    try{await dbClear();if(await dbCount()!==0)failed.push('some database records remain');}catch(e){failed.push('database: '+((e&&e.message)||e));}
    const keys=[STORAGE.results,'p9_session_v2','p9_failed','p9_session_id'];if(choice==='all')keys.push(ANSWER_KEY_STORAGE,STORAGE.calibration,EXAM_KEY);
    keys.forEach(k=>{try{localStorage.removeItem(k);if(localStorage.getItem(k)!==null)failed.push(k);}catch(e){failed.push(k);}});
    if(failed.length){handleAppError(new Error('Not everything could be deleted: '+failed.join(', ')),'clear data');renderStorage();return;}
    IMG.clear();REC.all=[];REC.sel.clear();resetSessionCounters();
    if(choice==='all'){showToast('✓ All data deleted — reloading…');setTimeout(()=>location.reload(),900);return;}
    sessionId='S'+Date.now();try{localStorage.setItem('p9_session_id',sessionId);}catch(_){}
    renderSession();renderRecords();renderStorage();showToast('✓ Scanned results deleted (settings kept)');
  }
  window.p9Debug={geometry(){const p=state.calibration.TBWS_CLASS_7_SET_A,out=[];let q=1;p.rowCountByColumn.forEach((n,c)=>{for(let r=0;r<n;r++)out.push({q:q++,col:c+1,row:r+1,y:+rowY(p,r).toFixed(4),x:[0,1,2,3].map(k=>+p.bubbleCentersX[c*4+k].toFixed(4)).join(', ')});});console.table(out);return out;}};

  function showTab(name){
    ['scan','records','data','school','omr'].forEach(t=>{$id('tab-'+t).hidden=t!==name;});
    document.querySelectorAll('[data-tab]').forEach(b=>{const on=b.dataset.tab===name;b.classList.toggle('active',on);b.setAttribute('aria-current',on?'page':'false');});
    if(name==='records')loadRecords();if(name==='data')renderStorage();window.scrollTo({top:0});
  }
  function resetRecordFilters(){
    Object.assign(REC.f,{q:'',cls:'',sec:'',sub:'',set:'',status:'',date:'',min:'',sort:'new'});
    ['search','class','section','subject','set','status','date','min'].forEach(k=>{const el=document.getElementById('p9-f-'+k);if(el)el.value='';});
    const so=document.getElementById('p9-f-sort');if(so)so.value='new';
    const sa=document.getElementById('p9-sel-all');if(sa)sa.checked=false;REC.sel.clear();REC.page=1;renderRecords();
  }
  function bindRecords(){
    document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>showTab(b.dataset.tab)));
    document.querySelectorAll('[data-goto]').forEach(b=>b.addEventListener('click',()=>showTab(b.dataset.goto)));
    const F=REC.f,bind=(id,key,ev='input')=>$id(id).addEventListener(ev,e=>{F[key]=e.target.value;REC.page=1;renderRecords();});
    bind('p9-f-search','q');bind('p9-f-class','cls','change');bind('p9-f-section','sec','change');bind('p9-f-subject','sub','change');bind('p9-f-set','set','change');bind('p9-f-status','status','change');bind('p9-f-date','date','change');bind('p9-f-min','min');bind('p9-f-sort','sort','change');
    $id('p9-f-clear').addEventListener('click',resetRecordFilters);
    $id('p9-rec-prev').addEventListener('click',()=>{REC.page--;renderRecords();});$id('p9-rec-next').addEventListener('click',()=>{REC.page++;renderRecords();});
    $id('p9-rec-body').addEventListener('click',e=>{const c=e.target.closest('[data-sel]');if(c){c.checked?REC.sel.add(c.dataset.sel):REC.sel.delete(c.dataset.sel);$id('p9-rec-del-sel').textContent=`Delete Selected (${REC.sel.size})`;$id('p9-rec-del-sel').disabled=!REC.sel.size;return;}const b=e.target.closest('[data-act]');if(!b)return;const id=b.dataset.id;if(b.dataset.act==='view')openRecord(id);else if(b.dataset.act==='del')deleteRecords([id]);else if(b.dataset.act==='pdf'){const r=REC.all.find(x=>x.id===id);if(!r)return;studentPdf(r);}});
    $id('p9-class-cards').addEventListener('click',e=>{const v=e.target.closest('[data-cls-view]'),d=e.target.closest('[data-cls-del]');if(v){F.cls=v.dataset.clsView;REC.page=1;renderRecords();$id('p9-rec-list').scrollIntoView({behavior:'smooth'});}else if(d)deleteClass(d.dataset.clsDel);});
    $id('p9-rec-del-sel').addEventListener('click',()=>deleteRecords([...REC.sel]));
    $id('p9-rec-pdf').addEventListener('click',()=>{const L=filteredRecords();generateAllPdf(L,`Filtered records (${L.length} of ${REC.all.length} saved)`,false);});$id('p9-pdf-status').addEventListener('click',e=>{if(e.target.closest('[data-pdf-close]')){revokePdfParts();pdfStatus('');}else if(e.target.closest('[data-pdf-retry]')){if(lastPdfJob)lastPdfJob();}else{const b=e.target.closest('[data-part]');if(b&&pdfParts[b.dataset.part])triggerDownload(pdfParts[b.dataset.part].url,pdfParts[b.dataset.part].name);}});$id('p9-save-retry').addEventListener('click',retrySave);
    $id('p9-sel-all').addEventListener('change',e=>{const L=filteredRecords().slice((REC.page-1)*REC.per,REC.page*REC.per);L.forEach(r=>e.target.checked?REC.sel.add(r.id):REC.sel.delete(r.id));renderRecords();});
    $id('p9-backup').addEventListener('click',()=>backupData(true));$id('p9-backup-lite').addEventListener('click',()=>backupData(false));$id('p9-restore').addEventListener('click',()=>$id('p9-restore-file').click());$id('p9-restore-file').addEventListener('change',e=>{restoreData(e.target.files&&e.target.files[0]);e.target.value='';});$id('p9-clear-data').addEventListener('click',clearAllData);
    $id('p9-opencv-retry').addEventListener('click',loadOpenCV);
    $id('p9-sess-search').addEventListener('input',e=>{SESS.q=e.target.value;SESS.page=1;drawSessionBody();});
    $id('p9-sess-prev').addEventListener('click',()=>{SESS.page--;drawSessionBody();});$id('p9-sess-next').addEventListener('click',()=>{SESS.page++;drawSessionBody();});
    const opt=$id('p9-opt-unatt');opt.checked=REVIEW_ON_UNATTEMPTED;
    opt.addEventListener('change',async e=>{REVIEW_ON_UNATTEMPTED=e.target.checked;try{localStorage.setItem('p9_review_unatt',REVIEW_ON_UNATTEMPTED?'1':'0');}catch(_){}try{await flushAllPending();const all=await dbAll();all.forEach(r=>{r.review=isNeedsReview(r);});await dbPutMany(all);session.rows.forEach(r=>{r.review=isNeedsReview(r);});REC.loaded=false;renderSession();showToast('✓ Review policy updated for all saved records');}catch(err){handleAppError(err,'review policy');}});
    initStore();
  }

  /* ---------- Live sheet presence from the printed bubbles (no paper edges needed) ---------- */
  function gridPresence(frame){
    const m=frame.mat,w=m.cols,h=m.rows,d=m.data,g=new Uint8Array(w*h);
    for(let i=0,j=0;i<w*h;i++,j+=4)g[i]=(d[j]*77+d[j+1]*150+d[j+2]*29)>>8;
    const C=bubbleCandidates(g,w,h);
    if(C.length<60)return null;
    let x0=1e9,y0=1e9,x1=-1,y1=-1;C.forEach(c=>{x0=Math.min(x0,c.x);x1=Math.max(x1,c.x);y0=Math.min(y0,c.y);y1=Math.max(y1,c.y);});
    return{quad:[{x:x0,y:y0},{x:x1,y:y0},{x:x1,y:y1},{x:x0,y:y1}],quality:{score:Math.min(100,C.length/2)},full:C.length>330,count:C.length};
  }

  function resultSet(){return state.resultSet||(state.selectedSet==='B'?'B':'A');}

  function captureAndAnalyze(){
    if(!requireExam())return;
    if(state.scanning||!state.cameraRunning)return;
    if(!ensureAnswerKeyForSet(state.selectedSet==='AUTO'?null:state.selectedSet))return;
    const high=readHighResolutionFrame();
    if(!high){showToast('Camera frame is not ready.');return;}
    processOMRImage(high.imageData,high.width,high.height,'camera');
  }

  async function handleGalleryFile(file){
    if(!requireExam()){els.galleryInput.value='';return;}
    if(!file)return;
    if(!state.openCVReady){showToast('OpenCV is still loading. Please wait.');return;}
    if(!/^image\//i.test(file.type)){showToast('Please select an image file.');return;}
    if(state.scanning){showToast('A scan is already being processed.');return;}
    const url=URL.createObjectURL(file);
    try{
      const img=await loadImageFromUrl(url);
      const maxDim=4096;
      const scale=Math.min(1,maxDim/Math.max(img.naturalWidth,img.naturalHeight));
      const w=Math.max(1,Math.round(img.naturalWidth*scale));
      const h=Math.max(1,Math.round(img.naturalHeight*scale));
      const canvas=els.uploadCanvas;
      canvas.width=w;canvas.height=h;
      const ctx=canvas.getContext('2d',{willReadFrequently:true});
      ctx.clearRect(0,0,w,h);ctx.drawImage(img,0,0,w,h);
      const imageData=ctx.getImageData(0,0,w,h);
      debugLog('Gallery image loaded',{name:file.name,type:file.type,width:w,height:h});
      processOMRImage(imageData,w,h,'gallery');
    }catch(err){
      debugLog('Gallery load failed',err&&err.message||String(err));
      showToast('Could not read that image. Please choose a clear OMR photo.');
    }finally{
      URL.revokeObjectURL(url);
      els.galleryInput.value='';
    }
  }

  function loadImageFromUrl(url){
    return new Promise((resolve,reject)=>{
      const img=new Image();
      img.onload=()=>resolve(img);
      img.onerror=()=>reject(new Error('Image decode failed'));
      img.src=url;
    });
  }

  async function processOMRImage(imageData,width,height,sourceLabel){
    if(!state.openCVReady){showToast('OpenCV is not ready yet — wait or press Retry',4000);return;}
    if(state.scanning)return;
    if(window.EgyanLicense&&!window.EgyanLicense.gate())return;   /* licence gate: no NEW evaluation without a trial credit or an active licence */
    state.scanning=true;
    els.error.hidden=true;
    els.scanBtn.disabled=true;
    els.galleryBtn.disabled=true;
    setStatus('live',sourceLabel==='gallery'?'Analyzing uploaded OMR…':'Capturing high-resolution frame…');
    const t0=performance.now(),epoch=state.epoch||0;state.detected=(state.detected||0)+1;
    let inputMat=null,warp=null,source=null;
    try{
      setStatus('live','PROCESSING…');
      showToast('Scanning… please wait',60000);
      await new Promise(r=>setTimeout(r,60));
      inputMat=cv.matFromImageData(imageData);
      state.matsCreated++;
      let detection=detectDocument(inputMat,width,height);
      const reg=tryRegisterGrid(imageData,width,height);
      const looksFull=!reg&&detection&&isFullPage(detection.quad,inputMat);
      if(!detection&&reg){detection=wholeImageDetection(inputMat,width,height);debugLog('No sheet outline; aligned using the printed bubble grid');}
      if(!detection)throw new Error('Layout not detected. Show one OMR half (Set A or B) clearly, flat and fully inside the frame.');
      const quality=detection.quality;
      if(quality.sharpness<QUALITY_CONFIG.minSharpness)throw new Error('Image is blurry. Retake the photo with the OMR flat and steady.');
      if(quality.brightness<QUALITY_CONFIG.minBrightness||quality.brightness>QUALITY_CONFIG.maxBrightness)throw new Error('Lighting is not suitable. Avoid glare and very dark shadows.');
      if(quality.contrast<QUALITY_CONFIG.minContrast)throw new Error('OMR contrast is too low. Improve lighting and try again.');
      if(quality.coverage<QUALITY_CONFIG.minDocumentCoverage)throw new Error('OMR is too small in the image. Move closer or crop around the sheet.');

      const mode=reg?'half':(looksFull?'full':'half');
      warp=reg?warpByGrid(imageData,reg.Hfull):warpDocument(imageData,width,height,detection.quad,mode);
      if(!warp||!warp.mat)throw new Error('Perspective correction failed.');
      let selected=resolveSetForScan(mode,warp.mat);
      if(mode==='full'){
        const split=splitFullPage(warp.mat);
        try{
          if(selected==='A')source=split.top.clone();
          else if(selected==='B')source=split.bottom.clone();
          else throw new Error('Full A4 page detected. Select Set A or Set B before scanning.');
        }finally{deleteMat(split.top);deleteMat(split.bottom);}
      }else{
        selected=selected||detectSetFromHalf(warp.mat);
        if(!selected)throw new Error('Set A/B could not be reliably identified. Select Set A or Set B manually.');
        source=warp.mat.clone();
      }

      if(!ensureAnswerKeyForSet(selected))throw new Error(`Answer Key for Set ${selected} is not configured. Open Answer Key Configuration and enter all 50 answers.`);
      state.resultSet=selected;
      els.setNote.textContent=`Scored as Set ${selected}.`;
      const profile=state.calibration[selected==='A'?'TBWS_CLASS_7_SET_A':'TBWS_CLASS_7_SET_B'];
      const results=analyzeAllQuestions(source,profile,selected);
      const student=extractStudentInfo(source,profile);
      const score=calculateScore(results,ANSWER_KEYS[selected]);
      if((state.epoch||0)!==epoch){debugLog('Scan discarded: data was cleared while processing');return;}
      if(state.currentWarp){deleteMat(state.currentWarp);state.currentWarp=null;}
      state.currentWarp=source.clone();
      state.currentMode=mode;
      state.currentResults=results;
      state.currentStudent=student;
      state.currentScanId=makeScanId();
      if(window.EgyanLicense)window.EgyanLicense.recordEvaluation(state.currentScanId);   /* one successful evaluation = one copy (idempotent per scan id) */
      state.saved=false;
      state.lastQuality=quality;
      drawResultOverlay(state.currentWarp,results,ANSWER_KEYS[selected]);
      showResults(score,selected,quality,mode);
      els.error.hidden=true;
      setStatus('live','Scan complete ✓');
      state.needRemoval=true;state.absentFrames=0;state.stableFrames=0;state.prevQuad=null;
      const needsReview=isNeedsReview(rowFromCurrent());{const ms=Math.round(performance.now()-t0);debugLog('Scan time ms',ms);(state.scanTimes=state.scanTimes||[]).push(ms);if(state.scanTimes.length>20)state.scanTimes.shift();}
      const sc=calculateScore(results,ANSWER_KEYS[selected]);
      sessionAdd(Object.assign({id:state.currentScanId,name:'',roll:'',nameImg:(student.crops||{}).name||'',rollImg:(student.crops||{}).rollNo||''},rowFromCurrent()));
      if((state.batch||state.autoScan)&&state.cameraRunning){
        if(needsReview){state.holdReview=true;showToast('Please review this scan, then Save & Scan Next',5000);}
        else{saveOMRResult().then(ok=>setStatus(ok?'live':'error',ok?'SCAN COMPLETE ✓ SAVED':'SAVE FAILED — Retry Save'));}
      }
      if(state.batch){
        state.batchStats.scanned++;state.batchStats.successful++;
        if(results.some(r=>['low-confidence','multiple','unattempted'].includes(r.status)))state.batchStats.review++;
        updateBatchUI();
      }
      debugLog('Scan completed',{source:sourceLabel,mode,set:selected,score:score.score,confidence:Math.round(averageConfidence(results)*100)+'%'});
    }catch(err){
      debugLog('Scan failed',(err&&err.stack)||String(err));
      console.error('OMR scan failed',err);sessionFail();
      showScanError((err&&err.message)||'Unknown error. Open Developer Log for details.');
      setStatus('error','Scan rejected');
      state.stableFrames=0;if(sourceLabel==='camera'){state.needRemoval=true;state.absentFrames=0;}
      if(sourceLabel==='camera' && state.cameraRunning && (!state.batch||!state.batchPaused))startDetectionLoop();
    }finally{
      deleteMat(inputMat);
      deleteMat(source);
      deleteMat(warp&&warp.mat);
      state.scanning=false;
      els.scanBtn.disabled=!state.cameraRunning;
      els.galleryBtn.disabled=false;
    }
  }

  function readHighResolutionFrame(){
    if(!els.video.videoWidth||!els.video.videoHeight)return null;
    const w=els.video.videoWidth,h=els.video.videoHeight;
    const c=document.createElement('canvas');c.width=w;c.height=h;
    const ctx=c.getContext('2d',{willReadFrequently:true});
    ctx.drawImage(els.video,0,0,w,h);
    return {width:w,height:h,imageData:ctx.getImageData(0,0,w,h)};
  }

  function isFullPage(quad,source=null){
    if(!Array.isArray(quad)||quad.length!==4)return false;
    const p=sortCorners(quad);
    const sides=[dist(p[0],p[1]),dist(p[1],p[2]),dist(p[2],p[3]),dist(p[3],p[0])].sort((a,b)=>b-a);
    const longest=(sides[0]+sides[1])/2;
    const shortest=(sides[2]+sides[3])/2;
    const aspect=longest/Math.max(shortest,1);
    // Geometry alone cannot distinguish an A4 page from an exact half-A4 crop:
    // both are approximately 1.414:1. Therefore use orientation-invariant side
    // ordering first, then inspect the page content when the source Mat is available.
    if(!Number.isFinite(aspect)||aspect<1.08||aspect>2.25)return false;
    if(!source)return false;
    return hasCentralFullPageDivider(source);
  }

  function hasCentralFullPageDivider(image){
    let gray=null,blur=null,edges=null;
    try{
      if(!image||image.cols<20||image.rows<20)return false;
      gray=new cv.Mat();blur=new cv.Mat();edges=new cv.Mat();
      cv.cvtColor(image,gray,cv.COLOR_RGBA2GRAY);
      cv.GaussianBlur(gray,blur,new cv.Size(3,3),0);
      cv.Canny(blur,edges,35,110);

      const scoreHorizontal=()=>{
        const lo=Math.max(1,Math.floor(image.rows*.44));
        const hi=Math.min(image.rows-1,Math.ceil(image.rows*.56));
        const x0=Math.floor(image.cols*.04),x1=Math.ceil(image.cols*.96);
        let best=0;
        for(let y=lo;y<=hi;y++){
          let edge=0,dark=0,run=0,longRuns=0,samples=0;
          for(let x=x0;x<x1;x+=2){
            const g=gray.ucharAt(y,x),e=edges.ucharAt(y,x);samples++;
            if(g<205){dark++;run++;if(run>=4)longRuns++;}else run=0;
            if(e>0)edge++;
          }
          const edgeDensity=edge/Math.max(samples,1),darkDensity=dark/Math.max(samples,1),continuity=longRuns/Math.max(samples,1);
          best=Math.max(best,edgeDensity*1.9+darkDensity*.7+continuity*4.0);
        }
        return best;
      };

      const scoreVertical=()=>{
        const lo=Math.max(1,Math.floor(image.cols*.44));
        const hi=Math.min(image.cols-1,Math.ceil(image.cols*.56));
        const y0=Math.floor(image.rows*.04),y1=Math.ceil(image.rows*.96);
        let best=0;
        for(let x=lo;x<=hi;x++){
          let edge=0,dark=0,run=0,longRuns=0,samples=0;
          for(let y=y0;y<y1;y+=2){
            const g=gray.ucharAt(y,x),e=edges.ucharAt(y,x);samples++;
            if(g<205){dark++;run++;if(run>=4)longRuns++;}else run=0;
            if(e>0)edge++;
          }
          const edgeDensity=edge/Math.max(samples,1),darkDensity=dark/Math.max(samples,1),continuity=longRuns/Math.max(samples,1);
          best=Math.max(best,edgeDensity*1.9+darkDensity*.7+continuity*4.0);
        }
        return best;
      };

      const horizontal=scoreHorizontal(),vertical=scoreVertical(),best=Math.max(horizontal,vertical);
      debugLog('Full-page divider check',{horizontal:Number(horizontal.toFixed(3)),vertical:Number(vertical.toFixed(3)),best:Number(best.toFixed(3))});
      return best>=1.25;
    }finally{[gray,blur,edges].forEach(deleteMat);}
  }

  function resolveSetForScan(mode,image){
    // Explicit selection always wins.
    if(state.selectedSet==='A'||state.selectedSet==='B')return state.selectedSet;

    // A full A4 contains both Set A and Set B. AUTO cannot know which half
    // the teacher intends to score, so it must never silently choose one.
    if(mode==='full'){
      debugLog('AUTO set resolution: full A4 detected; manual Set A/B selection required');
      return null;
    }

    // A cropped half-page has no absolute Y position, so use the printed
    // "SET A / SET B" marker. Never silently assume Set A when the marker is
    // unclear: an incorrect key can produce a completely wrong score.
    if(image){
      const detected=detectSetFromHalf(image);
      if(detected)return detected;
      debugLog('AUTO set marker inconclusive; manual Set A/B selection required');
      return null;
    }
    return null;
  }

  // Ownership transfer: `out.mat` is intentionally returned to the caller; local temporary Mats are always deleted in finally.
  function warpDocument(imageData,w,h,quad,mode){
    let src=null,dst=null,transform=null,srcPts=null,dstPts=null;
    try{
      src=cv.matFromImageData(imageData);state.matsCreated++;
      const sorted=sortCorners(quad),targetW=OMR_CONFIG.targetWidth,targetH=mode==='full'?OMR_CONFIG.targetHeightFull:OMR_CONFIG.targetHeightHalf;
      srcPts=cv.matFromArray(4,1,cv.CV_32FC2,sorted.flatMap(p=>[p.x,p.y]));
      dstPts=cv.matFromArray(4,1,cv.CV_32FC2,[0,0,targetW,0,targetW,targetH,0,targetH]);
      transform=cv.getPerspectiveTransform(srcPts,dstPts);dst=new cv.Mat();
      cv.warpPerspective(src,dst,transform,new cv.Size(targetW,targetH),cv.INTER_LINEAR,cv.BORDER_CONSTANT,new cv.Scalar(255,255,255,255));
      const out=dst;dst=null;return{mat:out};
    }finally{[src,dst,srcPts,dstPts,transform].forEach(deleteMat);}
  }

  function clampRect(x,y,w,h,cols,rows,minSize=1){
    const maxX=Math.max(0,Math.floor(cols)-1),maxY=Math.max(0,Math.floor(rows)-1);
    const ix=Math.min(maxX,Math.max(0,Math.floor(x)));
    const iy=Math.min(maxY,Math.max(0,Math.floor(y)));
    const iw=Math.min(Math.floor(w),Math.floor(cols)-ix);
    const ih=Math.min(Math.floor(h),Math.floor(rows)-iy);
    if(iw<minSize||ih<minSize)return null;
    return new cv.Rect(ix,iy,iw,ih);
  }

  function splitFullPage(mat){
    let gray=null,blur=null,edges=null,roiTop=null,roiBottom=null,top=null,bottom=null;
    try{
      if(!mat||mat.cols<2||mat.rows<2)throw new Error('Invalid full-page image');
      gray=new cv.Mat();blur=new cv.Mat();edges=new cv.Mat();
      cv.cvtColor(mat,gray,cv.COLOR_RGBA2GRAY);
      cv.GaussianBlur(gray,blur,new cv.Size(3,3),0);
      cv.Canny(blur,edges,35,110);

      const lo=Math.floor(mat.rows*.42),hi=Math.ceil(mat.rows*.58);
      let bestY=Math.round(mat.rows*.5),bestScore=-Infinity;
      const x0=Math.floor(mat.cols*.035),x1=Math.ceil(mat.cols*.965);
      for(let y=lo;y<hi;y++){
        let dark=0,edge=0,longRuns=0,run=0,samples=0;
        for(let x=x0;x<x1;x+=2){
          const g=gray.ucharAt(y,x),e=edges.ucharAt(y,x);samples++;
          if(g<205){dark++;run++;if(run>=4)longRuns++;}else run=0;
          if(e>0)edge++;
        }
        const continuity=longRuns/Math.max(1,samples);
        const darkDensity=dark/Math.max(1,samples);
        const edgeDensity=edge/Math.max(1,samples);
        const centerPenalty=Math.abs(y-mat.rows*.5)/(mat.rows*.08);
        const score=continuity*4.0+edgeDensity*1.8+darkDensity*.7-Math.max(0,centerPenalty)*.35;
        if(score>bestScore){bestScore=score;bestY=y;}
      }
      bestY=Math.max(Math.floor(mat.rows*.44),Math.min(Math.floor(mat.rows*.56),bestY));
      roiTop=mat.roi(clampRect(0,0,mat.cols,bestY,mat.cols,mat.rows,1));
      roiBottom=mat.roi(clampRect(0,bestY,mat.cols,mat.rows-bestY,mat.cols,mat.rows,1));
      top=roiTop.clone();bottom=roiBottom.clone();
      const out={top,bottom,dividerY:bestY};
      top=null;bottom=null;
      debugLog('Dynamic half-page split',{dividerY:bestY,ratio:Number((bestY/mat.rows).toFixed(4)),score:Number(bestScore.toFixed(3))});
      return out;
    }finally{[gray,blur,edges,roiTop,roiBottom,top,bottom].forEach(deleteMat);}
  }

  function cropHalf(mat,set){const split=splitFullPage(mat);try{return(set==='B'?split.bottom:split.top).clone();}finally{deleteMat(split.top);deleteMat(split.bottom);}}

  function detectSetFromHalf(image){
    let roi=null,gray=null,blur=null,thr=null,contours=null,hierarchy=null;
    try{
      // On the supplied sheet the SET marker is the blue banner at the upper
      // left. The final ~1/3 of that banner contains only "SET A" or "SET B".
      // Restricting the ROI to that area avoids confusing the words
      // "OMR ANSWER SHEET" with the set marker.
      const x=Math.floor(image.cols*.205),y=Math.floor(image.rows*.075),
            w=Math.floor(image.cols*.095),h=Math.floor(image.rows*.085);
      const rect=clampRect(x,y,w,h,image.cols,image.rows,1);
      if(!rect)return null;
      roi=image.roi(rect);gray=new cv.Mat();blur=new cv.Mat();thr=new cv.Mat();contours=new cv.MatVector();hierarchy=new cv.Mat();
      cv.cvtColor(roi,gray,cv.COLOR_RGBA2GRAY);
      cv.GaussianBlur(gray,blur,new cv.Size(3,3),0);
      cv.threshold(blur,thr,190,255,cv.THRESH_BINARY_INV+cv.THRESH_OTSU);
      cv.findContours(thr,contours,hierarchy,cv.RETR_CCOMP,cv.CHAIN_APPROX_SIMPLE);

      let holes=0,ink=0,components=0;
      for(let i=0;i<contours.size();i++){
        let c=null;
        try{
          c=contours.get(i);const area=Math.abs(cv.contourArea(c));
          if(area>2)ink+=area;
          if(area>5)components++;
          if(hierarchy.data32S[i*4+3]>=0)holes++;
        }finally{deleteMat(c);}
      }
      const density=ink/Math.max(1,rect.width*rect.height);
      // A has one enclosed counter; B has two. Require a plausible marker
      // density before using the hole count, otherwise return null.
      if(density<.015||components<1)return null;
      if(holes>=2)return'B';
      if(holes===1)return'A';
      return density>.22?'B':'A';
    }finally{[gray,blur,roi,thr,contours,hierarchy].forEach(deleteMat);}
  }

  function keyIsComplete(key){
    if(!key||typeof key!=='object')return false;
    for(let q=1;q<=OMR_CONFIG.questions;q++){
      if(!OMR_CONFIG.options.includes(String(key[String(q)]||'').toUpperCase()))return false;
    }
    return true;
  }

  function ensureAnswerKeyForSet(set){
    if(!set)return keyIsComplete(ANSWER_KEYS.A)||keyIsComplete(ANSWER_KEYS.B);
    if(keyIsComplete(ANSWER_KEYS[set]))return true;
    showToast(`Answer Key for Set ${set} is incomplete. Configure all 50 answers first.`);
    els.keyStatus.className='key-status error';
    els.keyStatus.textContent=`Set ${set}: incomplete — 50 valid answers are required.`;
    els.keyText.focus();
    return false;
  }

  function parseAnswerKeyText(text){
    const source=String(text||'').trim();
    if(!source)throw new Error('Answer Key input is empty.');
    let parsed=null;
    if(source.startsWith('{')||source.startsWith('[')){
      try{parsed=JSON.parse(source);}catch(e){throw new Error('Invalid JSON Answer Key.');}
    }
    const info={bad:0};
    const parseSingle=(value)=>{
      const out=emptyAnswerKey();
      if(value&&!Array.isArray(value)&&typeof value==='object'&&Array.isArray(value.answers))value=value.answers;
      const put=(q,a)=>{
        const n=Number(String(q).replace(/[\"']/g,'').trim());
        const v=String(a??'').replace(/[\"']/g,'').trim().toUpperCase();
        if(Number.isInteger(n)&&n>=1&&n<=OMR_CONFIG.questions&&OMR_CONFIG.options.includes(v))out[String(n)]=v;else if(String(a??'').trim()!=='')info.bad++;
      };
      if(Array.isArray(value)){
        value.forEach((item,i)=>{
          if(typeof item==='string')put(i+1,item);
          else if(item&&typeof item==='object')put(item.question??item.q??i+1,item.answer??item.a??item.key);
        });
      }else if(value&&typeof value==='object'){
        const src=value.answers&&typeof value.answers==='object'?value.answers:value;
        for(const [k,v] of Object.entries(src)){
          if(k==='A'||k==='B'||k==='answers')continue;
          if(typeof v==='object'&&v!==null)put(k,v.answer??v.a??v.key);
          else put(k,v);
        }
      }else{
        const records=source.split(/[\n;]+/).map(s=>s.trim()).filter(Boolean);
        for(const record of records){
          const csv=record.split(',').map(v=>v.trim()).filter(Boolean);
          if(csv.length===2 && /^\"?\d+\"?$/.test(csv[0])){put(csv[0],csv[1]);continue;}
          for(const token of csv){
            const m=token.match(/^(?:Q\s*)?[\"']?(\d+)[\"']?\s*[-:=]\s*[\"']?([ABCD])[\"']?$/i);
            if(m)put(m[1],m[2]);
            else{
              const pair=token.split(/\s+/).map(v=>v.replace(/^[\"']|[\"']$/g,'')).filter(Boolean);
              if(pair.length===2)put(pair[0],pair[1]);
            }
          }
        }
      }
      return out;
    };
    if(parsed&&typeof parsed==='object'&&!Array.isArray(parsed)&&(parsed.A||parsed.B)){
      return {sets:{A:parseSingle(parsed.A||{}),B:parseSingle(parsed.B||{})},single:null,info};
    }
    return {sets:null,single:parseSingle(parsed===null?source:parsed),info};
  }

  function mergeAnswerKey(target,parsed){
    if(!parsed)return;
    for(let q=1;q<=OMR_CONFIG.questions;q++){
      const v=parsed[String(q)];
      if(v)target[String(q)]=v;
    }
  }

  function applyAnswerKeyText(){
    try{
      const parsed=parseAnswerKeyText(els.keyText.value);
      const target=els.keyTarget.value;
      if(parsed.info&&parsed.info.bad>0)throw new Error(`${parsed.info.bad} invalid answer entries (use A/B/C/D and questions 1-50). Nothing was changed.`);
      if(parsed.sets){
        if(target==='A')mergeAnswerKey(ANSWER_KEYS.A,parsed.sets.A);
        else if(target==='B')mergeAnswerKey(ANSWER_KEYS.B,parsed.sets.B);
        else{mergeAnswerKey(ANSWER_KEYS.A,parsed.sets.A);mergeAnswerKey(ANSWER_KEYS.B,parsed.sets.B);}
      }else if(target==='A'||target==='B')mergeAnswerKey(ANSWER_KEYS[target],parsed.single);
      else{mergeAnswerKey(ANSWER_KEYS.A,parsed.single);mergeAnswerKey(ANSWER_KEYS.B,parsed.single);}
      localStorage.setItem(ANSWER_KEY_STORAGE,JSON.stringify(ANSWER_KEYS));
      renderAnswerKeyStatus();
      showToast(`Answer Key ${target==='BOTH'?'A + B':target} updated.`);
      debugLog('Answer Key updated',{target});
    }catch(err){
      els.keyStatus.className='key-status error';
      els.keyStatus.textContent=err.message;
      showToast(err.message);
    }
  }

  async function handleAnswerKeyFile(file){
    if(!file)return;
    try{
      const text=await file.text();
      els.keyText.value=text;
      applyAnswerKeyText();
    }catch(err){showToast('Could not read Answer Key file.');}
    finally{els.keyFile.value='';}
  }

  function clearAnswerKeys(){
    ANSWER_KEYS.A=emptyAnswerKey();
    ANSWER_KEYS.B=emptyAnswerKey();
    localStorage.removeItem(ANSWER_KEY_STORAGE);
    renderAnswerKeyStatus();
    showToast('Answer Keys cleared.');
  }

  function renderAnswerKeyStatus(){
    const a=Object.values(ANSWER_KEYS.A).filter(Boolean).length,b=Object.values(ANSWER_KEYS.B).filter(Boolean).length;
    const complete=a===OMR_CONFIG.questions&&b===OMR_CONFIG.questions;
    els.keyStatus.className=`key-status ${complete?'ok':(a||b?'warn':'error')}`;
    els.keyStatus.textContent=`Set A: ${a}/50 · Set B: ${b}/50${complete?' · Ready to scan':''}`;
    els.keyPreview.textContent=`A: ${formatAnswerKeyPreview(ANSWER_KEYS.A)}\nB: ${formatAnswerKeyPreview(ANSWER_KEYS.B)}`;
  }

  function formatAnswerKeyPreview(key){
    const values=[];
    for(let q=1;q<=OMR_CONFIG.questions;q++)values.push(`${q}-${key[String(q)]||'?'}`);
    return values.join(', ');
  }

  function updateSetSelectionUI(){
    els.setButtons.forEach(b=>b.classList.toggle('selected',b.dataset.set===state.selectedSet));
  }

  function analyzeAllQuestions(image,profile,set){
    const quality=measureQuality(image);if(quality.sharpness<QUALITY_CONFIG.minSharpness/2)debugLog('Warp quality warning',quality);
    const scores=[];for(let q=1;q<=OMR_CONFIG.questions;q++){scores.push(analyzeQuestion(image,q,profile));}
    const all=scores.flatMap(r=>r.options.map(o=>o.score));const stats=distribution(all);const dynamic=adaptiveThresholds(all,stats);
    return scores.map(r=>finalizeQuestion(r,dynamic));
  }

  function analyzeQuestion(image,q,profile){
    const colIndex=OMR_CONFIG.columns.findIndex(c=>q>=c.startQuestion&&q<=c.endQuestion);const col=OMR_CONFIG.columns[colIndex];const posInCol=q-col.startQuestion;const count=col.endQuestion-col.startQuestion+1;const y=rowY(profile,posInCol);
    const centers=profile.bubbleCentersX.slice(colIndex*4,colIndex*4+4);const options=[];
    for(let i=0;i<4;i++){const expected={x:centers[i],y};const refined=refineBubbleCenter(image,expected,profile.bubbleRadius);options.push({option:OMR_CONFIG.options[i],...measureBubble(image,refined,profile.bubbleRadius)});}
    return {question:q,options,expectedCenterY:y};
  }

  function refineBubbleCenter(image,expected,rNorm){
    const cx=Math.round(expected.x*image.cols),cy=Math.round(expected.y*image.rows),radius=Math.max(12,Math.round(rNorm*image.cols*1.8));
    let roi=null,gray=null,blur=null,thr=null,contours=null,hierarchy=null;
    try{
      const x0=cx-radius*2,y0=cy-radius*2,rect=clampRect(x0,y0,radius*4,radius*4,image.cols,image.rows,3);
      if(!rect)return {...expected};
      roi=image.roi(rect);gray=new cv.Mat();blur=new cv.Mat();thr=new cv.Mat();contours=new cv.MatVector();hierarchy=new cv.Mat();cv.cvtColor(roi,gray,cv.COLOR_RGBA2GRAY);cv.GaussianBlur(gray,blur,new cv.Size(3,3),0);cv.adaptiveThreshold(blur,thr,255,cv.ADAPTIVE_THRESH_GAUSSIAN_C,cv.THRESH_BINARY_INV,15,5);cv.findContours(thr,contours,hierarchy,cv.RETR_EXTERNAL,cv.CHAIN_APPROX_SIMPLE);
      let best=null;for(let i=0;i<contours.size();i++){let c=null;try{c=contours.get(i);const a=Math.abs(cv.contourArea(c)),peri=cv.arcLength(c,true);if(a<8||!peri)continue;const circ=4*Math.PI*a/(peri*peri),m=cv.moments(c);if(m.m00){const x=rect.x+m.m10/m.m00,y=rect.y+m.m01/m.m00,d=Math.hypot(x-cx,y-cy);if(d<radius*1.7&&circ>.45&&(!best||a>best.a))best={x,y,a};}}finally{deleteMat(c);}}
      return best?{x:best.x/image.cols,y:best.y/image.rows}:{...expected};
    }finally{[roi,gray,blur,thr,contours,hierarchy].forEach(deleteMat);}
  }

  function measureBubble(image,center,rNorm){
    let rgbaRoi=null,gray=null,otsu=null,adaptive=null,mask=null,rgb=null,hsv=null,sat=null,satMask=null,combined=null;
    const empty={centerDarkness:0,edgeDarkness:0,fillRatio:0,inkDensity:0,score:0,confidence:0};
    try{
      if(!image||image.cols<3||image.rows<3||!center)return empty;
      const cx=Math.round(center.x*image.cols),cy=Math.round(center.y*image.rows),
            r=Math.max(8,Math.round(rNorm*image.cols)),box=Math.max(14,Math.round(r*1.55));
      const rect=clampRect(cx-box,cy-box,box*2,box*2,image.cols,image.rows,3);
      if(!rect)return empty;
      const size=rect.width;
      if(size<3||rect.height!==size)return empty;
      rgbaRoi=image.roi(rect);
      gray=new cv.Mat();cv.cvtColor(rgbaRoi,gray,cv.COLOR_RGBA2GRAY);

      otsu=new cv.Mat();adaptive=new cv.Mat();mask=new cv.Mat();
      cv.threshold(gray,otsu,0,255,cv.THRESH_BINARY_INV+cv.THRESH_OTSU);
      const block=Math.max(3,Math.min(31,(size%2===1?size:size-1)));
      cv.adaptiveThreshold(gray,adaptive,255,cv.ADAPTIVE_THRESH_GAUSSIAN_C,cv.THRESH_BINARY_INV,block,4);
      cv.bitwise_or(otsu,adaptive,mask);

      const data=mask.data,src=image.data,stepPx=image.cols*4;
let dark=0,total=0,centerDark=0,centerTotal=0,edgeDark=0,edgeTotal=0,rr=size/2;
      for(let yy=0;yy<size;yy++)for(let xx=0;xx<size;xx++){
        const dx=xx-rr,dy=yy-rr,d=Math.hypot(dx,dy);
        const o=(rect.y+yy)*stepPx+(rect.x+xx)*4,R=src[o],G=src[o+1],B=src[o+2],mx=Math.max(R,G,B),mn=Math.min(R,G,B);
        const v=data[yy*size+xx]>0||(mx>0&&(mx-mn)/mx*255>48);
        if(d<=rr*.82){total++;if(v)dark++;}
        if(d<=rr*.43){centerTotal++;if(v)centerDark++;}
        else if(d>rr*.58&&d<=rr*.82){edgeTotal++;if(v)edgeDark++;}
      }
      const fill=dark/Math.max(total,1),cen=centerDark/Math.max(centerTotal,1),
            edge=edgeDark/Math.max(edgeTotal,1),ink=Math.max(0,Math.min(1,fill*.65+cen*.35)),
            w=OMR_CONFIG.bubbleDetection.scoreWeights,
            score=Math.max(0,Math.min(1,fill*w.fillRatio+cen*w.centerDarkness+ink*w.inkDensity));
      return{centerDarkness:cen,edgeDarkness:edge,fillRatio:fill,inkDensity:ink,score,confidence:0};
    }finally{[rgbaRoi,gray,otsu,adaptive,mask].forEach(deleteMat);}
  }

  function distribution(values){const v=[...values].sort((a,b)=>a-b);const mean=v.reduce((a,b)=>a+b,0)/Math.max(v.length,1);const sd=Math.sqrt(v.reduce((a,b)=>a+(b-mean)**2,0)/Math.max(v.length,1));return {mean,sd,median:percentile(v,.5),p75:percentile(v,.75),p90:percentile(v,.9),p95:percentile(v,.95)} }
  function percentile(v,p){if(!v.length)return 0;const i=(v.length-1)*p,l=Math.floor(i),d=i-l;return v[l]+(v[l+1]!==undefined?(v[l+1]-v[l])*d:0)}
  function adaptiveThresholds(values,stats){const ink=stats.p90>0.12?stats.p90:0.12;return {accept:Math.max(OMR_CONFIG.bubbleDetection.minFillRatio,Math.min(.58,stats.median+Math.max(.06,stats.sd*1.15))),strong:Math.max(OMR_CONFIG.bubbleDetection.strongFillRatio,Math.min(.82,Math.max(ink,stats.median+.12))),ambiguity:OMR_CONFIG.bubbleDetection.ambiguityRatio};}

  function finalizeQuestion(r,t){
    const sorted=[...r.options].sort((a,b)=>b.score-a.score);const best=sorted[0],second=sorted[1];const strong=sorted.filter(o=>o.score>=t.strong).length;const accepted=best.score>=t.accept;let status='unattempted',detected=null;
    if(strong>=2)status='multiple';
    else if(!accepted)status=best.score>=t.accept*.8?'low-confidence':'unattempted';
    else if(best.score-second.score<t.ambiguity)status='low-confidence';
    else {status='detected';detected=best.option;}
    const confidence=confidenceFromScores(best.score,second.score,status,t);return {...r,detected,confidence,status,options:r.options.map(o=>({...o,confidence:o===best?confidence:Math.max(0,Math.min(1,o.score))}))};
  }

  function confidenceFromScores(best,second,status,t){if(status==='multiple')return Math.min(1,best.score);if(status==='unattempted')return Math.max(0,Math.min(.45,best.score));const margin=Math.max(0,best-second);return Math.max(0,Math.min(1,.35+.55*Math.min(1,best/Math.max(t.strong,.01))+.35*Math.min(1,margin/.25)))}

  function calculateScore(results,answerKey){let correct=0,wrong=0,unattempted=0,invalid=0,review=0;const key=answerKey||{};results.forEach(r=>{if(r.status==='multiple'){invalid++;return}if(r.status==='low-confidence'){review++;return}if(r.status==='unattempted'){unattempted++;return}const expected=String(key[String(r.question)]||'').toUpperCase();if(!OMR_CONFIG.options.includes(expected)){invalid++;return}if(r.detected===expected)correct++;else wrong++});const score=correct;return {correct,wrong,unattempted,invalid,review,score,total:OMR_CONFIG.questions,percentage:score/OMR_CONFIG.questions*100}}

  function measureQuality(image){let gray=null,lap=null;try{gray=new cv.Mat();lap=new cv.Mat();cv.cvtColor(image,gray,cv.COLOR_RGBA2GRAY);cv.Laplacian(gray,lap,cv.CV_64F);const mean=cv.mean(gray)[0],sd=meanStd(gray).std,sharp=meanStd(lap).std**2;return {sharpness:sharp,brightness:mean,contrast:sd,coverage:1,perspective:1,score:Math.min(100,sharp/2+Math.min(100,sd*2))};}finally{deleteMat(gray);deleteMat(lap)}}

  const STUDENT_BOXES={name:[.15,.145,.52,.222],rollNo:[.42,.195,.51,.26],className:[.095,.195,.2,.26],section:[.25,.195,.37,.26],subject:[.57,.145,.75,.222],date:[.6,.195,.752,.26]};
  function extractStudentInfo(source){
    const st={name:'',subject:exam.subject,className:exam.className,section:exam.section,rollNo:'',date:fmtDate(exam.date),crops:{}};
    try{
      const full=document.createElement('canvas');full.width=source.cols;full.height=source.rows;
      full.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(source.data),source.cols,source.rows),0,0);
      for(const[key,b]of Object.entries(STUDENT_BOXES)){
        const sx=Math.max(0,b[0]*source.cols),sy=Math.max(0,b[1]*source.rows),sw=Math.min(source.cols-sx,(b[2]-b[0])*source.cols),sh=Math.min(source.rows-sy,(b[3]-b[1])*source.rows);
        const c=document.createElement('canvas');c.width=Math.round(sw*.65);c.height=Math.round(sh*.65);
        c.getContext('2d').drawImage(full,sx,sy,sw,sh,0,0,c.width,c.height);st.crops[key]=c.toDataURL('image/jpeg',.72);
      }
    }catch(e){debugLog('Student crop failed',String(e));}
    return st;
  }

  function averageConfidence(results){return results.reduce((a,r)=>a+r.confidence,0)/Math.max(results.length,1)}
  function makeScanId(){return `${Date.now()}-${Math.random().toString(36).slice(2,8)}`}

  function showResults(score,set,quality,mode){
    [els.save,els.saveNext,els.print].forEach(b=>{if(b)b.disabled=false;});els.result.hidden=false;animateNumber(els.scoreNumber,score.score,`${score.score} / ${score.total}`);animateNumber(els.scorePercent,score.percentage,`${Math.round(score.percentage)}%`);els.correct.textContent=score.correct;els.wrong.textContent=score.wrong;els.unattempted.textContent=score.unattempted;if(els.reviewCount)els.reviewCount.textContent=score.review;els.invalid.textContent=score.invalid;
    renderStudentFields(state.currentStudent);renderReview(set);els.result.scrollIntoView({behavior:'smooth',block:'start'});const review=state.currentResults.filter(r=>['low-confidence','multiple','unattempted'].includes(r.status)).length;showToast(review?`⚠ ${review} answers need review`:'✓ Scan completed successfully');debugLog('Result HUD shown',{set,mode,quality});
  }

  function animateNumber(el,value,finalText){const start=Number(el.dataset.value||0),duration=650,t0=performance.now();const tick=t=>{const p=Math.min(1,(t-t0)/duration),e=1-Math.pow(1-p,3),n=start+(value-start)*e;el.textContent=el===els.scorePercent?`${Math.round(n)}%`:`${Math.round(n)} / 50`;if(p<1)requestAnimationFrame(tick);else{el.textContent=finalText;el.dataset.value=value}};requestAnimationFrame(tick)}

  function renderStudentFields(student){
    const f=[['name','Student Name'],['rollNo','Roll No.']];
    els.studentFields.innerHTML=`<p class="muted" style="grid-column:1/-1;margin:0">Class ${escapeHtml(exam.className)} · ${escapeHtml(exam.subject)} · Section ${escapeHtml(exam.section)} · ${escapeHtml(fmtDate(exam.date))} (from Exam Details). Type the name/roll below; if left blank the photo from the sheet is used in reports.</p>`+f.map(([k,l])=>`<label>${l}${student.crops&&student.crops[k]?`<img class="field-crop" src="${student.crops[k]}" alt="${l} from sheet">`:''}<input data-student="${k}" value="${escapeHtml(student[k]||'')}" aria-label="${l}"></label>`).join('');
  }

  function renderReview(set){const results=state.currentResults;const needs=results.filter(r=>reviewStatus(r.status)).length;let html=needs?`<div class="review-alert">⚠ ${needs} answers need review. Manual correction updates the score immediately.</div>`:'';html+=`<div class="review-table-wrap"><table class="review-table"><thead><tr><th>Q</th><th>Detected</th><th>Correct</th><th>Confidence</th><th>Status</th><th>Manual correction</th></tr></thead><tbody>`;results.forEach(r=>{const key=ANSWER_KEYS[set][String(r.question)];html+=`<tr><td>Q${r.question}</td><td><span class="answer-chip ${chipClass(r.status,r.detected===key)}">${r.detected||'—'}</span></td><td><span class="answer-chip warn">${key||'—'}</span></td><td>${Math.round(r.confidence*100)}%</td><td>${statusLabel(r.status,r.detected,key)}</td><td><div class="review-selects">${OMR_CONFIG.options.map(o=>`<button type="button" data-review-q="${r.question}" data-review-answer="${o}" class="${r.detected===o?'active':''}" aria-label="Set Q${r.question} to ${o}">${o}</button>`).join('')}<button type="button" data-review-q="${r.question}" data-review-answer="" class="${!r.detected?'active':''}" aria-label="Clear Q${r.question}">×</button></div></td></tr>`});html+='</tbody></table></div>';els.review.innerHTML=html;els.review.querySelectorAll('[data-review-q]').forEach(btn=>btn.addEventListener('click',()=>manualCorrection(Number(btn.dataset.reviewQ),btn.dataset.reviewAnswer||null)))}

  function chipClass(status,correct){if(status==='multiple')return'invalid';if(status==='low-confidence')return'warn';if(status==='unattempted')return'empty';return correct?'good':'bad'}
  function statusLabel(status,detected,key){if(status==='multiple')return'MULTIPLE / INVALID';if(status==='unattempted')return'UNATTEMPTED';if(status==='low-confidence')return'LOW CONFIDENCE';return detected===key?'✓ Correct':'✗ Wrong'}

  function manualCorrection(q,answer){const r=state.currentResults.find(x=>x.question===q);if(!r)return;r.detected=answer;r.status=answer?'detected':'unattempted';r.confidence=answer?1:0;const key=ANSWER_KEYS[resultSet()]||{};const score=calculateScore(state.currentResults,key);els.correct.textContent=score.correct;els.wrong.textContent=score.wrong;els.unattempted.textContent=score.unattempted;if(els.reviewCount)els.reviewCount.textContent=score.review;els.invalid.textContent=score.invalid;els.scoreNumber.textContent=`${score.score} / 50`;els.scorePercent.textContent=`${Math.round(score.percentage)}%`;syncRowFromCurrent();renderReview(resultSet());drawResultOverlay(state.currentWarp,state.currentResults,ANSWER_KEYS[resultSet()]);state.saved=false;showToast(`Q${q} updated`)}

  function drawResultOverlay(image,results,key){if(!image)return;const c=els.resultCanvas;c.width=image.cols;c.height=image.rows;const ctx=c.getContext('2d');const tmp=document.createElement('canvas');tmp.width=image.cols;tmp.height=image.rows;const data=new ImageData(new Uint8ClampedArray(image.data),image.cols,image.rows);tmp.getContext('2d').putImageData(data,0,0);ctx.drawImage(tmp,0,0);const profile=state.calibration[resultSet()==='A'?'TBWS_CLASS_7_SET_A':'TBWS_CLASS_7_SET_B'];ctx.font='bold 18px system-ui';results.forEach(r=>{const kq=(key||{})[String(r.question)],kidx=OMR_CONFIG.options.indexOf(kq);const col=OMR_CONFIG.columns.findIndex(c=>r.question>=c.startQuestion&&r.question<=c.endQuestion),pos=r.question-OMR_CONFIG.columns[col].startQuestion,count=OMR_CONFIG.columns[col].endQuestion-OMR_CONFIG.columns[col].startQuestion+1,y=rowY(profile,pos);const xs=profile.bubbleCentersX.slice(col*4,col*4+4);if(r.status==='multiple'){r.options.forEach((o,i)=>drawBubbleMark(ctx,xs[i],y,'#b77aff',image.cols,profile.bubbleRadius));}else if(r.detected){const idx=OMR_CONFIG.options.indexOf(r.detected);drawBubbleMark(ctx,xs[idx],y,r.detected===kq?'#31d58b':'#ff6675',image.cols,profile.bubbleRadius);if(kidx>=0&&r.detected!==kq)drawBubbleMark(ctx,xs[kidx],y,'#ffbf55',image.cols,profile.bubbleRadius)}else{xs.forEach(x=>drawBubbleMark(ctx,x,y,'#7e8b9d',image.cols,profile.bubbleRadius))}if(r.status==='low-confidence'&&r.detected){const idx=OMR_CONFIG.options.indexOf(r.detected);drawBubbleMark(ctx,xs[idx],y,'#ff9f43',image.cols,profile.bubbleRadius)}ctx.fillStyle='#ffffff';ctx.strokeStyle='rgba(0,0,0,.7)';ctx.lineWidth=4;ctx.strokeText(`Q${r.question} ${r.detected||'—'} ${Math.round(r.confidence*100)}%`,12,y*image.rows-7);ctx.fillText(`Q${r.question} ${r.detected||'—'} ${Math.round(r.confidence*100)}%`,12,y*image.rows-7)});}
  function drawBubbleMark(ctx,xn,yn,color,w,rn){const x=xn*w,y=yn*ctx.canvas.height,r=Math.max(11,rn*w*1.4);ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.strokeStyle=color;ctx.lineWidth=5;ctx.stroke()}

  function toggleDebugOverlay(){state.debugOverlay=!state.debugOverlay;els.debugToggle.textContent=state.debugOverlay?'Hide Debug Overlay':'Show Debug Overlay';els.resultCanvas.classList.toggle('show',state.debugOverlay)}

  function collectStudentFromUI(){els.studentFields.querySelectorAll('[data-student]').forEach(i=>state.currentStudent[i.dataset.student]=i.value.trim())}
  async function saveOMRResult(){
    if(!state.currentResults||!state.currentScanId)return false;if(state.saved)return true;
    collectStudentFromUI();syncRowFromCurrent();
    const r=session.rows.find(x=>x.id===state.currentScanId);if(!r){handleAppError(new Error('Result not found in session'),'save');return false;}
    let ok=true;if(putTimers.has(r.id)||r._saveError)ok=await flushRow(r,true);else if(r._p)ok=await r._p;
    if(!ok){showToast('Save failed — result is still available. Press Retry Save.',7000);return false;}
    state.saved=true;els.save.textContent='✓ Marks Saved';showToast('✓ Marks saved locally');debugLog('Marks saved',{id:r.id,set:r.set,score:r.score});return true;
  }

  async function saveAndScanNext(){if(!await saveOMRResult())return;resetScanner({preserveStudent:false});state.holdReview=false;state.needRemoval=true;if(!state.cameraRunning)initCamera();else if(!state.rafId)startDetectionLoop();}
  function resetScanner(opts={}){if(opts.stop||!state.cameraRunning)stopCamera();state.holdReview=false;if(state.currentWarp){deleteMat(state.currentWarp);state.currentWarp=null}state.currentResults=null;state.currentScanId=null;state.saved=false;els.result.hidden=true;els.resultCanvas.classList.remove('show');state.resultSet=null;state.stableFrames=0;state.scanning=false;els.save.textContent='Save Marks';if(!opts.preserveStudent)state.currentStudent={name:'',subject:'',className:'',section:'',rollNo:'',date:''};setStatus('','Ready to scan')}

  function exportCSV(){if(!state.currentResults)return;collectStudentFromUI();const score=calculateScore(state.currentResults,ANSWER_KEYS[resultSet()]);const headers=['Student Name','Roll No','Class','Subject',...Array.from({length:OMR_CONFIG.questions},(_,i)=>`Q${i+1}`),'Correct','Wrong','Unattempted','Invalid','Score','Percentage','Date'];const row=[state.currentStudent.name,state.currentStudent.rollNo,state.currentStudent.className,state.currentStudent.subject,...Array.from({length:OMR_CONFIG.questions},(_,i)=>{const r=state.currentResults.find(x=>x.question===i+1);return r&&r.detected?r.detected:'';}),score.correct,score.wrong,score.unattempted,score.invalid,score.score,score.percentage.toFixed(2),state.currentStudent.date||new Date().toLocaleDateString('en-IN')];downloadBlob([headers,row].map(r=>r.map(csvEscape).join(',')).join('\n'),'omr-result.csv','text/csv;charset=utf-8')}
  function exportJSON(){if(!state.currentResults)return;collectStudentFromUI();const score=calculateScore(state.currentResults,ANSWER_KEYS[resultSet()]);const obj={timestamp:new Date().toISOString(),student:state.currentStudent,set:resultSet(),answers:state.currentResults,score,scanQuality:state.lastQuality};downloadBlob(JSON.stringify(obj,null,2),'omr-result.json','application/json')}
  function csvEscape(v){const s=String(v??'');return /[",\n]/.test(s)?`"${s.replace(/"/g,'""')}"`:s}
  function downloadBlob(data,name,type){const blob=new Blob([data],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),500)}
  function printResult(){if(!state.currentResults)return;collectStudentFromUI();syncRowFromCurrent();const r=session.rows.find(x=>x.id===state.currentScanId);if(!r){showToast('Result not found');return;}studentPdf(r);}

  function escapeHtml(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

  function startCalibration(){els.calibrationPanel.hidden=false;renderCalibrationFields();if(state.currentWarp)renderCalibrationPreview();els.calibrationPanel.scrollIntoView({behavior:'smooth'})}
  function renderCalibrationFields(){const p=state.calibration[resultSet()==='B'?'TBWS_CLASS_7_SET_B':'TBWS_CLASS_7_SET_A'];const fields=[['firstRowY','First Row Y',p.firstRowY],['lastRowY','Last Row Y',p.lastRowY],['headerCutY','Header Cut Y',p.headerCutY],['footerCutY','Footer Cut Y',p.footerCutY],['bubbleRadius','Bubble Radius',p.bubbleRadius],['x0','Column 1 X',p.bubbleCentersX[0]],['x4','Column 2 X',p.bubbleCentersX[4]],['x8','Column 3 X',p.bubbleCentersX[8]],['x12','Column 4 X',p.bubbleCentersX[12]],['minFill','Min Fill Ratio',OMR_CONFIG.bubbleDetection.minFillRatio],['strongFill','Strong Fill Ratio',OMR_CONFIG.bubbleDetection.strongFillRatio],['ambiguity','Ambiguity Threshold',OMR_CONFIG.bubbleDetection.ambiguityRatio]];els.calGrid.innerHTML=fields.map(([id,label,val])=>`<label class="cal-field">${label}<input type="number" step="0.001" data-cal="${id}" value="${val}"></label>`).join('')}
  function applyCalibrationFields(){
    const key=resultSet()==='B'?'TBWS_CLASS_7_SET_B':'TBWS_CLASS_7_SET_A';
    const cand=JSON.parse(JSON.stringify(state.calibration[key])),th={minFill:OMR_CONFIG.bubbleDetection.minFillRatio,strongFill:OMR_CONFIG.bubbleDetection.strongFillRatio,ambiguity:OMR_CONFIG.bubbleDetection.ambiguityRatio},errs=[];
    els.calGrid.querySelectorAll('[data-cal]').forEach(i=>{
      const id=i.dataset.cal,raw=String(i.value).trim(),v=raw===''?NaN:Number(raw);
      if(!Number.isFinite(v)){errs.push(`"${id}" must be a number`);return;}
      if(id==='firstRowY'||id==='lastRowY'||id==='headerCutY'||id==='footerCutY'||id==='bubbleRadius')cand[id]=v;
      else if(/^x(0|4|8|12)$/.test(id)){const st=Number(id.slice(1)),d=v-cand.bubbleCentersX[st];for(let k=st;k<st+4;k++)cand.bubbleCentersX[k]+=d;}
      else if(id==='minFill'||id==='strongFill'||id==='ambiguity')th[id]=v;
    });
    const all=errs.concat(validateProfile(cand,key==='TBWS_CLASS_7_SET_B'?'Set B':'Set A'),validateThresholds(th));
    if(all.length){showToast('✕ Calibration not saved: '+all[0]+(all.length>1?` (+${all.length-1} more)`:''),7000);debugLog('Calibration rejected',all);renderCalibrationFields();return false;}
    const before=JSON.stringify(state.calibration);
    try{state.calibration[key]=cand;OMR_CONFIG.bubbleDetection.minFillRatio=th.minFill;OMR_CONFIG.bubbleDetection.strongFillRatio=th.strongFill;OMR_CONFIG.bubbleDetection.ambiguityRatio=th.ambiguity;saveCalibrationStore();}
    catch(e){state.calibration=JSON.parse(before);handleAppError(e,'save calibration');return false;}
    showToast('✓ Calibration saved');return true;
  }
  function renderCalibrationPreview(){const c=els.calCanvas;c.width=state.currentWarp.cols;c.height=state.currentWarp.rows;const ctx=c.getContext('2d');const data=new ImageData(new Uint8ClampedArray(state.currentWarp.data),c.width,c.height);ctx.putImageData(data,0,0);const p=state.calibration[resultSet()==='B'?'TBWS_CLASS_7_SET_B':'TBWS_CLASS_7_SET_A'];ctx.strokeStyle='#4ea3ff';ctx.lineWidth=2;for(let col=0;col<4;col++){const xs=p.bubbleCentersX.slice(col*4,col*4+4);const qs=OMR_CONFIG.columns[col];for(let q=qs.startQuestion;q<=qs.endQuestion;q++){const pos=q-qs.startQuestion,y=rowY(p,pos);xs.forEach(x=>{ctx.beginPath();ctx.arc(x*c.width,y*c.height,p.bubbleRadius*c.width,0,Math.PI*2);ctx.stroke()})}}}
  function resetCalibration(){state.calibration=JSON.parse(JSON.stringify(DEFAULT_CALIBRATION));saveCalibrationStore();renderCalibrationFields();showToast('Calibration reset')}

  function toggleBatch(){state.batch=!state.batch;els.batchToggle.setAttribute('aria-pressed',String(state.batch));els.batchStats.hidden=!state.batch;if(state.batch){startAutoScan();showToast('Batch Scan enabled')}}
  function updateBatchUI(){const c=sessionCounts();els.batchCount.textContent=`Detected: ${c.detected} · Processed: ${c.processed}`;els.batchSuccess.textContent=`Saved: ${c.saved} · Pending: ${c.pending}`;els.batchReview.textContent=`Needs Review: ${c.review} · Save failed: ${c.saveFailed} · Rejected: ${c.rejected}`}
  function pauseBatch(){state.batchPaused=!state.batchPaused;els.pauseBatch.textContent=state.batchPaused?'Resume':'Pause';if(state.batchPaused)stopAutoScan();else startAutoScan();showToast(state.batchPaused?'Batch paused':'Batch resumed')}
  function finishBatch(){state.batch=false;state.batchPaused=false;els.batchToggle.setAttribute('aria-pressed','false');els.batchStats.hidden=true;stopCamera();showToast('Batch finished')}

  function selectSet(set){state.selectedSet=set;updateSetSelectionUI();if(set==='AUTO')els.setNote.textContent='Set is not assumed. For a half-page sheet, the printed Set marker is detected; for a full A4, choose Set A or Set B.';else els.setNote.textContent=`Scoring is locked to Set ${set}. The ${set==='A'?'A':'B'} answer key is used.`;if(state.currentWarp)renderCalibrationPreview();renderAnswerKeyStatus()}

  async function retake(){if(!await confirmModal({title:'RETAKE THIS SCAN?',body:'<p>This student\'s saved result is deleted and the sheet is scanned again.</p>',confirmText:'Retake',danger:false}))return;try{await sessionRemove(state.currentScanId);}catch(e){handleAppError(e,'retake');return;}resetScanner({preserveStudent:true});state.needRemoval=true;if(!state.cameraRunning)initCamera();}

  function cleanupOpenCV(){if(state.currentWarp){deleteMat(state.currentWarp);state.currentWarp=null}debugLog('Memory cleanup',{matsCreated:state.matsCreated,matsDeleted:state.matsDeleted})}

  function resetAll(){resetScanner();stopCamera();state.batchStats={scanned:0,successful:0,review:0};updateBatchUI();}

  function wireEvents(){
    if(wireEvents.done)return;wireEvents.done=true;
    els.startCamera.addEventListener('click',()=>initCamera());
    els.scanBtn.addEventListener('click',captureAndAnalyze);
    els.galleryBtn.addEventListener('click',()=>els.galleryInput.click());
    els.galleryInput.addEventListener('change',()=>handleGalleryFile(els.galleryInput.files&&els.galleryInput.files[0]));
    els.examStart.addEventListener('click',applyExam);renderExam();bindRecords();els.sessPdf.addEventListener('click',downloadAllPdf);els.sessBody.addEventListener('click',async e=>{const b=e.target.closest('[data-pdf]');if(!b)return;const r=session.rows.find(x=>x.id===b.dataset.pdf);if(!r)return;studentPdf(r);});els.studentFields.addEventListener('input',e=>{const i=e.target.closest('[data-student]');if(!i||!state.currentStudent)return;state.currentStudent[i.dataset.student]=i.value.trim();sessionUpdate(state.currentScanId,{name:state.currentStudent.name||'',roll:state.currentStudent.rollNo||''});});els.sessReset.addEventListener('click',resetSession);els.sessExport.addEventListener('click',exportSession);renderSession();
    els.autoToggle.addEventListener('click',()=>state.autoScan?stopAutoScan():startAutoScan());
    els.stopCamera.addEventListener('click',stopCamera);
    els.setButtons.forEach(b=>b.addEventListener('click',()=>selectSet(b.dataset.set)));
    els.batchToggle.addEventListener('click',toggleBatch);els.pauseBatch.addEventListener('click',pauseBatch);els.finishBatch.addEventListener('click',finishBatch);
    els.keyApply.addEventListener('click',applyAnswerKeyText);els.keyFileBtn.addEventListener('click',()=>els.keyFile.click());
    els.keyFile.addEventListener('change',()=>handleAnswerKeyFile(els.keyFile.files&&els.keyFile.files[0]));
    els.keyClear.addEventListener('click',clearAnswerKeys);
    els.calibrate.addEventListener('click',startCalibration);els.closeCalibration.addEventListener('click',()=>els.calibrationPanel.hidden=true);els.saveCal.addEventListener('click',()=>{applyCalibrationFields();if(state.currentWarp)renderCalibrationPreview()});els.resetCal.addEventListener('click',resetCalibration);
    els.debugToggle.addEventListener('click',toggleDebugOverlay);els.debugPanelToggle.addEventListener('click',()=>{els.debugPanel.hidden=!els.debugPanel.hidden});
    els.copyLog.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(state.debugLog.join('\n'));showToast('Debug log copied')}catch(e){showToast('Clipboard permission unavailable')}});
    els.save.addEventListener('click',saveOMRResult);els.saveNext.addEventListener('click',saveAndScanNext);els.exportCSV.addEventListener('click',exportCSV);els.exportJSON.addEventListener('click',exportJSON);els.print.addEventListener('click',printResult);els.retake.addEventListener('click',retake);
    els.video.addEventListener('loadedmetadata',applyCameraLayout);els.video.addEventListener('resize',applyCameraLayout);window.addEventListener('resize',applyCameraLayout);window.addEventListener('pagehide',cleanupOpenCV);document.addEventListener('visibilitychange',()=>{if(document.hidden){if(state.rafId){cancelAnimationFrame(state.rafId);state.rafId=0;}}else if(state.cameraRunning){const t=state.stream&&state.stream.getVideoTracks()[0];if(t&&t.readyState==='live')startDetectionLoop();else{stopCamera();initCamera();}}});
  }

  wireEvents();
  initSchool();
  initOmrGen();
  selectSet('AUTO');
  state.currentStudent={name:'',subject:'',className:'',section:'',rollNo:'',date:''};
  els.opencv.textContent='OpenCV: loading…';
  els.startCamera.disabled=true;
  els.scanBtn.disabled=true;
  renderAnswerKeyStatus();
  debugLog('Phase 9 initialized; camera requires explicit user action');
  waitForOpenCV();

  window.P9OMR={initCamera,stopCamera,startAutoScan,stopAutoScan,captureFrame,detectDocument,validateQuadrilateral,sortCorners,isFullPage,warpDocument,detectBubble:refineBubbleCenter,calculateBubbleScore:measureBubble,analyzeQuestion,analyzeAllQuestions,detectSet:resolveSetForScan,calculateScore,drawResultOverlay,showResults,saveOMRResult,startCalibration,saveCalibration:saveCalibrationStore,cleanupOpenCV,resetScanner,parseAnswerKeyText,applyAnswerKeyText,handleGalleryFile,OMR_CONFIG,ANSWER_KEYS,OMR_PROFILES};
})();
