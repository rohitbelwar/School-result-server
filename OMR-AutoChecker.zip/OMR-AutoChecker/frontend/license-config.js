/* eGyan Classes — OMR Auto-Checker licensing configuration.
   The OMR licence API is mounted inside server1.js; no second port is required.
   Nothing secret belongs here: signing keys and admin credentials stay on the server. */
(function () {
  /* 1) Local development: server1.js serves OMR on port 3000 by default. */
  var LOCAL_API = "http://localhost:3000";

  /* 2) Production: by default use the same HTTPS origin that serves /omr/.
        Set this only if the frontend and server1.js are intentionally hosted on different origins. */
  var PRODUCTION_API = "";

  var h = location.hostname, isLocal = location.protocol === "file:" || h === "localhost" || h === "127.0.0.1" || h === "[::1]";

  window.EGYAN_LICENSE = {
    api: isLocal ? LOCAL_API : (PRODUCTION_API || location.origin),

    /* Optional: paste the server's PUBLIC key (printed on start-up / GET /api/v1/public-key) to pin it.
       If null, the app fetches it once and pins that copy. */
    publicKey: null,

    /* Payment details. UPI ID confirmed by the owner as 6200727245@ybl.
       NOTE: the supplied QR image encodes 6200727245@ibl (same number, same name "Mr ROHIT KUMAR"). The image is unchanged.
       Before going live, scan the QR with a UPI app, pay ₹1 and confirm it reaches the owner's account. */
    upiId: "6200727245@ybl",
    payeeName: "Mr ROHIT KUMAR",
    whatsapp: "6200727245",
    whatsappCountryCode: "91",
    price: 500,
    qrImage: "assets/phonepe-payment-qr.png"
  };
})();
