'use strict';
/* Admin panel. Every request is authenticated by the server (Bearer session). Nothing here is trusted: approval happens ONLY on the server.
   Customer-supplied text is always inserted with textContent — never innerHTML — so it cannot run script in this panel. */
(function () {
  const $ = id => document.getElementById(id);
  let token = sessionStorage.getItem('egyan_admin_token') || '', admin = '', status = '', timer = 0, shotUrl = '';
  const WA = '6200727245';
  function h(tag, props, ...kids) {
    const e = document.createElement(tag);
    for (const k in (props || {})) { if (k === 'class') e.className = props[k]; else if (k === 'text') e.textContent = props[k]; else if (k.startsWith('on')) e.addEventListener(k.slice(2), props[k]); else e.setAttribute(k, props[k]); }
    for (const c of kids.flat(Infinity)) if (c != null) e.append(c.nodeType ? c : document.createTextNode(String(c)));
    return e;
  }
  const money = n => '₹' + Number(n || 0).toLocaleString('en-IN');
  const when = t => t ? new Date(t).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';
  const day = t => t ? new Date(t).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
  const pill = (s) => h('span', { class: 'pill ' + (s || 'none'), text: s ? s.charAt(0).toUpperCase() + s.slice(1) : '—' });
  function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.remove('hidden'); clearTimeout(timer); timer = setTimeout(() => t.classList.add('hidden'), 3500); }
  async function api(method, url, body, raw) {
    const r = await fetch(url, { method, headers: Object.assign({ authorization: 'Bearer ' + token }, body ? { 'content-type': 'application/json' } : {}), body: body ? JSON.stringify(body) : undefined });
    if (r.status === 401 && !/login$/.test(url)) { signOut(true); throw new Error('Session expired. Please sign in again.'); }
    if (raw) { if (!r.ok) throw new Error('Not available'); return r; }
    const j = await r.json().catch(() => ({})); if (!r.ok || j.ok === false) throw new Error(j.message || 'Request failed'); return j;
  }
  function show(signedIn) { $('login').classList.toggle('hidden', signedIn); $('app').classList.toggle('hidden', !signedIn); }
  function signOut(expired) { if (token && !expired) fetch('/api/admin/logout', { method: 'POST', headers: { authorization: 'Bearer ' + token } }).catch(() => {}); token = ''; sessionStorage.removeItem('egyan_admin_token'); closeDlg(); show(false); if (expired) { const e = $('loginErr'); e.textContent = 'Session expired. Please sign in again.'; e.classList.remove('hidden'); } }
  async function login() {
    const e = $('loginErr'); e.classList.add('hidden'); $('loginBtn').disabled = true;
    try { const r = await fetch('/api/admin/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username: $('u').value, password: $('p').value }) }); const j = await r.json(); if (!r.ok) throw new Error(j.message || 'Sign-in failed');
      token = j.token; admin = j.username; sessionStorage.setItem('egyan_admin_token', token); $('p').value = ''; start(); }
    catch (x) { e.textContent = x.message; e.classList.remove('hidden'); } finally { $('loginBtn').disabled = false; }
  }
  async function start() { try { admin = (await api('GET', '/api/admin/me')).username; } catch (_) { return; } $('who').textContent = 'Signed in as ' + admin; show(true); loadAll(); }
  const loadAll = () => Promise.all([loadSummary(), loadPayments()]).catch(x => toast(x.message));

  async function loadSummary() {
    const s = await api('GET', '/api/admin/summary'), box = $('cards'); box.replaceChildren();
    [['Total Payment Requests', s.totalRequests, ''], ['Pending Payments', s.pending, 'pending' + (s.pending ? ' pend-alert' : '')], ['Approved Payments', s.approved, 'ok'], ['Rejected Payments', s.rejected, 'bad'],
     ['Active Licenses', s.activeLicenses, 'ok'], ['Expired Licenses', s.expiredLicenses, 'bad'], ['Total Verified Revenue', money(s.verifiedRevenue), ''], ['Licenses Expiring Soon', s.expiringSoon, 'pending']]
      .forEach(([l, v, c]) => box.append(h('div', { class: 'card stat ' + c }, h('span', { text: l }), h('b', { text: String(v) }))));
    document.title = (s.pending ? '(' + s.pending + ') ' : '') + 'Admin — eGyan Classes OMR Auto-Checker';
  }
  async function loadPayments() {
    const p = new URLSearchParams(); if (status) p.set('status', status); if ($('q').value.trim()) p.set('q', $('q').value.trim());
    const j = await api('GET', '/api/admin/payments?' + p), body = $('rows'); body.replaceChildren(); $('none').classList.toggle('hidden', j.items.length > 0);
    j.items.forEach(x => body.append(h('tr', {},
      h('td', { class: 'mono', text: x.id }), h('td', { text: x.school }), h('td', {}, x.contactName, h('div', { class: 'muted', text: x.contactPhone || '' })), h('td', { class: 'mono', text: x.txnId }),
      h('td', { class: 'num', text: money(x.amount) }), h('td', { text: when(x.createdAt) }), h('td', {}, pill(x.status), x.kind === 'renewal' ? h('div', { class: 'muted', text: 'renewal' }) : null),
      h('td', {}, pill(x.licenseStatus)), h('td', {}, h('button', { class: 'btn small' + (x.status === 'pending' ? ' primary' : ''), type: 'button', text: x.status === 'pending' ? 'Review' : 'View', onclick: () => openPayment(x.id) })))));
  }
  async function loadLicenses() {
    const j = await api('GET', '/api/admin/licenses?q=' + encodeURIComponent($('lq').value.trim())), b = $('lrows'); b.replaceChildren();
    j.items.forEach(l => b.append(h('tr', {}, h('td', { class: 'mono', text: l.id }), h('td', { text: l.school }), h('td', {}, pill(l.status)), h('td', { text: when(l.issuedAt) }), h('td', { text: when(l.activatedAt) }), h('td', { text: day(l.expiresAt) }),
      h('td', {}, h('button', { class: 'btn small', type: 'button', text: 'Open', onclick: () => openPayment(l.paymentId) })))));
    if (!j.items.length) b.append(h('tr', {}, h('td', { colspan: 7, class: 'empty', text: 'No licences yet.' })));
  }
  async function loadAudit() {
    const j = await api('GET', '/api/admin/audit?limit=200'), b = $('arows'); b.replaceChildren();
    j.items.forEach(a => b.append(h('tr', {}, h('td', { text: when(a.ts) }), h('td', { text: a.actor }), h('td', { class: 'mono', text: a.action }), h('td', { class: 'mono', text: a.entity_id }), h('td', { class: 'muted', text: a.detail ? JSON.stringify(a.detail) : '' }))));
  }

  /* ---------- dialogs ---------- */
  function closeDlg() { if (shotUrl) { URL.revokeObjectURL(shotUrl); shotUrl = ''; } $('layer').replaceChildren(); }
  function dlg(...kids) { const m = h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', onclick: e => { if (e.target === m) closeDlg(); } }, h('div', { class: 'card dlg' }, kids)); $('layer').replaceChildren(m); return m; }
  const kv = rows => h('dl', { class: 'kv' }, rows.map(([k, v]) => [h('dt', { text: k }), h('dd', {}, v == null || v === '' ? '—' : v)]));
  async function openPayment(id) {
    let d; try { d = await api('GET', '/api/admin/payments/' + id); } catch (x) { return toast(x.message); }
    const p = d.payment, l = d.license, wa = p.contactPhone ? h('a', { class: 'btn small', target: '_blank', rel: 'noopener', text: 'WhatsApp customer', href: 'https://wa.me/91' + p.contactPhone.replace(/\D/g, '').slice(-10) + '?text=' + encodeURIComponent('Hello, this is eGyan Classes regarding your OMR Auto-Checker payment request ' + p.id + '.') }) : null;
    const shot = h('div'); const body = [h('h2', { text: 'Payment ' + p.id }), h('div', {}, pill(p.status), ' ', p.kind === 'renewal' ? h('span', { class: 'muted', text: 'Renewal' }) : ''),
      h('h3', { text: 'Customer-submitted details' }),
      kv([['School', p.school], ['Authorised contact', p.contactName], ['Contact number', p.contactPhone], ['UPI transaction / reference ID', h('span', { class: 'mono', text: p.txnId })], ['Amount claimed', money(p.amount)], ['Customer says paid at', when(p.paidAt)], ['Request submitted', when(p.createdAt)], ['Checks run so far', d.sheetsChecked]]),
      p.hasScreenshot ? [h('h3', { text: 'Optional screenshot (supporting information only — never proof)' }), shot] : null];
    if (p.status === 'pending') body.push(h('div', { class: 'warnbox', text: 'Check the real incoming payment in your bank / UPI app (amount, reference ID, date) before approving. A screenshot or a typed ID proves nothing.' }));
    if (p.status === 'rejected') body.push(kv([['Rejected by', p.decidedBy], ['Reason', p.rejectReason], ['Rejected at', when(p.decidedAt)]]));
    if (p.status === 'approved') body.push(h('h3', { text: 'Licence' }), kv([['Approved by', p.decidedBy], ['Approved at', when(p.decidedAt)], ['Licence ID', l && h('span', { class: 'mono', text: l.id })], ['Licence status', l && pill(l.status)], ['Activated', l && when(l.activatedAt)], ['Expires', l && day(l.expiresAt)], ['Wrong code attempts', l && l.attempts]]));
    body.push(h('h3', { text: 'Audit history' }), h('ul', { class: 'hist' }, d.history.length ? d.history.map(x => h('li', {}, h('b', { text: x.action }), ' · ' + x.actor + ' · ' + when(x.ts), x.detail ? h('div', { class: 'muted', text: JSON.stringify(x.detail) }) : null)) : h('li', { text: 'No history.' })));
    const acts = h('div', { class: 'actions' }, wa, h('button', { class: 'btn', type: 'button', text: 'Close', onclick: closeDlg }));
    if (p.status === 'pending') { acts.prepend(h('button', { class: 'btn danger', type: 'button', text: 'Reject Payment', onclick: () => rejectDlg(p) }), h('button', { class: 'btn ok', type: 'button', text: 'Approve Payment & Generate License', onclick: () => approveDlg(p) })); }
    if (l && l.status === 'issued') acts.prepend(h('button', { class: 'btn small', type: 'button', text: 'Show activation code', onclick: async () => { try { const r = await api('POST', '/api/admin/licenses/' + l.id + '/reveal-code'); codeDlg(p, r.activationCode, 'Activation code (not yet activated)'); } catch (x) { toast(x.message); } } }));
    if (l && l.status !== 'revoked') acts.prepend(h('button', { class: 'btn danger small', type: 'button', text: 'Revoke licence', onclick: () => revokeDlg(l) }));
    body.push(acts); dlg(body);
    if (p.hasScreenshot) api('GET', '/api/admin/payments/' + p.id + '/screenshot', null, true).then(r => r.blob()).then(b => { shotUrl = URL.createObjectURL(b); shot.append(h('img', { class: 'shot', src: shotUrl, alt: 'Customer screenshot' })); }).catch(() => shot.append('Screenshot unavailable.'));
  }
  function approveDlg(p) {
    const err = h('div', { class: 'err hidden', role: 'alert' }), btn = h('button', { class: 'btn ok', type: 'button', text: 'Yes — ₹500 received, approve' });
    btn.addEventListener('click', async () => { btn.disabled = true; try { const r = await api('POST', '/api/admin/payments/' + p.id + '/approve', { confirmReceived: true }); loadAll(); codeDlg(p, r.activationCode, 'Payment approved — licence generated'); }
      catch (x) { err.textContent = x.message; err.classList.remove('hidden'); btn.disabled = false; } });
    dlg(h('h2', { text: 'Approve payment ' + p.id }), h('div', { class: 'warnbox', text: 'Confirm that ₹500 has been received and verified in the bank/UPI account before approving this payment.' }), kv([['School', p.school], ['UPI reference ID', h('span', { class: 'mono', text: p.txnId })], ['Amount', money(p.amount)]]), err, h('div', { class: 'actions' }, h('button', { class: 'btn', type: 'button', text: 'Cancel', onclick: () => openPayment(p.id) }), btn));
  }
  function rejectDlg(p) {
    const r = h('textarea', { rows: 3, maxlength: 300, placeholder: 'e.g. Amount not received / reference ID not found' }), err = h('div', { class: 'err hidden', role: 'alert' }), btn = h('button', { class: 'btn danger', type: 'button', text: 'Reject payment' });
    btn.addEventListener('click', async () => { btn.disabled = true; try { await api('POST', '/api/admin/payments/' + p.id + '/reject', { reason: r.value }); toast('Payment rejected'); loadAll(); openPayment(p.id); } catch (x) { err.textContent = x.message; err.classList.remove('hidden'); btn.disabled = false; } });
    dlg(h('h2', { text: 'Reject payment ' + p.id }), h('label', {}, 'Reason (required, saved in the audit log)', r), err, h('div', { class: 'actions' }, h('button', { class: 'btn', type: 'button', text: 'Cancel', onclick: () => openPayment(p.id) }), btn));
  }
  function revokeDlg(l) {
    const r = h('textarea', { rows: 3, maxlength: 300, placeholder: 'Reason for revoking this licence' }), err = h('div', { class: 'err hidden', role: 'alert' }), btn = h('button', { class: 'btn danger', type: 'button', text: 'Revoke licence' });
    btn.addEventListener('click', async () => { btn.disabled = true; try { await api('POST', '/api/admin/licenses/' + l.id + '/revoke', { reason: r.value }); toast('Licence revoked'); closeDlg(); loadAll(); loadLicenses(); } catch (x) { err.textContent = x.message; err.classList.remove('hidden'); btn.disabled = false; } });
    dlg(h('h2', { text: 'Revoke licence ' + l.id }), h('div', { class: 'warnbox', text: 'The school will not be able to check new OMR sheets. Their saved results stay available. This action is recorded in the audit log.' }), h('label', {}, 'Reason (required)', r), err, h('div', { class: 'actions' }, h('button', { class: 'btn', type: 'button', text: 'Cancel', onclick: closeDlg }), btn));
  }
  function codeDlg(p, code, title) {
    const msg = 'Hello, your eGyan Classes OMR Auto-Checker payment ' + p.id + ' is verified. Open the app → License → Activate, and enter the 4-digit code shown there (your code: ' + code + ').';
    dlg(h('h2', { text: title }), h('p', { class: 'muted', text: 'Request ' + p.id + ' · ' + p.school + '. The customer can also see this code inside the app (License → Check status).' }), h('div', { class: 'code', text: code }),
      h('div', { class: 'actions' }, h('button', { class: 'btn', type: 'button', text: 'Copy code', onclick: () => navigator.clipboard.writeText(code).then(() => toast('Code copied')) }),
        p.contactPhone ? h('a', { class: 'btn', target: '_blank', rel: 'noopener', text: 'Send on WhatsApp', href: 'https://wa.me/91' + p.contactPhone.replace(/\D/g, '').slice(-10) + '?text=' + encodeURIComponent(msg) }) : null, h('button', { class: 'btn primary', type: 'button', text: 'Done', onclick: closeDlg })));
  }
  function pwDlg() {
    const a = h('input', { type: 'password', autocomplete: 'current-password' }), b = h('input', { type: 'password', autocomplete: 'new-password' }), err = h('div', { class: 'err hidden' }), btn = h('button', { class: 'btn primary', type: 'button', text: 'Change password' });
    btn.addEventListener('click', async () => { try { await api('POST', '/api/admin/password', { current: a.value, next: b.value }); toast('Password changed — sign in again'); signOut(false); } catch (x) { err.textContent = x.message; err.classList.remove('hidden'); } });
    dlg(h('h2', { text: 'Change password' }), h('label', {}, 'Current password', a), h('label', {}, 'New password (min 10 characters)', b), err, h('div', { class: 'actions' }, h('button', { class: 'btn', type: 'button', text: 'Cancel', onclick: closeDlg }), btn));
  }

  /* ---------- wiring ---------- */
  $('loginBtn').addEventListener('click', login); $('p').addEventListener('keydown', e => { if (e.key === 'Enter') login(); }); $('u').addEventListener('keydown', e => { if (e.key === 'Enter') $('p').focus(); });
  $('logoutBtn').addEventListener('click', () => signOut(false)); $('pwBtn').addEventListener('click', pwDlg); $('refresh').addEventListener('click', loadAll);
  $('seg').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; status = b.dataset.s; [...$('seg').children].forEach(x => x.classList.toggle('active', x === b)); loadPayments().catch(x => toast(x.message)); });
  let qt = 0; const debounce = (fn) => () => { clearTimeout(qt); qt = setTimeout(fn, 250); };
  $('q').addEventListener('input', debounce(() => loadPayments().catch(x => toast(x.message)))); $('lq').addEventListener('input', debounce(() => loadLicenses().catch(x => toast(x.message))));
  document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => { document.querySelectorAll('.tab').forEach(x => x.classList.toggle('active', x === t)); ['pay', 'lic', 'aud'].forEach(k => $('tab-' + k).classList.toggle('hidden', k !== t.dataset.tab));
    $('cards').classList.toggle('hidden', t.dataset.tab !== 'pay'); if (t.dataset.tab === 'lic') loadLicenses().catch(x => toast(x.message)); if (t.dataset.tab === 'aud') loadAudit().catch(x => toast(x.message)); }));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeDlg(); });
  if (token) start(); else show(false);
})();
