'use strict';
/* eGyan Classes — OMR Auto-Checker licence server.
   Zero npm dependencies: Node >= 22.5 (built-in node:sqlite, node:crypto, node:http).
   Started by ../../server2.js (OMR licence server). Listens on PORT_OMR (default 3001), never on server1's PORT.
   The server is the ONLY authority for: payment approval, activation codes, licence validity and the free-trial counter. */
const http = require('node:http'), fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const CFG = {
  port: Number(process.env.PORT_OMR || 3001),   // deliberately NOT process.env.PORT: that belongs to server1.js (school server)
  host: process.env.HOST || '0.0.0.0',
  dataDir: process.env.DATA_DIR || path.join(__dirname, 'data'),
  allowedOrigins: (process.env.ALLOWED_ORIGINS || '*').split(',').map(s => s.trim()).filter(Boolean), // customer API only (file:// pages send Origin "null")
  trustProxy: process.env.TRUST_PROXY === '1',
  price: 500, trialAllowed: 20, licenseDays: 365, graceHours: 48,
  sessionHours: 8, maxBody: 700 * 1024, maxShot: 450 * 1024,
};
const DAY = 86400000;
fs.mkdirSync(path.join(CFG.dataDir, 'screenshots'), { recursive: true });

/* ---------- server-side secrets (never sent to the browser, except the PUBLIC verification key) ---------- */
const secretsFile = process.env.SECRETS_FILE || path.join(CFG.dataDir, 'secrets.json');
let S;
if (fs.existsSync(secretsFile)) S = JSON.parse(fs.readFileSync(secretsFile, 'utf8'));
else {
  const kp = crypto.generateKeyPairSync('ed25519');
  S = { privatePem: kp.privateKey.export({ type: 'pkcs8', format: 'pem' }), publicJwk: kp.publicKey.export({ format: 'jwk' }),
        hmacKey: crypto.randomBytes(32).toString('hex'), aesKey: crypto.randomBytes(32).toString('hex') };
  fs.writeFileSync(secretsFile, JSON.stringify(S, null, 2), { mode: 0o600 });
}
const PRIV = crypto.createPrivateKey(S.privatePem), HMAC_KEY = Buffer.from(S.hmacKey, 'hex'), AES_KEY = Buffer.from(S.aesKey, 'hex');

/* ---------- database ---------- */
const db = new DatabaseSync(process.env.DB_FILE || path.join(CFG.dataDir, 'egyan-license.db'));
db.exec(`
PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
CREATE TABLE IF NOT EXISTS clients(id TEXT PRIMARY KEY, secret_hash TEXT NOT NULL, school TEXT, created_at INTEGER NOT NULL, last_seen INTEGER);
CREATE TABLE IF NOT EXISTS usage(client_id TEXT NOT NULL REFERENCES clients(id), result_id TEXT NOT NULL, ts INTEGER NOT NULL, counted INTEGER NOT NULL, PRIMARY KEY(client_id,result_id));
CREATE TABLE IF NOT EXISTS payments(id TEXT PRIMARY KEY, client_id TEXT NOT NULL REFERENCES clients(id), school TEXT NOT NULL, contact_name TEXT NOT NULL, contact_phone TEXT,
  txn_id TEXT NOT NULL, txn_norm TEXT NOT NULL, amount INTEGER NOT NULL, paid_at INTEGER NOT NULL, status TEXT NOT NULL CHECK(status IN('pending','approved','rejected')),
  status_token_hash TEXT NOT NULL, screenshot TEXT, created_at INTEGER NOT NULL, decided_by TEXT, decided_at INTEGER, reject_reason TEXT, kind TEXT NOT NULL DEFAULT 'new');
CREATE UNIQUE INDEX IF NOT EXISTS ux_txn_live ON payments(txn_norm) WHERE status IN('pending','approved');
CREATE UNIQUE INDEX IF NOT EXISTS ux_one_pending ON payments(client_id) WHERE status='pending';
CREATE TABLE IF NOT EXISTS licenses(id TEXT PRIMARY KEY, payment_id TEXT NOT NULL UNIQUE REFERENCES payments(id), client_id TEXT NOT NULL REFERENCES clients(id),
  code_hash TEXT NOT NULL, code_enc TEXT, status TEXT NOT NULL CHECK(status IN('issued','active','revoked')), issued_at INTEGER NOT NULL, issued_by TEXT NOT NULL,
  activated_at INTEGER, expires_at INTEGER, attempts INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0, lock_level INTEGER NOT NULL DEFAULT 0,
  revoked_at INTEGER, revoked_by TEXT, revoke_reason TEXT);
CREATE TABLE IF NOT EXISTS admins(username TEXT PRIMARY KEY, pw_hash TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, username TEXT NOT NULL, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, actor TEXT NOT NULL, action TEXT NOT NULL, entity TEXT NOT NULL, entity_id TEXT NOT NULL, detail TEXT);
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit BEGIN SELECT RAISE(ABORT,'audit log is append-only'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit BEGIN SELECT RAISE(ABORT,'audit log is append-only'); END;
`);
const q = (sql) => db.prepare(sql);
function tx(fn) { db.exec('BEGIN IMMEDIATE'); try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { try { db.exec('ROLLBACK'); } catch (_) {} throw e; } }
const audit = (actor, action, entity, id, detail) => q('INSERT INTO audit(ts,actor,action,entity,entity_id,detail) VALUES(?,?,?,?,?,?)').run(Date.now(), actor, action, entity, id, detail ? JSON.stringify(detail) : null);

/* ---------- small helpers ---------- */
class HttpError extends Error { constructor(status, code, message, extra) { super(message || code); this.status = status; this.code = code; this.extra = extra; } }
const sha256 = s => crypto.createHash('sha256').update(s).digest('hex');
const b64u = b => Buffer.from(b).toString('base64url');
const safeEq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
const clean = (v, max) => String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f<>]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
const ALPHA = 'ABCDEFGHJKMNPQRSTVWXYZ23456789';
const rid = (prefix, n) => prefix + Array.from(crypto.randomBytes(n), b => ALPHA[b % ALPHA.length]).join('');
const hashCode = (licId, code) => crypto.createHmac('sha256', HMAC_KEY).update(licId + ':' + code).digest('hex');
function encCode(code) { const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', AES_KEY, iv), e = Buffer.concat([c.update(code, 'utf8'), c.final()]); return [iv, c.getAuthTag(), e].map(b => b.toString('base64')).join('.'); }
function decCode(s) { const [iv, tag, e] = s.split('.').map(x => Buffer.from(x, 'base64')), d = crypto.createDecipheriv('aes-256-gcm', AES_KEY, iv); d.setAuthTag(tag); return Buffer.concat([d.update(e), d.final()]).toString('utf8'); }
const hashPw = (pw, salt = crypto.randomBytes(16)) => 'scrypt$' + salt.toString('hex') + '$' + crypto.scryptSync(pw, salt, 64).toString('hex');
const DUMMY_PW = hashPw('dummy-password-for-timing');
function checkPw(pw, stored) { const [, salt, h] = stored.split('$'); return safeEq(crypto.scryptSync(pw, Buffer.from(salt, 'hex'), 64).toString('hex'), h); }

/* in-memory sliding-window rate limiter (per process; put a reverse proxy / WAF in front for more) */
const hits = new Map();
function rate(key, max, windowMs) {
  const now = Date.now(), arr = (hits.get(key) || []).filter(t => now - t < windowMs);
  if (arr.length >= max) { hits.set(key, arr); return Math.ceil((windowMs - (now - arr[0])) / 1000); }
  arr.push(now); hits.set(key, arr); if (hits.size > 5000) for (const [k, v] of hits) if (!v.length || now - v[v.length - 1] > 3600000) hits.delete(k);
  return 0;
}
const RATE_MULT = Number(process.env.RATE_MULT || 1); // >1 ONLY for automated tests
const needRate = (key, max, windowMs, msg) => { const w = rate(key, max * RATE_MULT, windowMs); if (w) throw new HttpError(429, 'rate_limited', msg || 'Too many requests. Please try again later.', { retryAfter: w }); };

/* ---------- licensing logic ---------- */
function entitlement(cid) {
  const now = Date.now();
  const used = q('SELECT COUNT(*) n FROM usage WHERE client_id=? AND counted=1').get(cid).n;
  const lics = q("SELECT * FROM licenses WHERE client_id=? AND status IN('active','revoked')").all(cid);
  const live = lics.filter(l => l.status === 'active' && l.expires_at > now), dead = lics.filter(l => l.status === 'active' && l.expires_at <= now), rev = lics.filter(l => l.status === 'revoked');
  const e = { clientId: cid, trialAllowed: CFG.trialAllowed, trialUsed: used, trialRemaining: Math.max(0, CFG.trialAllowed - used), licenseStatus: 'none', activatedAt: null, expiresAt: null };
  if (live.length) { e.state = 'active'; e.licenseStatus = 'active'; e.activatedAt = Math.min(...live.map(l => l.activated_at)); e.expiresAt = Math.max(...live.map(l => l.expires_at)); }
  else if (rev.length && Math.max(...rev.map(l => l.revoked_at || 0)) >= Math.max(0, ...dead.map(l => l.activated_at))) { e.state = 'revoked'; e.licenseStatus = 'revoked'; } // the most recent event wins
  else if (dead.length) { e.state = 'expired'; e.licenseStatus = 'expired'; e.activatedAt = Math.min(...dead.map(l => l.activated_at)); e.expiresAt = Math.max(...dead.map(l => l.expires_at)); }
  else e.state = e.trialRemaining > 0 ? 'trial' : 'trial_completed';
  const pend = q("SELECT id,status FROM payments WHERE client_id=? ORDER BY created_at DESC LIMIT 1").get(cid);
  e.latestRequest = pend ? { id: pend.id, status: pend.status } : null;
  e.serverTime = now;
  return e;
}
function signedEntitlement(cid) {
  const e = entitlement(cid), now = Date.now();
  const payload = { v: 1, cid, state: e.state, trialAllowed: e.trialAllowed, trialUsed: e.trialUsed, trialRemaining: e.trialRemaining, expiresAt: e.expiresAt, activatedAt: e.activatedAt, iat: now, exp: now + CFG.graceHours * 3600000 };
  const body = b64u(JSON.stringify(payload)), sig = b64u(crypto.sign(null, Buffer.from(body), PRIV));
  return Object.assign(e, { token: body + '.' + sig });
}

/* ---------- request plumbing ---------- */
const ip = req => (CFG.trustProxy && req.headers['x-forwarded-for'] ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : req.socket.remoteAddress) || 'unknown';
function readJson(req) {
  return new Promise((resolve, reject) => {
    const chunks = []; let n = 0;
    req.on('data', c => { n += c.length; if (n > CFG.maxBody) { reject(new HttpError(413, 'too_large', 'Request is too large.')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { if (!chunks.length) return resolve({}); try { const v = JSON.parse(Buffer.concat(chunks).toString('utf8')); resolve(v && typeof v === 'object' ? v : {}); } catch (_) { reject(new HttpError(400, 'bad_json', 'Invalid JSON.')); } });
    req.on('error', reject);
  });
}
function send(res, status, obj, extraHeaders) {
  const body = JSON.stringify(obj);
  res.writeHead(status, Object.assign({ 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }, extraHeaders));
  res.end(body);
}
function clientAuth(req) {
  const id = String(req.headers['x-client-id'] || ''), secret = String(req.headers['x-client-secret'] || '');
  if (!/^[0-9a-f-]{36}$/.test(id) || secret.length < 32 || secret.length > 128) throw new HttpError(401, 'unauthorized', 'Not authorised.');
  const row = q('SELECT * FROM clients WHERE id=?').get(id);
  if (!row || !safeEq(row.secret_hash, sha256(secret))) throw new HttpError(401, 'unauthorized', 'Not authorised.');
  q('UPDATE clients SET last_seen=? WHERE id=?').run(Date.now(), id);
  return row;
}
function adminAuth(req) {
  const m = /^Bearer ([A-Za-z0-9_-]{20,100})$/.exec(String(req.headers.authorization || ''));
  if (!m) throw new HttpError(401, 'unauthorized', 'Administrator sign-in required.');
  const s = q('SELECT * FROM sessions WHERE token_hash=?').get(sha256(m[1]));
  if (!s || s.expires_at < Date.now()) throw new HttpError(401, 'unauthorized', 'Session expired. Please sign in again.');
  return s.username;
}
const payRow = r => ({ id: r.id, clientId: r.client_id, school: r.school, contactName: r.contact_name, contactPhone: r.contact_phone, txnId: r.txn_id, amount: r.amount, paidAt: r.paid_at, status: r.status,
  createdAt: r.created_at, decidedBy: r.decided_by, decidedAt: r.decided_at, rejectReason: r.reject_reason, kind: r.kind, hasScreenshot: !!r.screenshot });
const licRow = (l, now = Date.now()) => l && ({ id: l.id, paymentId: l.payment_id, clientId: l.client_id, status: l.status === 'active' && l.expires_at <= now ? 'expired' : l.status, issuedAt: l.issued_at, issuedBy: l.issued_by,
  activatedAt: l.activated_at, expiresAt: l.expires_at, attempts: l.attempts, lockedUntil: l.locked_until, revokedAt: l.revoked_at, revokedBy: l.revoked_by, revokeReason: l.revoke_reason, codePending: !!l.code_enc });

/* ---------- customer API ---------- */
const routes = [];
const route = (method, re, fn) => routes.push({ method, re, fn });

route('GET', /^\/healthz$/, () => ({ ok: true }));
route('GET', /^\/api\/omr\/health$/, () => {   // real DB round-trip: a broken database must NOT report success
  try { q('SELECT 1 AS n').get(); } catch (_) { throw new HttpError(503, 'db_unavailable', 'Database unavailable.', { success: false }); }
  return { success: true, service: 'OMR Auto-Checker License API' };
});
route('GET', /^\/api\/v1\/public-key$/, () => ({ ok: true, publicKey: S.publicJwk, price: CFG.price, trialAllowed: CFG.trialAllowed }));

route('POST', /^\/api\/v1\/client\/register$/, async (req) => {
  needRate('reg:' + ip(req), 30, DAY, 'Too many new installations from this network today.');
  const b = await readJson(req);
  if (!/^[0-9a-f-]{36}$/.test(String(b.clientId || '')) || String(b.secret || '').length < 32 || String(b.secret).length > 128) throw new HttpError(400, 'bad_request', 'Invalid registration.');
  const ex = q('SELECT * FROM clients WHERE id=?').get(b.clientId);
  if (ex) { if (!safeEq(ex.secret_hash, sha256(b.secret))) throw new HttpError(401, 'unauthorized', 'Not authorised.'); }
  else q('INSERT INTO clients(id,secret_hash,school,created_at,last_seen) VALUES(?,?,?,?,?)').run(b.clientId, sha256(b.secret), clean(b.school, 80) || null, Date.now(), Date.now());
  return { ok: true, entitlement: signedEntitlement(b.clientId) };
});
route('GET', /^\/api\/v1\/entitlement$/, async (req) => { const c = clientAuth(req); needRate('ent:' + c.id, 120, 3600000); return { ok: true, entitlement: signedEntitlement(c.id) }; });
route('POST', /^\/api\/v1\/usage$/, async (req) => {
  const c = clientAuth(req); needRate('use:' + c.id, 300, 3600000);
  const b = await readJson(req), ids = Array.isArray(b.ids) ? b.ids.slice(0, 100) : [];
  if (b.school) q('UPDATE clients SET school=? WHERE id=?').run(clean(b.school, 80), c.id);
  tx(() => {
    const licensed = entitlement(c.id).state === 'active';
    const ins = q('INSERT OR IGNORE INTO usage(client_id,result_id,ts,counted) VALUES(?,?,?,?)');
    for (const id of ids) { const r = clean(id, 64); if (r) ins.run(c.id, r, Date.now(), licensed ? 0 : 1); }
  });
  return { ok: true, entitlement: signedEntitlement(c.id) };
});

function validatePayment(b) {
  const school = clean(b.school, 80), contactName = clean(b.contactName, 60), phone = clean(b.contactPhone, 20), txn = clean(b.txnId, 40).replace(/\s+/g, '');
  if (school.length < 2) throw new HttpError(400, 'validation', 'School name is required.', { field: 'school' });
  if (contactName.length < 2) throw new HttpError(400, 'validation', 'Authorised contact name is required.', { field: 'contactName' });
  if (phone && !/^[0-9+\-\s]{7,15}$/.test(phone)) throw new HttpError(400, 'validation', 'Contact number looks invalid.', { field: 'contactPhone' });
  if (!/^[A-Za-z0-9]{8,35}$/.test(txn)) throw new HttpError(400, 'validation', 'Enter the UPI transaction / reference ID exactly as shown in your UPI app (8–35 letters or digits).', { field: 'txnId' });
  if (Number(b.amount) !== CFG.price) throw new HttpError(400, 'validation', `The licence fee is exactly ₹${CFG.price}. If you paid a different amount, contact us on WhatsApp.`, { field: 'amount' });
  const paidAt = Number(b.paidAt), now = Date.now();
  if (!Number.isFinite(paidAt) || paidAt < now - 45 * DAY || paidAt > now + 10 * 60000) throw new HttpError(400, 'validation', 'Payment date/time looks wrong.', { field: 'paidAt' });
  return { school, contactName, phone: phone || null, txn, amount: CFG.price, paidAt };
}
function saveScreenshot(id, dataUrl) {
  const m = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
  if (!m) throw new HttpError(400, 'validation', 'Screenshot must be a PNG, JPG or WebP image.', { field: 'screenshot' });
  const buf = Buffer.from(m[2], 'base64'); if (buf.length > CFG.maxShot) throw new HttpError(400, 'validation', 'Screenshot is too large (max 450 KB).', { field: 'screenshot' });
  const magic = { png: [0x89, 0x50, 0x4e, 0x47], jpeg: [0xff, 0xd8, 0xff], webp: [0x52, 0x49, 0x46, 0x46] }[m[1]];
  if (!magic.every((v, i) => buf[i] === v)) throw new HttpError(400, 'validation', 'The screenshot file is not a valid image.', { field: 'screenshot' });
  const file = id + '.' + (m[1] === 'jpeg' ? 'jpg' : m[1]); fs.writeFileSync(path.join(CFG.dataDir, 'screenshots', file), buf); return file;
}
route('POST', /^\/api\/v1\/payments$/, async (req) => {
  const c = clientAuth(req); needRate('pay:' + c.id, 8, 3600000, 'Too many submissions. Please wait before trying again.'); needRate('payip:' + ip(req), 30, 3600000);
  const b = await readJson(req), v = validatePayment(b), id = rid('PAY-', 10), statusToken = crypto.randomBytes(24).toString('base64url');
  const hasLic = q("SELECT 1 FROM licenses WHERE client_id=? AND status IN('active','revoked')").get(c.id);
  let shot = null;
  try {
    tx(() => {
      if (b.screenshot) shot = saveScreenshot(id, b.screenshot);
      q('UPDATE clients SET school=? WHERE id=?').run(v.school, c.id);
      q('INSERT INTO payments(id,client_id,school,contact_name,contact_phone,txn_id,txn_norm,amount,paid_at,status,status_token_hash,screenshot,created_at,kind) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        .run(id, c.id, v.school, v.contactName, v.phone, v.txn, v.txn.toUpperCase(), v.amount, v.paidAt, 'pending', sha256(statusToken), shot, Date.now(), hasLic ? 'renewal' : 'new');
      audit('customer:' + c.id.slice(0, 8), 'payment.submitted', 'payment', id, { school: v.school, txn: v.txn, amount: v.amount });
    });
  } catch (e) {
    if (shot) try { fs.unlinkSync(path.join(CFG.dataDir, 'screenshots', shot)); } catch (_) {}
    if (e instanceof HttpError) throw e;
    if (/UNIQUE constraint failed: payments\.txn_norm/.test(e.message)) throw new HttpError(409, 'duplicate_txn', 'This transaction ID has already been submitted. Check the ID, or contact us on WhatsApp.');
    if (/UNIQUE constraint failed: payments\.client_id/.test(e.message)) { const p = q("SELECT id FROM payments WHERE client_id=? AND status='pending'").get(c.id); throw new HttpError(409, 'already_pending', 'You already have a payment waiting for verification.', { requestId: p && p.id }); }
    throw e;
  }
  return { ok: true, requestId: id, statusToken, status: 'pending', message: 'Payment submitted for verification.' };
});
route('GET', /^\/api\/v1\/payments\/(PAY-[A-Z0-9]{10})$/, async (req, m) => {
  const c = clientAuth(req); needRate('pst:' + c.id, 120, 3600000);
  const p = q('SELECT * FROM payments WHERE id=? AND client_id=?').get(m[1], c.id);
  if (!p || !safeEq(p.status_token_hash, sha256(String(req.headers['x-status-token'] || '')))) throw new HttpError(404, 'not_found', 'Payment request not found.');
  const out = { ok: true, requestId: p.id, status: p.status, submittedAt: p.created_at, rejectReason: p.status === 'rejected' ? p.reject_reason : null, license: null };
  const l = q('SELECT * FROM licenses WHERE payment_id=?').get(p.id);
  if (l) { out.license = { status: licRow(l).status, activatedAt: l.activated_at, expiresAt: l.expires_at }; if (l.status === 'issued' && l.code_enc) out.activationCode = decCode(l.code_enc); }
  return out;
});
route('POST', /^\/api\/v1\/license\/activate$/, async (req) => {
  const c = clientAuth(req); needRate('act:' + c.id, 30, 3600000); needRate('actip:' + ip(req), 100, 3600000);
  const b = await readJson(req), code = String(b.code || '').trim(), generic = new HttpError(400, 'invalid_activation', 'Invalid activation details.');
  if (!/^PAY-[A-Z0-9]{10}$/.test(String(b.requestId || '')) || !/^\d{4}$/.test(code)) throw generic;
  const l = q('SELECT l.* FROM licenses l JOIN payments p ON p.id=l.payment_id WHERE p.id=? AND p.client_id=?').get(b.requestId, c.id);
  if (!l || l.status === 'revoked') throw generic;
  if (l.status === 'active') throw new HttpError(409, 'already_active', 'This licence is already activated.');
  const now = Date.now();
  if (l.locked_until > now) throw new HttpError(429, 'locked', 'Too many wrong attempts. Try again later.', { retryAfter: Math.ceil((l.locked_until - now) / 1000) });
  if (!safeEq(l.code_hash, hashCode(l.id, code))) {
    const attempts = l.attempts + 1; let lockedUntil = 0, level = l.lock_level;
    if (attempts % 5 === 0) { level++; lockedUntil = now + Math.min(24 * 3600000, 15 * 60000 * 2 ** (level - 1)); }
    q('UPDATE licenses SET attempts=?, locked_until=?, lock_level=? WHERE id=?').run(attempts, lockedUntil, level, l.id);
    audit('customer:' + c.id.slice(0, 8), 'activation.failed', 'license', l.id, { attempts });
    if (lockedUntil) throw new HttpError(429, 'locked', 'Too many wrong attempts. Try again later.', { retryAfter: Math.ceil((lockedUntil - now) / 1000) });
    throw generic;
  }
  tx(() => { // atomic: a double-click or a second device cannot activate the same licence twice
    const cur = q('SELECT * FROM licenses WHERE id=?').get(l.id); if (cur.status !== 'issued') throw new HttpError(409, 'already_active', 'This licence is already activated.');
    const live = q("SELECT MAX(expires_at) m FROM licenses WHERE client_id=? AND status='active' AND expires_at>?").get(c.id, now).m || 0;
    const start = Math.max(now, live);
    q("UPDATE licenses SET status='active', activated_at=?, expires_at=?, code_enc=NULL, attempts=0 WHERE id=? AND status='issued'").run(now, start + CFG.licenseDays * DAY, l.id);
    audit('customer:' + c.id.slice(0, 8), 'license.activated', 'license', l.id, { paymentId: l.payment_id, expiresAt: start + CFG.licenseDays * DAY });
  });
  return { ok: true, entitlement: signedEntitlement(c.id) };
});

/* ---------- admin API ---------- */
route('POST', /^\/api\/admin\/login$/, async (req) => {
  const b = await readJson(req), u = clean(b.username, 40).toLowerCase(), k = 'login:' + ip(req) + ':' + u;
  needRate('loginip:' + ip(req), 30, 900000, 'Too many sign-in attempts. Try again in 15 minutes.');
  const fails = (hits.get(k) || []).filter(t => Date.now() - t < 900000).length;
  if (fails >= 5) throw new HttpError(429, 'locked', 'Too many failed sign-ins. Try again in 15 minutes.');
  const a = q('SELECT * FROM admins WHERE username=?').get(u), good = checkPw(String(b.password || ''), a ? a.pw_hash : DUMMY_PW) && !!a;
  if (!good) { rate(k, 99, 900000); audit(u || 'unknown', 'admin.login_failed', 'admin', u || '-', { ip: ip(req) }); throw new HttpError(401, 'invalid_login', 'Invalid username or password.'); }
  hits.delete(k);
  const token = crypto.randomBytes(32).toString('base64url');
  q('DELETE FROM sessions WHERE expires_at<?').run(Date.now());
  q('INSERT INTO sessions(token_hash,username,created_at,expires_at) VALUES(?,?,?,?)').run(sha256(token), u, Date.now(), Date.now() + CFG.sessionHours * 3600000);
  audit(u, 'admin.login', 'admin', u, { ip: ip(req) });
  return { ok: true, token, username: u, expiresIn: CFG.sessionHours * 3600 };
});
route('POST', /^\/api\/admin\/logout$/, async (req) => { adminAuth(req); q('DELETE FROM sessions WHERE token_hash=?').run(sha256(String(req.headers.authorization).slice(7))); return { ok: true }; });
route('GET', /^\/api\/admin\/me$/, async (req) => ({ ok: true, username: adminAuth(req) }));
route('POST', /^\/api\/admin\/password$/, async (req) => {
  const u = adminAuth(req), b = await readJson(req), a = q('SELECT * FROM admins WHERE username=?').get(u);
  if (!checkPw(String(b.current || ''), a.pw_hash)) throw new HttpError(400, 'invalid_login', 'Current password is wrong.');
  if (String(b.next || '').length < 10) throw new HttpError(400, 'validation', 'New password must be at least 10 characters.');
  q('UPDATE admins SET pw_hash=? WHERE username=?').run(hashPw(String(b.next)), u); q('DELETE FROM sessions WHERE username=?').run(u); audit(u, 'admin.password_changed', 'admin', u); return { ok: true };
});
route('GET', /^\/api\/admin\/summary$/, async (req) => {
  adminAuth(req); const now = Date.now(), one = (s, ...p) => q(s).get(...p).n;
  return { ok: true, totalRequests: one('SELECT COUNT(*) n FROM payments'), pending: one("SELECT COUNT(*) n FROM payments WHERE status='pending'"), approved: one("SELECT COUNT(*) n FROM payments WHERE status='approved'"),
    rejected: one("SELECT COUNT(*) n FROM payments WHERE status='rejected'"), activeLicenses: one("SELECT COUNT(*) n FROM licenses WHERE status='active' AND expires_at>?", now),
    expiredLicenses: one("SELECT COUNT(*) n FROM licenses WHERE status='active' AND expires_at<=?", now), expiringSoon: one("SELECT COUNT(*) n FROM licenses WHERE status='active' AND expires_at>? AND expires_at<=?", now, now + 30 * DAY),
    verifiedRevenue: q("SELECT COALESCE(SUM(amount),0) n FROM payments WHERE status='approved'").get().n, currency: 'INR' };
});
route('GET', /^\/api\/admin\/payments$/, async (req, m, url) => {
  adminAuth(req); const st = url.searchParams.get('status'), term = clean(url.searchParams.get('q'), 60), lim = Math.min(200, Number(url.searchParams.get('limit')) || 100), off = Math.max(0, Number(url.searchParams.get('offset')) || 0);
  const where = [], p = [];
  if (['pending', 'approved', 'rejected'].includes(st)) { where.push('p.status=?'); p.push(st); }
  if (term) { where.push("(p.school LIKE ? ESCAPE '\\' OR p.id LIKE ? ESCAPE '\\' OR p.txn_id LIKE ? ESCAPE '\\' OR p.contact_phone LIKE ? ESCAPE '\\' OR p.contact_name LIKE ? ESCAPE '\\')"); const l = '%' + term.replace(/[\\%_]/g, '\\$&') + '%'; p.push(l, l, l, l, l); }
  const rows = q(`SELECT p.*, l.id lic_id, l.status lic_status, l.expires_at lic_exp, l.activated_at lic_act FROM payments p LEFT JOIN licenses l ON l.payment_id=p.id ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY p.created_at DESC LIMIT ? OFFSET ?`).all(...p, lim, off);
  const total = q(`SELECT COUNT(*) n FROM payments p ${where.length ? 'WHERE ' + where.join(' AND ') : ''}`).get(...p).n, now = Date.now();
  return { ok: true, total, items: rows.map(r => Object.assign(payRow(r), { licenseId: r.lic_id, licenseStatus: r.lic_id ? (r.lic_status === 'active' && r.lic_exp <= now ? 'expired' : r.lic_status) : null, licenseExpiresAt: r.lic_exp, licenseActivatedAt: r.lic_act })) };
});
route('GET', /^\/api\/admin\/payments\/(PAY-[A-Z0-9]{10})$/, async (req, m) => {
  adminAuth(req); const p = q('SELECT * FROM payments WHERE id=?').get(m[1]); if (!p) throw new HttpError(404, 'not_found', 'Not found.');
  const l = q('SELECT * FROM licenses WHERE payment_id=?').get(p.id), trial = q('SELECT COUNT(*) n FROM usage WHERE client_id=?').get(p.client_id).n;
  const hist = q("SELECT ts,actor,action,detail FROM audit WHERE (entity='payment' AND entity_id=?) OR (entity='license' AND entity_id=?) ORDER BY id").all(p.id, l ? l.id : '-');
  return { ok: true, payment: payRow(p), license: licRow(l), sheetsChecked: trial, history: hist.map(h => ({ ts: h.ts, actor: h.actor, action: h.action, detail: h.detail ? JSON.parse(h.detail) : null })) };
});
route('GET', /^\/api\/admin\/payments\/(PAY-[A-Z0-9]{10})\/screenshot$/, async (req, m, url, res) => {
  adminAuth(req); const p = q('SELECT screenshot FROM payments WHERE id=?').get(m[1]); if (!p || !p.screenshot) throw new HttpError(404, 'not_found', 'No screenshot.');
  const ext = path.extname(p.screenshot).slice(1), buf = fs.readFileSync(path.join(CFG.dataDir, 'screenshots', path.basename(p.screenshot)));
  res.writeHead(200, { 'content-type': { png: 'image/png', jpg: 'image/jpeg', webp: 'image/webp' }[ext], 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'content-security-policy': "default-src 'none'; sandbox" }); res.end(buf); return null;
});
route('POST', /^\/api\/admin\/payments\/(PAY-[A-Z0-9]{10})\/approve$/, async (req, m) => {
  const admin = adminAuth(req), b = await readJson(req);
  if (b.confirmReceived !== true) throw new HttpError(400, 'confirm_required', 'Confirm that the money has been received before approving.');
  const out = tx(() => {
    const p = q('SELECT * FROM payments WHERE id=?').get(m[1]); if (!p) throw new HttpError(404, 'not_found', 'Not found.');
    if (p.status !== 'pending') throw new HttpError(409, 'already_processed', 'This request has already been ' + p.status + '. No new code was generated.');
    if (q("SELECT 1 FROM payments WHERE txn_norm=? AND status='approved' AND id<>?").get(p.txn_norm, p.id)) throw new HttpError(409, 'duplicate_txn', 'This transaction ID was already used for another approved payment.');
    const licId = rid('LIC-', 10), code = String(crypto.randomInt(0, 10000)).padStart(4, '0');
    q("UPDATE payments SET status='approved', decided_by=?, decided_at=? WHERE id=? AND status='pending'").run(admin, Date.now(), p.id);
    q("INSERT INTO licenses(id,payment_id,client_id,code_hash,code_enc,status,issued_at,issued_by) VALUES(?,?,?,?,?,'issued',?,?)").run(licId, p.id, p.client_id, hashCode(licId, code), encCode(code), Date.now(), admin);
    audit(admin, 'payment.approved', 'payment', p.id, { amount: p.amount, txn: p.txn_id }); audit(admin, 'license.issued', 'license', licId, { paymentId: p.id });
    return { licenseId: licId, code };
  });
  return { ok: true, licenseId: out.licenseId, activationCode: out.code };
});
route('POST', /^\/api\/admin\/payments\/(PAY-[A-Z0-9]{10})\/reject$/, async (req, m) => {
  const admin = adminAuth(req), b = await readJson(req), reason = clean(b.reason, 300);
  if (reason.length < 3) throw new HttpError(400, 'validation', 'A rejection reason is required.');
  tx(() => {
    const p = q('SELECT * FROM payments WHERE id=?').get(m[1]); if (!p) throw new HttpError(404, 'not_found', 'Not found.');
    if (p.status !== 'pending') throw new HttpError(409, 'already_processed', 'This request has already been ' + p.status + '.');
    q("UPDATE payments SET status='rejected', decided_by=?, decided_at=?, reject_reason=? WHERE id=? AND status='pending'").run(admin, Date.now(), reason, p.id);
    audit(admin, 'payment.rejected', 'payment', p.id, { reason });
  });
  return { ok: true };
});
route('GET', /^\/api\/admin\/licenses$/, async (req, m, url) => {
  adminAuth(req); const term = clean(url.searchParams.get('q'), 60), l = '%' + term.replace(/[\\%_]/g, '\\$&') + '%', now = Date.now();
  const rows = q(`SELECT l.*, p.school, p.contact_name, p.txn_id FROM licenses l JOIN payments p ON p.id=l.payment_id ${term ? "WHERE p.school LIKE ? ESCAPE '\\' OR l.id LIKE ? ESCAPE '\\' OR p.txn_id LIKE ? ESCAPE '\\'" : ''} ORDER BY l.issued_at DESC LIMIT 200`).all(...(term ? [l, l, l] : []));
  return { ok: true, items: rows.map(r => Object.assign(licRow(r, now), { school: r.school, contactName: r.contact_name, txnId: r.txn_id })) };
});
route('POST', /^\/api\/admin\/licenses\/(LIC-[A-Z0-9]{10})\/revoke$/, async (req, m) => {
  const admin = adminAuth(req), b = await readJson(req), reason = clean(b.reason, 300);
  if (reason.length < 3) throw new HttpError(400, 'validation', 'A revocation reason is required.');
  tx(() => { const l = q('SELECT * FROM licenses WHERE id=?').get(m[1]); if (!l) throw new HttpError(404, 'not_found', 'Not found.'); if (l.status === 'revoked') throw new HttpError(409, 'already_processed', 'Already revoked.');
    q("UPDATE licenses SET status='revoked', revoked_at=?, revoked_by=?, revoke_reason=?, code_enc=NULL WHERE id=?").run(Date.now(), admin, reason, l.id); audit(admin, 'license.revoked', 'license', l.id, { reason }); });
  return { ok: true };
});
route('POST', /^\/api\/admin\/licenses\/(LIC-[A-Z0-9]{10})\/reveal-code$/, async (req, m) => {
  const admin = adminAuth(req), l = q('SELECT * FROM licenses WHERE id=?').get(m[1]);
  if (!l || l.status !== 'issued' || !l.code_enc) throw new HttpError(409, 'unavailable', 'The code is only available until the licence is activated.');
  audit(admin, 'license.code_revealed', 'license', l.id); return { ok: true, activationCode: decCode(l.code_enc) };
});
route('GET', /^\/api\/admin\/audit$/, async (req, m, url) => {
  adminAuth(req); const lim = Math.min(300, Number(url.searchParams.get('limit')) || 100), act = clean(url.searchParams.get('action'), 40);
  return { ok: true, items: (act ? q('SELECT id,ts,actor,action,entity,entity_id,detail FROM audit WHERE action=? ORDER BY id DESC LIMIT ?').all(act, lim) : q('SELECT id,ts,actor,action,entity,entity_id,detail FROM audit ORDER BY id DESC LIMIT ?').all(lim)).map(a => Object.assign(a, { detail: a.detail ? JSON.parse(a.detail) : null })) };
});

/* ---------- static admin panel ---------- */
const ADMIN_DIR = path.join(__dirname, 'admin'), MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };
function serveAdmin(req, res, pathname) {
  let rel = pathname.replace(/^\/admin\/?/, '') || 'index.html'; const file = path.resolve(ADMIN_DIR, rel);
  if (!file.startsWith(ADMIN_DIR + path.sep) || !fs.existsSync(file) || !MIME[path.extname(file)]) { res.writeHead(404); return res.end('Not found'); }
  res.writeHead(200, { 'content-type': MIME[path.extname(file)], 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'x-frame-options': 'DENY', 'referrer-policy': 'no-referrer',
    'content-security-policy': "default-src 'self'; img-src 'self' blob:; connect-src 'self'; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'" });
  res.end(fs.readFileSync(file));
}

/* ---------- server ---------- */
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x'), origin = req.headers.origin, cors = {};
  if (url.pathname.startsWith('/api/v1/') && origin && (CFG.allowedOrigins.includes('*') || CFG.allowedOrigins.includes(origin))) {   // customer API only; the admin API never sends CORS headers
    Object.assign(cors, { 'access-control-allow-origin': CFG.allowedOrigins.includes('*') ? '*' : origin, 'access-control-allow-headers': 'content-type,x-client-id,x-client-secret,x-status-token', 'access-control-allow-methods': 'GET,POST,OPTIONS', 'access-control-expose-headers': 'retry-after', 'access-control-max-age': '600', vary: 'Origin' });
  }
  try {
    if (CFG.trustProxy && req.headers['x-forwarded-proto'] === 'https') res.setHeader('strict-transport-security', 'max-age=31536000');
    if (url.pathname === '/admin' || url.pathname.startsWith('/admin/')) { if (req.method !== 'GET') throw new HttpError(405, 'method', 'Not allowed.'); return serveAdmin(req, res, url.pathname); }
    if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end(); }
    for (const r of routes) {
      if (r.method !== req.method) continue; const m = r.re.exec(url.pathname); if (!m) continue;
      const out = await r.fn(req, m, url, res); if (out === null) return; return send(res, 200, out, cors);
    }
    throw new HttpError(404, 'not_found', 'Not found.');
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.status, Object.assign({ ok: false, error: e.code, message: e.message }, e.extra || {}), Object.assign({}, cors, e.extra && e.extra.retryAfter ? { 'retry-after': String(e.extra.retryAfter) } : {}));
    console.error('[server error]', e && e.stack || e); return send(res, 500, { ok: false, error: 'server_error', message: 'Something went wrong on the server.' }, cors);
  }
});

/* ---------- CLI: create-admin ---------- */
async function createAdmin() {
  const name = clean(process.argv[3], 40).toLowerCase(); if (!/^[a-z0-9._-]{3,40}$/.test(name)) { console.error('Usage: node server.js create-admin <username>   (3-40 chars: a-z 0-9 . _ -)'); process.exit(1); }
  let pw = process.env.ADMIN_PASSWORD;
  if (!pw) { process.stdout.write('New admin password (min 10 chars, input hidden): '); pw = await new Promise(r => { let s = ''; process.stdin.setRawMode && process.stdin.setRawMode(true); process.stdin.resume(); process.stdin.setEncoding('utf8');
    process.stdin.on('data', function f(c) { for (const ch of c) { if (ch === '\r' || ch === '\n') { process.stdin.setRawMode && process.stdin.setRawMode(false); process.stdin.pause(); process.stdin.removeListener('data', f); console.log(''); return r(s); } if (ch === '\u0003') process.exit(1); if (ch === '\u007f') s = s.slice(0, -1); else s += ch; } }); }); }
  if (pw.length < 10) { console.error('Password must be at least 10 characters.'); process.exit(1); }
  q('INSERT INTO admins(username,pw_hash,created_at) VALUES(?,?,?) ON CONFLICT(username) DO UPDATE SET pw_hash=excluded.pw_hash').run(name, hashPw(pw), Date.now()); audit('cli', 'admin.created', 'admin', name);
  console.log('Administrator "' + name + '" saved.'); process.exit(0);
}
function start() {
  return server.listen(CFG.port, CFG.host, () => {
    const n = q('SELECT COUNT(*) n FROM admins').get().n;
    console.log(`OMR licence server (server2) on http://${CFG.host}:${CFG.port}  (health: /api/omr/health, admin panel: /admin)`);
    if (!n) console.log('No administrator yet. Create one:  node server2.js create-admin <username>');
    console.log('Public verification key (put it in frontend/license-config.js):\n' + JSON.stringify(S.publicJwk));
    if (!CFG.trustProxy) console.log('NOTE: run behind an HTTPS reverse proxy in production and set TRUST_PROXY=1.');
    if (CFG.allowedOrigins.includes('*')) console.log('WARNING: ALLOWED_ORIGINS is "*". Set it to your hosted frontend origin(s) in production.');
  });
}
if (require.main === module) { if (process.argv[2] === 'create-admin') createAdmin(); else start(); }
module.exports = { server, CFG, start, createAdmin };
