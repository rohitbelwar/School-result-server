# eGyan Classes — OMR Auto-Checker · Licence server

Payment requests · admin approval · four-digit activation · free trial · annual licence.
Zero npm dependencies: **Node ≥ 22.5** (uses built-in `node:sqlite`, `node:crypto`, `node:http`). One process, one SQLite file.

## 1. Why a server is needed (read this first)

The OMR app is a local HTML/JS app. **Nothing that lives only in the browser can prove a payment, protect an activation code, or stop someone from resetting a counter** — the user owns the browser, its storage and its JavaScript.
So the **server is the only authority** for: payment approval, activation codes, the 20-copy trial counter, and licence validity/expiry. The app only *asks* the server, verifies the server's **Ed25519 signature** on the answer, and caches that signed answer for up to **48 hours** of offline use.

| | Needs internet? | Notes |
|---|---|---|
| Open saved results, records, PDFs, CSV/JSON export, backups | **No** | Never locked — not by trial end, expiry or revocation. |
| Scan a NEW sheet with a valid cached signed answer (≤ 48 h old) | No | The cached answer is re-verified on every start. |
| First launch of a new installation (registration), activation, payment, renewal, status | **Yes** | |
| Scan a NEW sheet when the cached answer is older than 48 h | Yes (once) | The app asks the user to connect and re-verify. |

### Honest limitations (not hidden)
* A person who edits **their own copy** of `license_3_2_2.js` / `app_3_2_2.js` can remove the gate. No pure client-side scheme can prevent that. What *is* enforced server-side: nobody can obtain a valid signed licence, a valid activation code, or a re-approved payment without the administrator.
* A trial belongs to a **browser installation** (random ID + secret stored in `localStorage`). Clearing all site data or using another browser creates a *new* installation with a *new* 20-copy trial. Changing the school name, class, subject etc. does **not** reset it. Mitigations included: registrations are rate-limited per IP (30/day); the admin sees every installation's school name. A stronger identity (e.g. login accounts) would need a separate decision.
* Trial usage is reported shortly after each scan. While offline, the app lets a trial school scan only while `server remaining − unsent scans > 0`; the unsent scans are uploaded when the connection returns.
* Four-digit codes have only 10 000 values. They are safe here only because activation additionally requires **the customer's own installation credentials + the payment request ID**, and is locked after 5 wrong attempts (15 min, doubling up to 24 h), plus per-installation and per-IP rate limits. A code alone is never enough, and a wrong request/code pair always returns the same generic message.
* Rate limits are in-memory (per process). Put the server behind a reverse proxy/WAF if you expect abuse.
* The server cannot see your bank. **The administrator must check the real money in the bank/UPI app before pressing "Approve".** A typed transaction ID or screenshot proves nothing.

## 2. Install & run

```bash
cd server
node server.js create-admin owner         # prompts for a password (min 10 chars, hidden). Or: ADMIN_PASSWORD=... node server.js create-admin owner
PORT=8787 node server.js                  # prints the PUBLIC verification key
```
Open `http://localhost:8787/admin` and sign in. First start creates `data/` (database, screenshots, **`secrets.json`**).

**Back up `data/` — especially `data/secrets.json`.** It holds the private signing key and the code-encryption key. If it is lost, all issued tokens/codes become unverifiable; if it leaks, anyone can forge licences. Never commit it, never copy it to the browser.

### Production (HTTPS is mandatory)
Run the server behind a TLS reverse proxy and set `TRUST_PROXY=1`. Caddy example:
```
license.yourdomain.in {
  reverse_proxy 127.0.0.1:8787
}
```
(systemd: `ExecStart=/usr/bin/node /opt/egyan/server/server.js`, `Environment=PORT=8787 TRUST_PROXY=1 ALLOWED_ORIGINS=*`, `Restart=always`.)
Optionally restrict `/admin` further (IP allow-list or VPN) at the proxy.

### Environment variables
| Variable | Default | Meaning |
|---|---|---|
| `PORT` / `HOST` | 8787 / 0.0.0.0 | Listen address |
| `DATA_DIR` | `./data` | DB, screenshots, secrets |
| `ALLOWED_ORIGINS` | `*` | CORS for the **customer** API only (the app runs from `file://`, which sends `Origin: null`). The admin API never sends CORS headers. |
| `TRUST_PROXY` | off | `1` = trust `X-Forwarded-For/Proto` (needed for correct per-IP limits behind a proxy) |
| `ADMIN_PASSWORD` | – | Only for non-interactive `create-admin` |
| `SECRETS_FILE`, `DB_FILE` | in `DATA_DIR` | Override locations |

## 3. Connect the app
Edit **`license-config.js`** (the only file to edit):
```js
api: "https://license.yourdomain.in",
publicKey: { /* paste the JSON printed by the server (or GET /api/v1/public-key) */ },
```
`api: ""` (the default) = **licensing OFF**: the app behaves exactly as before and nothing is enforced.
The payment details (UPI ID, name on the QR, WhatsApp, price, QR image path) are in the same file.

> ⚠ **Check the UPI ID before going live.** The supplied QR image decodes to `upi://pay?pa=6200727245@ibl&pn=Mr ROHIT KUMAR…`, whereas the owner supplied the UPI ID as `6200727245@ybl`. Both are PhonePe handles, but only the owner can say which is correct. The app shows the ID configured in `license-config.js` (`upiId`) exactly; the QR image is shown untouched. Make them consistent (customers pay the QR's `@ibl` address when scanning).

## 4. Customer flow
1. First launch → app registers an installation (`clientId` + secret) → **20 free copies**.
2. Each *successfully evaluated* sheet = 1 copy (`processOMRImage` → after the scan id is created; idempotent per scan id). Failed scans, camera previews, opening/re-saving results use nothing. Batch/auto-scan count each student once.
3. At 20 → new evaluations are blocked and the **annual licence screen** opens (₹500/year).
4. **Pay ₹500 via UPI** → QR + UPI ID → customer pays → **submits** school, contact, UPI reference ID, amount, date/time (+ optional screenshot) → request ID `PAY-XXXXXXXXXX`, status **Pending Admin Approval**.
5. Admin verifies the real payment → **Approve** → server creates the licence + random 4-digit code.
6. Customer taps **Check status** (needs the request's secret status token, stored in their browser) → sees the code → **Activate** → licence runs **365 days from activation**; renewal stacks after any unexpired time.
7. Expired/revoked → new scans blocked; all saved data stays available.

## 5. API reference

All responses are JSON: `{ "ok": true, … }` or `{ "ok": false, "error": "<code>", "message": "<human text>" }`. Errors are generic where needed (e.g. activation never says *why* it failed).

### Customer API (`/api/v1`, headers `x-client-id`, `x-client-secret` unless noted)
| Method & path | Body → result |
|---|---|
| `GET /api/v1/public-key` (no auth) | → `{publicKey (JWK), price, trialAllowed}` |
| `POST /api/v1/client/register` (no auth) | `{clientId (uuid), secret (≥32 chars), school?}` → `{entitlement}` (idempotent; a different secret for an existing id → 401) |
| `GET /api/v1/entitlement` | → `{entitlement}` |
| `POST /api/v1/usage` | `{ids:[scanId…≤100], school?}` → `{entitlement}`; idempotent per id; not counted against the trial while a licence is active |
| `POST /api/v1/payments` | `{school, contactName, contactPhone?, txnId (8-35 A-Z0-9), amount (=500), paidAt (ms), screenshot? (data URL png/jpeg/webp ≤450 KB)}` → `{requestId, statusToken, status:"pending"}`; `409 duplicate_txn`, `409 already_pending` |
| `GET /api/v1/payments/:requestId` + header `x-status-token` | → `{status, rejectReason?, license?:{status,activatedAt,expiresAt}, activationCode? (only while approved & not yet activated)}` |
| `POST /api/v1/license/activate` | `{requestId, code}` → `{entitlement}`; `400 invalid_activation`, `429 locked {retryAfter}`, `409 already_active` |

`entitlement` = `{state: trial|trial_completed|active|expired|revoked, trialAllowed, trialUsed, trialRemaining, activatedAt, expiresAt, serverTime, latestRequest, token}`.
`token` = `base64url(payload).base64url(Ed25519 signature)`; payload contains `cid, state, trial*, expiresAt, iat, exp (= iat+48h)`. The app verifies it with the public key; a modified token fails.

### Admin API (`/api/admin`, `Authorization: Bearer <session token>`; no CORS)
| Method & path | Purpose |
|---|---|
| `POST /login` `{username,password}` → `{token}` | scrypt-hashed passwords; 5 failures/15 min lock per user+IP; no user enumeration; 8 h sessions |
| `POST /logout`, `GET /me`, `POST /password` | session management (changing the password ends all sessions) |
| `GET /summary` | the 8 dashboard numbers |
| `GET /payments?status=&q=&limit=&offset=` | list/filter/search (school, request ID, txn ID, contact) |
| `GET /payments/:id`, `GET /payments/:id/screenshot` | details + history; screenshot only for admins |
| `POST /payments/:id/approve` `{confirmReceived:true}` | **atomic** (`BEGIN IMMEDIATE`): checks pending + txn uniqueness, marks approved, creates licence + code, audits. Repeat/parallel calls → `409 already_processed` and no second code |
| `POST /payments/:id/reject` `{reason}` | reason required; no licence/code |
| `GET /licenses?q=`, `POST /licenses/:id/revoke` `{reason}` | revocation (audited; saved customer data untouched) |
| `POST /licenses/:id/reveal-code` | only until activation; audited |
| `GET /audit?action=&limit=` | append-only audit log (DB triggers forbid UPDATE/DELETE) |

## 6. Data model (SQLite)
`clients` (identity, secret **hash**) · `usage` (client, scan id; PK prevents double counting) · `payments` (partial UNIQUE index on the normalised transaction ID for pending/approved; at most one pending per client) · `licenses` (UNIQUE `payment_id`; code stored as **HMAC** for checking and **AES-256-GCM ciphertext** for delivery until activation, then wiped) · `admins` · `sessions` (hashed tokens) · `audit`.
Payment records are completely separate from OMR results (which never leave the customer's device).

## 7. Tests
```bash
cd server && node --test test/api.test.mjs     # 18 tests: trial counting, forged tokens, auth, lockouts, races, expiry, renewal, revoke, CORS, audit immutability …
```
Browser end-to-end tests (customer app + admin panel + real server) were run with Playwright; see the project hand-over notes.
