import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { mkdtempSync, rmSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { tmpdir } from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const ENTRY = path.join(ROOT, 'server2.js');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const freePort = () => 20000 + Math.floor(Math.random() * 20000);
const dirs = [], procs = [];
after(() => { procs.forEach(p => p.kill()); dirs.forEach(d => rmSync(d, { recursive: true, force: true })); });

async function startOmr(extraEnv = {}) {
  const dir = mkdtempSync(path.join(tmpdir(), 'omr2-')); dirs.push(dir);
  const port = freePort();
  const p = spawn(process.execPath, [ENTRY], { env: { ...process.env, HOST: '127.0.0.1', DATA_DIR: dir, PORT_OMR: String(port), OMR_STANDALONE: '1', ...extraEnv }, stdio: 'ignore' });
  procs.push(p);
  for (let i = 0; i < 60; i++) { try { if ((await fetch(`http://127.0.0.1:${port}/healthz`)).ok) return { p, port }; } catch (_) {} await sleep(100); }
  throw new Error('server2 did not start');
}

test('S1. GET /api/omr/health returns the documented body', async () => {
  const { port } = await startOmr();
  const r = await fetch(`http://127.0.0.1:${port}/api/omr/health`);
  assert.equal(r.status, 200);
  assert.deepEqual(await r.json(), { success: true, service: 'OMR Auto-Checker License API' });
});

test('S2. server2 listens on PORT_OMR and ignores server1\'s PORT', async () => {
  const other = freePort() + 1;
  const { port } = await startOmr({ PORT: String(other) });
  assert.equal((await fetch(`http://127.0.0.1:${port}/api/omr/health`)).status, 200);
  await assert.rejects(fetch(`http://127.0.0.1:${other}/api/omr/health`), 'nothing may listen on PORT');
});

test('S3. server2 refuses to start when PORT_OMR equals PORT', () => {
  const dir = mkdtempSync(path.join(tmpdir(), 'omr2-')); dirs.push(dir);
  const r = spawnSync(process.execPath, [ENTRY], { env: { ...process.env, DATA_DIR: dir, PORT: '4555', PORT_OMR: '4555', OMR_STANDALONE: '1' }, encoding: 'utf8', timeout: 10000 });
  assert.equal(r.status, 1); assert.match(r.stderr, /PORT_OMR/);
});

test('S4. licence/admin routes are not mounted under school routes (isolation)', async () => {
  const { port } = await startOmr();
  for (const u of ['/get-students', '/teacher-login', '/api/results', '/api/subjects']) assert.equal((await fetch(`http://127.0.0.1:${port}${u}`)).status, 404, u);
});

test('S5. KNOWN LIMITATION: trial is device-based — a brand-new device identity gets a fresh 20-copy trial', async () => {
  const { port } = await startOmr();
  const reg = async () => (await (await fetch(`http://127.0.0.1:${port}/api/v1/client/register`, { method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ clientId: crypto.randomUUID(), secret: crypto.randomBytes(32).toString('hex'), school: 'S' }) })).json()).entitlement;
  const a = await reg(), b = await reg();
  assert.equal(a.trialRemaining, 20); assert.equal(b.trialRemaining, 20); // documents accepted risk (owner chose device-based trial)
});

test('S6. license-config.js: local uses server1 port; production defaults to same origin', () => {
  const src = readFileSync(path.join(ROOT, 'OMR-AutoChecker/frontend/license-config.js'), 'utf8');
  const run = (loc) => { const w = { location: loc }; vm.runInNewContext(src, { window: w, location: loc }); return w.EGYAN_LICENSE; };
  assert.equal(run({ protocol: 'http:', hostname: 'localhost' }).api, 'http://localhost:3000');
  assert.equal(run({ protocol: 'file:', hostname: '' }).api, 'http://localhost:3000');
  const prod = run({ protocol: 'https:', hostname: 'omr.example.in', origin: 'https://omr.example.in' });
  assert.equal(prod.api, 'https://omr.example.in'); assert.equal(prod.upiId, '6200727245@ybl'); assert.equal(prod.price, 500);
});

const req = createRequire(path.join(ROOT, 'package.json'));
let school1Missing = null; try { req.resolve('express'); req.resolve('mongoose'); req.resolve('bcrypt'); req.resolve('jsonwebtoken'); req.resolve('cors'); } catch (e) { school1Missing = e.message.split('\n')[0]; }
test('S7. server1.js and server2.js run simultaneously; stopping one leaves the other up',
  { skip: school1Missing ? `real server1.js cannot start here — dependency not installed (${school1Missing})` : false }, async () => {
  const p1port = freePort() + 2;
  const s1 = spawn(process.execPath, [path.join(ROOT, 'server1.js')], { cwd: ROOT, env: { ...process.env, PORT: String(p1port), JWT_SECRET: 'test', MONGODB_URI: 'mongodb://127.0.0.1:1/none' }, stdio: 'ignore' }); procs.push(s1);
  const { p: s2, port } = await startOmr();
  let up1 = false; for (let i = 0; i < 50 && !up1; i++) { try { await fetch(`http://127.0.0.1:${p1port}/api/notices`); up1 = true; } catch (_) { await sleep(100); } }
  assert.ok(up1, 'server1 reachable'); assert.equal((await fetch(`http://127.0.0.1:${port}/api/omr/health`)).status, 200);
  s1.kill(); await sleep(300); assert.equal((await fetch(`http://127.0.0.1:${port}/api/omr/health`)).status, 200, 'server2 survives server1 stopping');
  s2.kill();
});
