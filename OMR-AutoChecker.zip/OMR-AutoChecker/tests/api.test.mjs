import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
const ENTRY = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'server2.js'); // the real entry point
import { DatabaseSync } from 'node:sqlite';

const DIR = mkdtempSync(path.join(tmpdir(), 'egyan-'));
const PORT = 20000 + Math.floor(Math.random() * 20000), BASE = `http://127.0.0.1:${PORT}`;
const env = { ...process.env, RATE_MULT: '1000', PORT_OMR: String(PORT), HOST: '127.0.0.1', DATA_DIR: DIR, OMR_STANDALONE: '1', ADMIN_PASSWORD: 'correct-horse-battery' };
let proc, pub, adminToken;
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function api(method, url, { body, client, headers = {}, admin } = {}) {
  const h = { ...headers }; if (body) h['content-type'] = 'application/json';
  if (client) { h['x-client-id'] = client.id; h['x-client-secret'] = client.secret; if (client.st) h['x-status-token'] = client.st; }
  if (admin) h.authorization = 'Bearer ' + (admin === true ? adminToken : admin);
  const r = await fetch(BASE + url, { method, headers: h, body: body ? JSON.stringify(body) : undefined });
  const ct = r.headers.get('content-type') || ''; return { status: r.status, headers: r.headers, json: ct.includes('json') ? await r.json() : null, buf: ct.includes('image') ? Buffer.from(await r.arrayBuffer()) : null };
}
const newClient = async () => { const c = { id: crypto.randomUUID(), secret: crypto.randomBytes(32).toString('hex') }; const r = await api('POST', '/api/v1/client/register', { body: { clientId: c.id, secret: c.secret, school: 'Test School' } }); assert.equal(r.status, 200); c.ent = r.json.entitlement; return c; };
let txnN = 100000000000;
const pay = (c, over = {}) => api('POST', '/api/v1/payments', { client: c, body: { school: 'Sunrise Public School', contactName: 'A Teacher', contactPhone: '9876543210', txnId: String(++txnN), amount: 500, paidAt: Date.now() - 60000, ...over } });
const verifyToken = (tok) => { const [b, s] = tok.split('.'); return crypto.verify(null, Buffer.from(b), crypto.createPublicKey({ key: pub, format: 'jwk' }), Buffer.from(s, 'base64url')); };
const dbq = () => new DatabaseSync(path.join(DIR, 'egyan-license.db'));
const tinyPng = 'data:image/png;base64,' + Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000001e221bc330000000049454e44ae426082', 'hex').toString('base64');

before(async () => {
  const r = spawnSync(process.execPath, [ENTRY, 'create-admin', 'Owner'], { env, encoding: 'utf8' }); assert.match(r.stdout, /saved/);
  proc = spawn(process.execPath, [ENTRY], { env, stdio: 'ignore' });
  for (let i = 0; i < 50; i++) { try { if ((await fetch(BASE + '/healthz')).ok) break; } catch (_) {} await sleep(100); }
  pub = (await api('GET', '/api/v1/public-key')).json.publicKey;
  const l = await api('POST', '/api/admin/login', { body: { username: 'owner', password: 'correct-horse-battery' } }); adminToken = l.json.token;
});
after(() => { proc && proc.kill(); rmSync(DIR, { recursive: true, force: true }); });

test('1. new client gets 20 free evaluations and a server-signed token', async () => {
  const c = await newClient(); assert.equal(c.ent.state, 'trial'); assert.equal(c.ent.trialRemaining, 20); assert.equal(c.ent.trialAllowed, 20); assert.ok(verifyToken(c.ent.token));
  const forged = c.ent.token.split('.'); const p = JSON.parse(Buffer.from(forged[0], 'base64url')); p.state = 'active'; p.expiresAt = Date.now() + 1e10;
  assert.equal(verifyToken(Buffer.from(JSON.stringify(p)).toString('base64url') + '.' + forged[1]), false, 'a forged token must not verify');
});
test('2. trial counting is idempotent, survives re-registration and blocks at 20', async () => {
  const c = await newClient(); const ids = Array.from({ length: 20 }, (_, i) => 'scan-' + i);
  let r = await api('POST', '/api/v1/usage', { client: c, body: { ids: ids.slice(0, 5) } }); assert.equal(r.json.entitlement.trialRemaining, 15);
  r = await api('POST', '/api/v1/usage', { client: c, body: { ids: ids.slice(0, 5) } }); assert.equal(r.json.entitlement.trialRemaining, 15, 're-sending the same results must not double-count');
  r = await api('POST', '/api/v1/client/register', { body: { clientId: c.id, secret: c.secret, school: 'Renamed School' } }); assert.equal(r.json.entitlement.trialRemaining, 15, 'renaming / re-registering must not reset the trial');
  r = await api('POST', '/api/v1/usage', { client: c, body: { ids } }); assert.equal(r.json.entitlement.trialRemaining, 0); assert.equal(r.json.entitlement.state, 'trial_completed');
  r = await api('GET', '/api/v1/entitlement', { client: c }); assert.equal(r.json.entitlement.trialUsed, 20);
  const bad = await api('POST', '/api/v1/client/register', { body: { clientId: c.id, secret: crypto.randomBytes(32).toString('hex') } }); assert.equal(bad.status, 401, 'another secret cannot take over an identity');
});
test('3. unauthenticated / wrong-secret clients are rejected', async () => {
  const c = await newClient(); assert.equal((await api('GET', '/api/v1/entitlement')).status, 401);
  assert.equal((await api('GET', '/api/v1/entitlement', { client: { id: c.id, secret: 'x'.repeat(64) } })).status, 401);
});
test('4. payment validation: txn id required, exact amount, phone format', async () => {
  const c = await newClient();
  for (const [over, field] of [[{ txnId: '' }, 'txnId'], [{ txnId: 'abc' }, 'txnId'], [{ amount: 499 }, 'amount'], [{ amount: 5000 }, 'amount'], [{ school: ' ' }, 'school'], [{ contactName: '' }, 'contactName'], [{ contactPhone: 'abc' }, 'contactPhone'], [{ paidAt: Date.now() + 9e8 }, 'paidAt'], [{ screenshot: 'data:text/html;base64,PGI+' }, 'screenshot']]) {
    const r = await pay(c, over); assert.equal(r.status, 400, JSON.stringify(over)); assert.equal(r.json.field, field);
  }
});
test('5. pending request: no code, no licence, cannot be activated; one pending at a time; txn id cannot be reused', async () => {
  const c = await newClient(), c2 = await newClient(); const t = String(++txnN);
  const r = await pay(c, { txnId: t }); assert.equal(r.status, 200); assert.match(r.json.requestId, /^PAY-[A-Z0-9]{10}$/); c.st = r.json.statusToken;
  const s = await api('GET', '/api/v1/payments/' + r.json.requestId, { client: c }); assert.equal(s.json.status, 'pending'); assert.equal(s.json.activationCode, undefined); assert.equal(s.json.license, null);
  assert.equal((await api('GET', '/api/v1/entitlement', { client: c })).json.entitlement.state, 'trial');
  const a = await api('POST', '/api/v1/license/activate', { client: c, body: { requestId: r.json.requestId, code: '1234' } }); assert.equal(a.status, 400); assert.equal(a.json.error, 'invalid_activation');
  assert.equal((await pay(c)).status, 409, 'second pending request from the same client');
  const dup = await pay(c2, { txnId: t.toLowerCase() }); assert.equal(dup.status, 409); assert.equal(dup.json.error, 'duplicate_txn');
  const other = await api('GET', '/api/v1/payments/' + r.json.requestId, { client: { ...c2, st: c.st } }); assert.equal(other.status, 404, "another client cannot read someone else's request, even with its token");
  const noTok = await api('GET', '/api/v1/payments/' + r.json.requestId, { client: { id: c.id, secret: c.secret } }); assert.equal(noTok.status, 404, 'status needs the secret status token');
});
test('6. admin API is protected by backend authentication', async () => {
  for (const [m, u] of [['GET', '/api/admin/summary'], ['GET', '/api/admin/payments'], ['GET', '/api/admin/licenses'], ['GET', '/api/admin/audit'], ['POST', '/api/admin/payments/PAY-AAAAAAAAAA/approve'], ['POST', '/api/admin/licenses/LIC-AAAAAAAAAA/revoke']]) {
    assert.equal((await api(m, u, { body: m === 'POST' ? { confirmReceived: true } : undefined })).status, 401, u);
    assert.equal((await api(m, u, { admin: 'A'.repeat(43), body: m === 'POST' ? {} : undefined })).status, 401, u + ' with a made-up token');
  }
  const c = await newClient(); assert.equal((await api('GET', '/api/admin/summary', { headers: { 'x-client-id': c.id, 'x-client-secret': c.secret } })).status, 401, 'a customer credential is not an admin credential');
  const w = await api('POST', '/api/admin/login', { body: { username: 'owner', password: 'wrong-password-1' } }); assert.equal(w.status, 401);
  const o = await api('POST', '/api/admin/login', { body: { username: 'nobody', password: 'wrong-password-1' } }); assert.equal(o.json.message, w.json.message, 'no user enumeration');
});
test('7. admin login lockout after 5 failures', async () => {
  let last; for (let i = 0; i < 6; i++) last = await api('POST', '/api/admin/login', { body: { username: 'lockme', password: 'bad-password-' + i } });
  assert.equal(last.status, 429);
  const ok = await api('POST', '/api/admin/login', { body: { username: 'owner', password: 'correct-horse-battery' } }); assert.equal(ok.status, 200, 'other accounts are unaffected');
});
test('8. approve → 4-digit code → customer retrieves it → activates; full lifecycle', async () => {
  const c = await newClient(); const r = await pay(c, { screenshot: tinyPng }); assert.equal(r.status, 200); c.st = r.json.statusToken; const id = r.json.requestId;
  const sum0 = (await api('GET', '/api/admin/summary', { admin: true })).json;
  const shot = await api('GET', `/api/admin/payments/${id}/screenshot`, { admin: true }); assert.equal(shot.status, 200); assert.equal(shot.headers.get('content-type'), 'image/png'); assert.ok(shot.buf.length > 20);
  assert.equal((await api('GET', `/api/admin/payments/${id}/screenshot`)).status, 401, 'screenshot is admin-only');
  let ap = await api('POST', `/api/admin/payments/${id}/approve`, { admin: true, body: {} }); assert.equal(ap.status, 400, 'approval needs the receipt confirmation flag');
  ap = await api('POST', `/api/admin/payments/${id}/approve`, { admin: true, body: { confirmReceived: true } }); assert.equal(ap.status, 200); assert.match(ap.json.activationCode, /^\d{4}$/); assert.match(ap.json.licenseId, /^LIC-/);
  const st = await api('GET', '/api/v1/payments/' + id, { client: c }); assert.equal(st.json.status, 'approved'); assert.equal(st.json.activationCode, ap.json.activationCode); assert.equal(st.json.license.status, 'issued');
  assert.equal((await api('GET', '/api/v1/entitlement', { client: c })).json.entitlement.state, 'trial', 'approved but not activated is not yet a licence');
  const wrong = ap.json.activationCode === '0000' ? '0001' : '0000'; const bad = await api('POST', '/api/v1/license/activate', { client: c, body: { requestId: id, code: wrong } }); assert.equal(bad.status, 400);
  const t0 = Date.now(); const act = await api('POST', '/api/v1/license/activate', { client: c, body: { requestId: id, code: ap.json.activationCode } }); assert.equal(act.status, 200);
  const e = act.json.entitlement; assert.equal(e.state, 'active'); assert.ok(verifyToken(e.token)); assert.ok(Math.abs(e.expiresAt - (t0 + 365 * 86400000)) < 60000, 'expires 365 days after activation');
  const st2 = await api('GET', '/api/v1/payments/' + id, { client: c }); assert.equal(st2.json.activationCode, undefined, 'the code is no longer retrievable once used');
  assert.equal((await api('POST', '/api/v1/license/activate', { client: c, body: { requestId: id, code: ap.json.activationCode } })).status, 409, 'cannot activate twice');
  const sum1 = (await api('GET', '/api/admin/summary', { admin: true })).json;
  assert.equal(sum1.approved, sum0.approved + 1); assert.equal(sum1.activeLicenses, sum0.activeLicenses + 1); assert.equal(sum1.verifiedRevenue, sum0.verifiedRevenue + 500); assert.equal(sum1.pending, sum0.pending - 1);
  const u = await api('POST', '/api/v1/usage', { client: c, body: { ids: ['x1', 'x2'] } }); assert.equal(u.json.entitlement.trialUsed, 0, 'scans under an active licence do not use the trial'); assert.equal(u.json.entitlement.state, 'active');
});
test('9. duplicate / concurrent approval creates exactly one licence', async () => {
  const c = await newClient(); const r = await pay(c); const id = r.json.requestId;
  const res = await Promise.all([1, 2, 3, 4].map(() => api('POST', `/api/admin/payments/${id}/approve`, { admin: true, body: { confirmReceived: true } })));
  assert.equal(res.filter(x => x.status === 200).length, 1, JSON.stringify(res.map(x => x.status))); assert.equal(res.filter(x => x.status === 409).length, 3);
  assert.equal(dbq().prepare('SELECT COUNT(*) n FROM licenses WHERE payment_id=?').get(id).n, 1);
  const again = await api('POST', `/api/admin/payments/${id}/approve`, { admin: true, body: { confirmReceived: true } }); assert.equal(again.json.error, 'already_processed');
});
test('10. four-digit code: attempt limit, lockout, other schools cannot use it, no code hint', async () => {
  const c = await newClient(), thief = await newClient(); const r = await pay(c); const id = r.json.requestId; c.st = r.json.statusToken;
  const ap = (await api('POST', `/api/admin/payments/${id}/approve`, { admin: true, body: { confirmReceived: true } })).json; const good = ap.activationCode;
  const ta = await api('POST', '/api/v1/license/activate', { client: thief, body: { requestId: id, code: good } }); assert.equal(ta.status, 400); assert.equal(ta.json.error, 'invalid_activation', "another school cannot activate this request, even with the right code");
  const wrongCode = (n) => String((Number(good) + n) % 10000).padStart(4, '0'); let last;
  for (let i = 1; i <= 5; i++) last = await api('POST', '/api/v1/license/activate', { client: c, body: { requestId: id, code: wrongCode(i) } });
  assert.equal(last.status, 429); assert.equal(last.json.error, 'locked'); assert.ok(last.json.retryAfter > 800);
  const during = await api('POST', '/api/v1/license/activate', { client: c, body: { requestId: id, code: good } }); assert.equal(during.status, 429, 'even the right code is refused while locked');
  assert.equal((await api('POST', '/api/v1/license/activate', { client: c, body: { requestId: id, code: 'abcd' } })).status, 400);
  const row = dbq().prepare('SELECT code_hash FROM licenses WHERE payment_id=?').get(id); assert.ok(!row.code_hash.includes(good) && row.code_hash.length === 64, 'stored as an HMAC, not plain text');
  assert.equal(dbq().prepare("SELECT COUNT(*) n FROM licenses WHERE code_enc LIKE ?").get('%' + good + '%').n, 0, 'the delivery copy is encrypted at rest');
});
test('11. leading-zero codes are generated (statistical check over many approvals)', async () => {
  const seen = new Set(); let zero = 0;
  for (let i = 0; i < 40; i++) { const c = await newClient(), r = await pay(c); const ap = (await api('POST', `/api/admin/payments/${r.json.requestId}/approve`, { admin: true, body: { confirmReceived: true } })).json; assert.match(ap.activationCode, /^\d{4}$/); seen.add(ap.activationCode); if (ap.activationCode.startsWith('0')) zero++; }
  assert.ok(seen.size > 30, 'codes are random, not a constant'); console.log('   codes starting with 0 in 40 draws:', zero);
});
test('12. reject: reason required, no licence/code, customer may submit again, txn can be corrected', async () => {
  const c = await newClient(); const t = String(++txnN); const r = await pay(c, { txnId: t }); const id = r.json.requestId; c.st = r.json.statusToken;
  assert.equal((await api('POST', `/api/admin/payments/${id}/reject`, { admin: true, body: { reason: '' } })).status, 400);
  assert.equal((await api('POST', `/api/admin/payments/${id}/reject`, { admin: true, body: { reason: 'Amount not received' } })).status, 200);
  const s = await api('GET', '/api/v1/payments/' + id, { client: c }); assert.equal(s.json.status, 'rejected'); assert.equal(s.json.rejectReason, 'Amount not received'); assert.equal(s.json.activationCode, undefined); assert.equal(s.json.license, null);
  assert.equal(dbq().prepare('SELECT COUNT(*) n FROM licenses WHERE payment_id=?').get(id).n, 0);
  assert.equal((await api('POST', `/api/admin/payments/${id}/approve`, { admin: true, body: { confirmReceived: true } })).status, 409, 'a rejected request cannot be approved later');
  assert.equal((await pay(c)).status, 200, 'a new request is allowed after rejection');
});
test('13. admin list: filters, search, details, audit history', async () => {
  const c = await newClient(); const t = 'UTR' + (++txnN); const r = await pay(c, { txnId: t, school: 'Zebra Findable School' }); const id = r.json.requestId;
  let l = await api('GET', '/api/admin/payments?status=pending&q=Zebra', { admin: true }); assert.ok(l.json.items.some(x => x.id === id));
  l = await api('GET', '/api/admin/payments?q=' + t, { admin: true }); assert.equal(l.json.items.length, 1); l = await api('GET', '/api/admin/payments?q=' + id, { admin: true }); assert.equal(l.json.items[0].id, id);
  l = await api('GET', "/api/admin/payments?q=%25%27%3B--", { admin: true }); assert.equal(l.status, 200, 'search is injection-safe');
  assert.equal((await api('GET', '/api/admin/payments?status=approved&q=Zebra', { admin: true })).json.items.length, 0);
  const d = await api('GET', '/api/admin/payments/' + id, { admin: true }); assert.equal(d.json.payment.txnId, t); assert.ok(d.json.history.some(h => h.action === 'payment.submitted'));
  assert.equal(d.json.payment.status_token_hash, undefined, 'secrets are never returned to the admin UI');
  const au = await api('GET', '/api/admin/audit?action=admin.login', { admin: true }); assert.ok(au.json.items.length >= 1 && au.json.items.every(a => a.action === 'admin.login'));
  assert.throws(() => dbq().exec("UPDATE audit SET action='x'"), /append-only/); assert.throws(() => dbq().exec('DELETE FROM audit'), /append-only/);
});
test('14. expiry: expired licence stops being active; renewal extends; revoke works and is audited', async () => {
  const c = await newClient(); let r = await pay(c); c.st = r.json.statusToken; let id = r.json.requestId;
  let ap = (await api('POST', `/api/admin/payments/${id}/approve`, { admin: true, body: { confirmReceived: true } })).json;
  const act = await api('POST', '/api/v1/license/activate', { client: c, body: { requestId: id, code: ap.activationCode } }); const firstExpiry = act.json.entitlement.expiresAt;
  const sumA = (await api('GET', '/api/admin/summary', { admin: true })).json;
  dbq().prepare('UPDATE licenses SET expires_at=? WHERE id=?').run(Date.now() - 1000, ap.licenseId);
  let e = (await api('GET', '/api/v1/entitlement', { client: c })).json.entitlement; assert.equal(e.state, 'expired'); assert.equal(e.licenseStatus, 'expired'); assert.ok(verifyToken(e.token));
  const sumB = (await api('GET', '/api/admin/summary', { admin: true })).json; assert.equal(sumB.expiredLicenses, sumA.expiredLicenses + 1); assert.equal(sumB.activeLicenses, sumA.activeLicenses - 1);
  const u = await api('POST', '/api/v1/usage', { client: c, body: { ids: ['after-expiry'] } }); assert.equal(u.json.entitlement.state, 'expired', 'using the app after expiry does not bring back the trial');
  r = await pay(c); c.st = r.json.statusToken; id = r.json.requestId; const det = await api('GET', '/api/admin/payments/' + id, { admin: true }); assert.equal(det.json.payment.kind, 'renewal');
  ap = (await api('POST', `/api/admin/payments/${id}/approve`, { admin: true, body: { confirmReceived: true } })).json;
  const act2 = await api('POST', '/api/v1/license/activate', { client: c, body: { requestId: id, code: ap.activationCode } }); e = act2.json.entitlement; assert.equal(e.state, 'active'); assert.ok(e.expiresAt > Date.now() + 364 * 86400000);
  const rv = await api('POST', `/api/admin/licenses/${ap.licenseId}/revoke`, { admin: true, body: { reason: 'Chargeback' } }); assert.equal(rv.status, 200);
  e = (await api('GET', '/api/v1/entitlement', { client: c })).json.entitlement; assert.equal(e.state, 'revoked');
  assert.equal((await api('POST', `/api/admin/licenses/${ap.licenseId}/revoke`, { admin: true, body: { reason: 'again' } })).status, 409);
  assert.equal((await api('POST', `/api/admin/licenses/${ap.licenseId}/revoke`, { admin: true, body: { reason: '' } })).status, 400);
  const hist = (await api('GET', '/api/admin/payments/' + id, { admin: true })).json.history.map(h => h.action); assert.ok(hist.includes('license.revoked') && hist.includes('payment.approved') && hist.includes('license.activated'));
});
test('15. admin can reveal an un-activated code (audited) but never an activated one', async () => {
  const c = await newClient(); const r = await pay(c); const ap = (await api('POST', `/api/admin/payments/${r.json.requestId}/approve`, { admin: true, body: { confirmReceived: true } })).json;
  assert.equal((await api('POST', `/api/admin/licenses/${ap.licenseId}/reveal-code`)).status, 401);
  const rv = await api('POST', `/api/admin/licenses/${ap.licenseId}/reveal-code`, { admin: true }); assert.equal(rv.json.activationCode, ap.activationCode);
  c.st = r.json.statusToken; await api('POST', '/api/v1/license/activate', { client: c, body: { requestId: r.json.requestId, code: ap.activationCode } });
  assert.equal((await api('POST', `/api/admin/licenses/${ap.licenseId}/reveal-code`, { admin: true })).status, 409);
  const au = (await api('GET', '/api/admin/audit?limit=300', { admin: true })).json.items; assert.ok(au.some(a => a.action === 'license.code_revealed' && a.entity_id === ap.licenseId));
});
test('16. CORS: customer API is callable from file:// pages; admin API sends no CORS headers; admin UI is served with a strict CSP', async () => {
  const pre = await fetch(BASE + '/api/v1/entitlement', { method: 'OPTIONS', headers: { origin: 'null', 'access-control-request-method': 'GET' } }); assert.equal(pre.status, 204); assert.ok(pre.headers.get('access-control-allow-origin'));
  const adm = await fetch(BASE + '/api/admin/summary', { headers: { origin: 'https://evil.example' } }); assert.equal(adm.headers.get('access-control-allow-origin'), null);
  const page = await fetch(BASE + '/admin/'); assert.equal(page.status, 200); assert.match(page.headers.get('content-security-policy'), /script-src 'self'/); assert.doesNotMatch(await page.text(), /<script>[^<]/);
  assert.equal((await fetch(BASE + '/admin/../server.js')).status, 404); assert.equal((await fetch(BASE + '/admin/%2e%2e/server.js')).status, 404);
});
test('16b. ERROR responses also carry CORS headers (otherwise a browser hides the real error from the app)', async () => {
  const c = await newClient(); const hdr = { origin: 'null', 'content-type': 'application/json', 'x-client-id': c.id, 'x-client-secret': c.secret };
  const bad = await fetch(BASE + '/api/v1/license/activate', { method: 'POST', headers: hdr, body: JSON.stringify({ requestId: 'PAY-AAAAAAAAAA', code: '1234' }) });
  assert.equal(bad.status, 400); assert.ok(bad.headers.get('access-control-allow-origin'), '400 must carry ACAO');
  const unauth = await fetch(BASE + '/api/v1/entitlement', { headers: { origin: 'null' } }); assert.equal(unauth.status, 401); assert.ok(unauth.headers.get('access-control-allow-origin'), '401 must carry ACAO');
  const nf = await fetch(BASE + '/api/v1/nope', { headers: { origin: 'null' } }); assert.equal(nf.status, 404); assert.ok(nf.headers.get('access-control-allow-origin'));
});
test('17. oversized / malformed bodies are rejected safely', async () => {
  const c = await newClient(); const r = await fetch(BASE + '/api/v1/usage', { method: 'POST', headers: { 'content-type': 'application/json', 'x-client-id': c.id, 'x-client-secret': c.secret }, body: '{bad' }); assert.equal(r.status, 400);
  const big = await pay(c, { screenshot: 'data:image/png;base64,' + 'A'.repeat(900 * 1024) }).catch(() => ({ status: 413 })); assert.ok([413, 400].includes(big.status));
});
